-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2024 at 01:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_sim-psu`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` bigint(20) UNSIGNED NOT NULL,
  `gambar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_dibuat` date NOT NULL,
  `id_pengguna` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_lengkap` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `nama_pengguna` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kata_kunci` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','petugas') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'petugas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama_lengkap`, `foto`, `nama_pengguna`, `kata_kunci`, `role`) VALUES
(19, 'Admin', 'default.png', 'admin', '$2y$10$LOJAixH5eLLlGJDdL4fWNuC7Kt5TnYoOWDLuSyRljbsoNhv7LwMym', 'admin'),
(20, 'user', 'default.png', 'user', '$2y$10$OBEVaL2fMkelWVi6JMzghO.ijdkaViyKNw1XiNIKlBrGdLCBa0W7O', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `permohonan`
--

CREATE TABLE `permohonan` (
  `id_perumahan_permohonan` bigint(20) UNSIGNED NOT NULL,
  `nama_pemohon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat_pemohon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kelurahan_pemohon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kecamatan_pemohon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kota_pemohon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat_perumahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kelurahan_perumahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kecamatan_perumahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kota_perumahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe_perumahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `luas_kav` decimal(10,2) NOT NULL,
  `luas_efektif` decimal(10,2) NOT NULL,
  `luas_fasum` decimal(10,2) NOT NULL,
  `luas_tpu` decimal(10,2) NOT NULL,
  `luasRTH` decimal(10,2) NOT NULL,
  `jumlah_unit` int(10) UNSIGNED NOT NULL,
  `nomor_surat_pengesahan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_terbit` date NOT NULL,
  `keterangan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `berkas_permohonan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_berkas_permohonan` tinyint(1) NOT NULL DEFAULT 0,
  `berkas_prasarana` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_berkas_prasarana` tinyint(1) NOT NULL DEFAULT 0,
  `berkas_sarana` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_berkas_sarana` tinyint(1) NOT NULL DEFAULT 0,
  `berkas_berita_acara` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_berkas_berita_acara` tinyint(1) NOT NULL DEFAULT 0,
  `berkas_lainnya` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_berkas_lainnya` tinyint(1) NOT NULL DEFAULT 0,
  `status_penyerahan` tinyint(1) NOT NULL DEFAULT 0,
  `id_perumahan` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permohonan`
--

INSERT INTO `permohonan` (`id_perumahan_permohonan`, `nama_pemohon`, `alamat_pemohon`, `kelurahan_pemohon`, `kecamatan_pemohon`, `kota_pemohon`, `alamat_perumahan`, `kelurahan_perumahan`, `kecamatan_perumahan`, `kota_perumahan`, `tipe_perumahan`, `luas_kav`, `luas_efektif`, `luas_fasum`, `luas_tpu`, `luasRTH`, `jumlah_unit`, `nomor_surat_pengesahan`, `tanggal_terbit`, `keterangan`, `berkas_permohonan`, `status_berkas_permohonan`, `berkas_prasarana`, `status_berkas_prasarana`, `berkas_sarana`, `status_berkas_sarana`, `berkas_berita_acara`, `status_berkas_berita_acara`, `berkas_lainnya`, `status_berkas_lainnya`, `status_penyerahan`, `id_perumahan`) VALUES
(554, 'Sonny Darmansyah', 'Perum Situ Endah Jl. Ikan Mas No.12 RT.03/02', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Jl. Sarasa Kp.Loa Sari', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 10755.00, 5887.42, 4867.58, 215.10, 0.00, 0, '04 Tahun 2010', '2010-01-28', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 2),
(555, 'Hari Sutriadi', '', '', '', '', 'Jl. Sarasa', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 7019.00, 5042.85, 1976.15, 0.00, 0.00, 31, '40 Tahun 2017', '2017-09-29', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(556, 'John Santoso', 'Perum Puri CBR II Blok K/5, Jl. Pembangunan Km.01', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 96788.71, 54785.91, 44002.80, 1935.77, 0.00, 0, '653/227/DPU', '2009-06-01', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(557, 'Bambang Sumardi', 'Komplek Fadjr Raya Estate B2-45', 'Cibabat', 'Cimahi Utara', 'Kota Cimahi', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 98780.00, 54194.00, 43994.00, 1975.60, 0.00, 0, '27 Tahun 2013', '2013-12-12', 'Perubahan Ke-1 Mencabut Keputusan Kepala Dinas PU Nomor 653/227/DPU', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(558, 'Made Devi Pramiswari', 'Jl. Soka No.6 DPS BR/LINK Kertalangu', 'Kesiman kertalangu', 'Denpasar Timur', 'Denpasar', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 98780.00, 54391.64, 42412.36, 1976.00, 0.00, 0, '4 Tahun 2015', '2015-02-17', 'Perubahan Ke-2, Mencabut Keputusan Kepala DTRPP NOMOR 27 TAHUN 2013', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(559, 'Ir. Henry Bastian', 'Jl. Soka No.6 DPS BR/LINK Kertalangu', 'Kesiman kertalangu', 'Denpasar Timur', 'Denpasar', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 98778.03, 55762.46, 40969.82, 2045.75, 0.00, 760, '32 TAHUN 2018', '2018-08-28', 'Perubahan ke- IV Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(560, 'Henry Wibisono', 'Jl. Soka No.6 DPS BR/LINK Kertalangu', 'Kesiman kertalangu', 'Denpasar Timur', 'Denpasar', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 98778.03, 55762.46, 40969.82, 2045.75, 0.00, 770, '49 TAHUN 2018', '2018-12-14', 'Perubahan ke- V Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(561, 'Henry Wibisono', 'Jl. Soka No.6 DPS BR/LINK Kertalangu', 'Kesiman kertalangu', 'Denpasar Timur', 'Denpasar', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 43936.09, 21127.01, 22809.08, 2010.00, 0.00, 308, '25 Tahun 2020', '2020-04-29', 'Pengesahan Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(562, 'Ir. Henry Bastian', 'Fajar Raya C2 No. 9 RT.003 RW.024', 'Cibabat', 'Cimahi Utara', 'Kota Cimahi', 'Jl. Kapitan Kp. Joglo RW.003', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Campuran', 98780.00, 21127.01, 22809.08, 2010.00, 0.00, 308, '82 Tahun 2021', '2021-12-15', 'Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 3),
(563, 'Mohamad Iqbal', 'Jl. Gunung Karang Residence Blok B No. 11 RT.003 RW.001', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Jl. Sejahtera RT.002 RW.020', 'Dayeuhluhur', 'Warudoyong', 'Kota Sukabumi', 'Campuran', 32363.50, 17970.54, 14392.96, 650.00, 0.00, 262, '19 Tahun 2021', '2021-03-16', 'Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 4),
(564, 'Cecep Ismatulah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Jl. Nangela', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 9797.00, 5613.36, 4173.64, 200.00, 0.00, 62, '09 Tahun 2017', '2017-03-08', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 5),
(565, 'Cecep Ismatullah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Kp. Legok RT.001/002', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 12811.55, 7487.36, 5324.19, 400.00, 0.00, 62, '04 TAHUN 2018', '2018-01-18', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 5),
(566, 'Cecep Ismatullah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Kp. Legok RT.001/002', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 35512.00, 20427.81, 15084.19, 1800.00, 0.00, 214, '41 TAHUN 2018', '2018-10-12', 'Perubahan ke- III Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 5),
(567, 'Cecep Ismatullah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Kp. Legok RT.001/002', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 43947.33, 25883.02, 18064.31, 1800.00, 0.00, 0, '22 Tahun 2020', '2020-04-20', 'Pengesahan Perubahan Tahap III dan Tahap IV', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 5),
(568, 'Antony Ho', 'Jl. Urip Sumoharjo No. 111 RT.002 RW.005', 'Medono', 'Pekalongan Barat', 'Kota Pekalongan', 'Jl. Rancakadu Kp. Cikaret RT.003 RW.007', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Campuran', 50188.23, 22491.63, 27696.60, 1000.00, 0.00, 323, '78 Tahun 2021', '2021-11-26', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(569, 'Erni Kusumawati Tjetje', 'Jl. Stasiun Timur, Gg. Manggis No.46 RT.001/RW.002', 'Kebonjati', 'Cikole', 'Kota Sukabumi', 'Jl. Balandongan', 'Sudajaya Hilir', 'Baros', 'Kota Sukabumi', 'Komersil', 7420.00, 4966.48, 2453.52, 148.40, 0.00, 0, '2 Tahun 2013', '2013-01-21', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(570, 'Denan Renata', 'Jl. R. Syamsudin, SH. No.2', 'Cikole', 'Cikole', 'Kota Sukabumi', 'Jl. Aminta Azmali', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 7600.00, 5173.00, 2427.00, 152.00, 0.00, 0, '10 Tahun 2011', '2011-07-05', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 8),
(571, 'Ir. Denny Krisnandy', 'Griya Prana Estate Blok C6 No.1', 'Cisarua', 'Cikole', 'Kota Skabumi', 'Jl. Gunung Karang', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 3151.00, 2170.00, 1345.00, 63.02, 0.00, 0, '7 Tahun 2013', '2013-06-10', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 9),
(572, 'Panji Alamsyah', 'Jl. Samsi RT.06/14', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Jl. Ciandam Km.1 RT.03/04', 'Cibeureum Hilir', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 2085.00, 1649.00, 436.00, 41.70, 0.00, 0, '11 Tahun 2013', '2013-06-19', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 10),
(573, 'Dayat Bin Dasan', 'Kebon Pala RT.01/01', 'Kebon Pala', 'Makasar', 'Jakarta Timur', 'Blok Cipelang Jl. Kenari RT.03/03', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Komersil', 929.00, 696.00, 223.00, 18.58, 0.00, 0, '12 Tahun 2013', '2013-11-16', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 11),
(574, 'Ir. Denny Krisnandy', 'Griya Prana Estate Blok C6 No.1', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Jl. Benteng Kidul', 'Dayeuh Luhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 4608.00, 2556.00, 2078.00, 92.16, 0.00, 0, '5 Tahun 2015', '2015-02-17', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 12),
(575, 'Bambang Nurtanio', 'Jl. Satria Raya No.6 Kupat', 'Caringin', '', 'Kota Bandung', 'Jl. Sriwidari RT.003/002', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 7700.00, 4487.52, 3212.48, 154.00, 0.00, 0, '8 Tahun 2015', '2015-02-23', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 13),
(576, 'Christian', 'Cikahuripan RT.005/006', 'Neglasari', 'Neglasari', 'Tanggerang', 'Jl. Benteng Kidul RT.003/003', 'Dayeuh Luhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 17023.00, 8924.14, 8108.86, 340.46, 0.00, 0, '10 Tahun 2015', '2015-03-18', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 14),
(577, 'Chairul Hanie', 'Jl. Nyland No.12', '', '', 'Bandung', 'Jl. Ciaul Pasir RT.004/017', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Komersil', 17006.00, 7234.00, 9772.00, 340.12, 0.00, 0, '9 Tahun 2015', '2015-03-20', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 15),
(578, 'Dedih', 'Kp. Pasir ipis No.80 RT 005/012', 'Subangjaya', 'Cikole', 'Kota sukabumi', 'Jl. Hj. Kokom Komariah RT.005/012', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 2185.00, 1.46, 721.31, 60.00, 0.00, 11, '36 Tahun 2016', '2016-05-16', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 16),
(579, 'Christian', 'Cikahuripan RT.005/006', 'Neglasari', 'Neglasari', 'Tangerang', 'Jl. Benteng Kidul RT.003/003', 'Dayeuh Luhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 17023.00, 8924.14, 8108.86, 340.46, 0.00, 107, '9 Tahun 2016', '2016-02-04', 'Perubahan Ke-1 Mencabut Keputusan Kepala DTRPP NOMOR 10 TAHUN 2015', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 14),
(580, 'Dewi Arina Munandar', 'Komp. DPR RI Blok A 1/24 RT.001/RW.009', 'Pondok Ranji', 'Ciputat', 'Kota Tanggerang Selatan', 'Jl. Taman Bahagia', 'Benteng', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 3263.43, 2064.26, 1199.17, 100.00, 0.00, 28, '29 TAHUN 2018', '2018-07-25', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 17),
(581, 'Sandi Andreas', 'Jl. Pelabuhan II No. 279', 'Citamiang', 'Citamiang', 'Kota Sukabumi', 'Jl. Sawahbera RT.001/RW.004', 'Dayeuhluhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 5678.78, 2985.87, 2692.91, 130.00, 0.00, 40, '36 TAHUN 2018', '2018-09-17', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 18),
(582, 'Sandi Andreas', 'Jl. Pelabuhan II No. 279', 'Citamiang', 'Citamiang', 'Kota Sukabumi', 'Jl. Sawahbera RT.001/RW.004', 'Dayeuhluhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 3154.82, 2985.82, 0.00, 130.00, 0.00, 39, '18 Tahun 2019', '2019-01-23', 'Perubahan ke-I Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 18),
(583, 'Dudung Koswara, M.Pd.', 'Villa Edelweiss Blok C No. 37 RT.004/RW.015', 'Desa Sukaraja', 'Sukabumi', 'Kabupaten Sukabumi', 'Jl. Sarasa RT.003/RW.005', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 13167.00, 6423.89, 6743.11, 0.00, 0.00, 54, '43 TAHUN 2018', '2018-10-22', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 19),
(584, 'Drs. Yuwono Darpito Hudoyo', 'Jl. Rajawali Kav.1738 BNI RT.03 RW.17', 'Sarua', 'Ciputat', 'Kabupaten Tangerang', 'dsasdasd', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 2155.00, 1520.00, 635.00, 43.10, 0.00, 0, '653/01/DTLP', '2008-01-07', 'Perluasan', '', 1, '', 0, '', 0, '', 0, '', 0, 0, 20),
(585, 'Drs. Yuwono Darpito Hudoyo', 'Jl. Rajawali Kav.1738 BNI RT.03 RW.17', 'Sarua', 'Ciputat', 'Kabupaten Tangerang', '', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 3295.00, 2200.00, 1095.00, 65.90, 0.00, 0, '653/07/DTLP', '2008-04-02', 'Perluasan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 20),
(586, 'Ir. Gunawan Cahyadi', 'Perum Taman Asri Blok A-6/01 RT.01 RW.14', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Bhineka Karya RT.01  RW.04', 'Karamat', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 8500.00, 4200.00, 4300.00, 170.00, 0.00, 0, '653/19/DTLP', '2008-09-11', 'Perubahan dari H. Sudayat', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 21),
(587, 'Irma Yulandi, S.H.', 'Jl. Cipanengah RT.02/08', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Jl. Cicadas', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Komersil', 5000.00, 3289.42, 1710.58, 100.00, 0.00, 0, '19 Tahun 2009', '2009-11-18', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(588, 'Tan Le Gak', 'Jl. R. Syamsudin, SH. No.3', 'Cikole', 'Cikole', 'Kota Sukabumi', 'Jl. Subangjaya', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 12550.00, 8699.00, 3851.00, 251.00, 0.00, 0, '05 Tahun 2011', '2011-02-17', 'Perubahan Ke-1', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(589, 'Ny. Hj. Nyi Elom Romlah', 'Jl. R.A. Kosasih RT.001/012', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Ciaul Pasir', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 2270.00, 1949.00, 321.00, 45.40, 0.00, 0, '16 Tahun 2011', '2011-11-21', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(590, 'Johanes Hidayat', 'Jl. A. Yani No.167 RT.004/007', 'Gunungparang', 'Cikole', 'Kota Sukabumi', 'Jl. Samsi', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Komersil', 4585.00, 2590.00, 1753.00, 91.70, 0.00, 0, '6 TAHUN 2014', '2014-01-29', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 25),
(591, 'Erni Kusumawati Tjetje', 'Jl. Stasiun Timur, Gg. Manggis No.46 RT.001/RW.002', 'Kebonjati', 'Cikole', 'Kota Sukabumi', 'Jl.Balandongan RT.001/RW.003', 'Sudajaya Hilir', 'Baros', 'Kota Sukabumi', 'Komersil', 7180.50, 3987.00, 3193.50, 143.61, 0.00, 0, '23 TAHUN 2014', '2014-07-03', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 26),
(592, 'Asep Muhidin', 'Kp. Jati', 'Desa Gekbrong', 'Gekbrong', 'Kabupaten Cianjur', 'Jl. Nangela', 'Baros', 'Baros', 'Kota Sukabumi', 'Komersil', 9725.00, 6054.00, 3592.00, 195.00, 0.00, 0, '39 TAHUN 2014', '2014-12-15', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 27),
(593, 'Dr. Abas Thalib', 'Jl. Pedati  No.24', '', '', '', 'Jl. Benteng  Kidul  Blok  21', 'Benteng', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 2270.00, 1.36, 912.00, 100.00, 0.00, 16, '14 Tahun 2016', '2016-03-03', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 28),
(594, 'Idod  Juhandi', 'Bukit Ciaul Indah Blok H. 23/24 RT.003/11', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Kokom Komariah  RT.004/013', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 0.00, 0.00, 0.00, 0.00, 0.00, 0, '-', '2014-12-15', 'TIDAK BERLANJUT', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(595, 'Ir. Yanti Heryanti', '', '', '', '', 'Jl. Garuda', 'Baros', 'Baros', 'Kota Sukabumi', 'Komersil', 4450.00, 2670.66, 1780.02, 89.00, 0.00, 26, '54 Tahun 2017', '2017-12-13', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 30),
(596, 'Dedih', 'Jl. Hj. Kokom Komariah', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Hj. Kokom Komariah', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 14940.00, 8202.00, 6738.00, 298.80, 0.00, 0, '1 Tahun 2013', '2013-01-04', 'Pengesahan Baru', '', 1, '', 1, '', 1, '', 1, '', 1, 0, 1),
(597, 'Dedih', 'Jl. H. Kokon Komariah Pasir Ipis No. 82 RT.004/RW.012', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Gunung Karang RT.004/RW.010 // RT.009/RW.002/003', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 12484.70, 11949.70, 0.00, 400.00, 0.00, 135, '15 Tahun 2019', '2019-01-09', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 32),
(598, 'Taufik Aminuddin, ST', 'Jl. Borobudur No.1  RT.001/RW.003', 'Cibaduyut Kidul', 'Bojongloa Kidul', 'Kota Bandung', 'Jl. Babakan Jampang', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Komersil', 24980.00, 13603.23, 11376.77, 0.00, 0.00, 138, '13 TAHUN 2018', '2018-04-05', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 33),
(599, 'Yanuar Pribadi, SE.', 'Perum Cimahpar II, Jl. Cendrawasih No.19 RT.002/011', 'Desa Pasir Halang', 'Sukaraja', 'Kabupaten Sukabumi', 'Jl. Sriwidari', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 20305.00, 11337.27, 8899.97, 406.10, 0.00, 0, '22 Tahun 2012', '2012-10-30', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 34),
(600, 'Deby Pebrianti Puspita Sari', 'Jl.Sriwidari No.03 RT.002/RW.003', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Jl.Sriwidari No.03 RT.002/RW.003', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 20237.92, 10828.60, 9408.62, 400.00, 0.00, 0, '43 TAHUN 2014', '2014-12-31', 'Perubahan Ke-1, Mencabut Keputusan Kepala Dinas PU NOMOR 22 TAHUN 2014', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 35),
(601, 'Deby Pebianti PS, S.E.', 'Jl. Sriwidari', 'Sriwidari', 'Sriwidari', 'Kota Sukabumi', 'Jl. Sriwedari RT.003/002', 'Sriwedari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 20237.66, 12255.81, 7981.85, 400.00, 0.00, 29, '10 TAHUN 2018', '2018-03-13', 'Perubahan ke- II Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 35),
(602, 'Andri Potera', 'Jl. Sedap Malam II No. 18 Taman Yasmin 3', 'Curug Mekar', 'Bogor Barat', 'Kota Bogor', 'Jl. Lingkar Selatan', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 136117.44, 54185.39, 79650.05, 4450.00, 0.00, 0, '81 Tahun 2021', '2021-12-10', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 36),
(603, 'Yunadi Yoe', 'Jl. Suryakencana No.30', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Pembangunan', 'Cibeureum Hilir', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 19820.00, 11536.00, 8284.00, 396.40, 0.00, 0, '02 Tahun 2010', '2010-01-13', 'Perubahan Site Plan', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 37),
(604, 'Clarissa Agustine Joe', 'Jl. Suryakencana No.30', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Pembangunan', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 13360.55, 8016.62, 5344.93, 267.21, 0.00, 0, '15 Tahun 2010', '2010-08-05', 'Perubahan Perluasan 1', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 38),
(605, 'Yunadi Yoe', 'Jl. Suryakencana No.30', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Pembangunan', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 20439.91, 12100.06, 3851.00, 408.80, 0.00, 0, '11 Tahun 2011', '2011-09-07', 'Perubahan Ke-5', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 38),
(606, 'Yunadi Yoe', 'Jl. Suryakencana No.30', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Pembangunan', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 18290.00, 9515.09, 8775.89, 365.80, 0.00, 0, '18 Tahun 2009', '2009-09-04', 'Perluasan Tahap III dan Perubahan Site Plan', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 38),
(607, 'Yunadi Yoe', 'Jl. Suryakencana No. 30 RT 003 RW 005', 'Gunungparang', 'Cikole', 'Kota Sukabumi', 'Jl. Pembangunan KM. 1', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 9118.33, 4540.81, 3723.30, 1830.00, 0.00, 0, '46 Tahun 2020', '2020-09-21', 'Pengesahan perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 39),
(608, 'Fakhri Nur Ahmad', 'Perum Bumi Sariwangi 1 Blok I No. 8B RT. 008 RW. 014', 'Sariwangi', 'Parongpong', 'Kabupaten Bandung Barat', 'Jl. Sejahtera RT.003 RW.011', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 33046.00, 14793.00, 18246.00, 660.80, 0.00, 93, '05 Tahun 2020', '2020-01-30', 'Pengesahan Perubahan Site Plan No. 57 Tahun 2019 Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 40),
(609, 'Fakhri Nur Ahmad', 'Perum Bumi Sariwangi 1 Blok I No. 8B RT. 008 RW. 014', 'Sariwangi', 'Parongpong', 'Kabupaten Bandung Barat', 'Jl. Sejahtera RT.003 RW.011', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 33046.00, 15679.43, 17366.57, 660.80, 0.00, 68, '50 Tahun 2021', '2021-06-22', 'Pengesahan Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 40),
(610, 'Fakhri Nur Ahmad', 'Perum Bumi Sariwangi 1 Blok I No. 8B RT. 008 RW. 014', 'Sariwangi', 'Parongpong', 'Kabupaten Bandung Barat', 'Jl. Sejahtera RT 003 RW 011', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 15320.80, 14541.00, 0.00, 660.80, 0.00, 119, '57 Tahun 2019', '2019-11-12', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 40),
(611, 'Hj. Elis Sugiarti, SE.', 'Jl. Titiran No.24', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Jl. Aminta Azmali', 'Sriwidari', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 33101.00, 20608.25, 12492.75, 662.02, 0.00, 0, '05 Tahun 2010', '2010-01-29', 'Perubahan ke-1', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 41),
(612, 'Yudha Sukmagara,SH', 'Jl. Siliwangi No.112, Jl.Syamsudin, SH No.31', 'Cikole', 'Cikole', 'Kota Sukabumi', 'Jl. Stadion Suryakencana', 'Dayeuh Luhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 7900.00, 4773.25, 3126.75, 158.00, 0.00, 0, '653/16/DTLP', '2008-08-05', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 42),
(613, 'Novi Eriyanti', 'Villa Setiabudi Residence Blok A RT.001 RW.001', 'Desa Pesawahan', 'Cicurug', 'Kabupaten Sukabumi', 'Jl. Ciandam RT.005/RW.001', 'Cibeureumhilir', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 10441.70, 9906.70, 0.00, 400.00, 0.00, 135, '21 Tahun 2019', '2019-02-19', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 43),
(614, 'Novi Erianti', 'Villa Setiabudi Residence Blok A RT.001 RW.001', 'Desa Pasawahan', 'Cicurug', 'Kabupaten Sukabumi', 'Jl. Ciandam RT.005 RW.006', 'Cibeureumhilir', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 19755.00, 10792.68, 8962.32, 400.00, 0.00, 0, '55 Tahun 2020', '2020-11-18', 'Perubahan ke-1 Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 43),
(615, 'Rochman Iroyo', 'Jl. Mangga Besar No.41', 'Utan Kayu Utara', 'Matraman', 'Jakarta Timur', 'Jl. Merbabu', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 174980.00, 59748.80, 46770.55, 3499.60, 0.00, 0, '653/228/DPU', '2009-06-01', 'Perluasan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 44),
(616, 'Rochman Iroyo', 'Jl. Mangga Besar No.41', 'Utan Kayu Utara', 'Matraman', 'Jakarta Timur', 'Jl. Merbabu', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 106533.75, 59645.20, 46888.55, 2130.68, 0.00, 0, '16 Tahun 2010', '2010-08-27', 'Perubahan ke-5', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 44),
(617, 'Rochman Iroyo', 'Jl. Mangga Besar No.41', 'Utan Kayu Utara', 'Matraman', 'Jakarta Timur', 'Jl. Merbabu', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 23850.00, 16370.00, 7480.00, 477.00, 0.00, 0, '20 Tahun 2010', '2010-11-19', 'Perubahan ke-6', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 44),
(618, 'Rochman Iroyo', 'Jl. Mangga Besar No.41', 'Utan Kayu Utara', 'Matraman', 'Jakarta Timur', 'Jl. Merbabu', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 96799.35, 58235.20, 38564.15, 1935.99, 0.00, 0, '9 Tahun 2011', '2011-05-26', 'Perubahan ke-7', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 44),
(619, 'Halim Wijaya', 'Jl. Mayawati No.15', 'Gunungparang', 'Cikole', 'Kota Sukabumi', 'Jl. Nangela Kp. Ciwalen', 'Baros', 'Baros', 'Kota Sukabumi', 'Komersil', 80920.00, 44083.00, 36837.00, 1618.40, 0.00, 0, '17 Tahun 2009', '2009-09-04', 'Pengesahan Baru', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 45),
(620, 'Ir. Yono Widodo', 'Jl. Bina Marga I Kav.16', 'Baranangsiang', 'Kota Bogor Timur', 'Kota Bogor', 'Jl. Prana', 'Cikole dan Cisarua', 'Cikole', 'Kota Sukabumi', 'Komersil', 96295.00, 55276.00, 40596.00, 1925.90, 0.00, 0, '19 Tahun 2012', '2012-06-29', 'Perubahan Ke-1 (luasan ke Tahap II) Mencabut Keputusan Kepala Dinas Tarlingkim No. 653/08/DTLP Tgl 9 Sep. 2005', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 46),
(621, 'Ir. Yono Widodo', 'Jl. Bina Marga I Kav.16', 'Baranangsiang', 'Kota Bogor Timur', 'Kota Bogor', 'Jl. Samsi', 'Cisarua', 'Cikole', 'Kota Sukabumi', 'Komersil', 33112.00, 19009.00, 14103.00, 5767.00, 0.00, 0, '33 TAHUN 2014', '2014-10-27', 'Perubahan Ke-1 , Mencabut Keputusan Kepala DTRPP NOMOR 14 TAHUN 2014', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 47),
(622, 'Denan Renata', 'Jl. Kabandungan No.8', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Kabandungan No.8', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Komersil', 0.00, 42999.71, 55647.58, 0.00, 0.00, 0, '14 Tahun 2009', '2009-06-17', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 48),
(623, 'Budi', 'Jl. Kabandungan No.8', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Kabandungan No.8', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Komersil', 98830.78, 32618.15, 54482.36, 1976.62, 0.00, 0, '10 Tahun 2012', '2012-04-09', 'Perubahan Ke-1, Mencabut Keputusan Kepala Dinas PU Nomor 14 Tahun 2009', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 48),
(624, 'M. Abdul Karim', 'Jl. Nanggeleng RT.001 RW.008', 'Nanggeleng', 'Citamiang', 'Kota Sukabumi', '', 'Jayaraksa', 'Baros', 'Kota Sukabumi', 'Komersil', 10123.47, 5213.61, 5139.86, 200.00, 0.00, 64, '85 Tahun 2021', '2021-12-22', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 49),
(625, 'Atik Yayan Saputra', 'Jl. Selabintana RT 004 RW 007', 'Selabatu', 'Cikole', 'Kota Sukabumi', 'Jl. Karamat RT 002 RW 004', 'Karamat', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 11699.00, 6102.48, 0.00, 250.00, 0.00, 0, '34 Tahun 2020', '2020-07-28', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 50),
(626, 'Ratu Defi Kania, SE.', 'Perum Mangkalaya, Jl. Veteran No.4', 'Desa Cibolang', 'Gunungguruh', 'Kabupaten Sukabumi', 'Jl. Sarasa', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 8290.00, 4966.00, 3324.00, 165.80, 0.00, 0, '19 Tahun 2010', '2010-11-18', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 51),
(627, 'Ratu Defi Kania, SE.', 'Perum Mangkalaya, Jl. Veteran No.4', 'Desa Cibolang', 'Gunungguruh', 'Kabupaten Sukabumi', 'Jl. Sarasa', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 8290.00, 4882.50, 3407.50, 165.80, 0.00, 0, '14 Tahun 2012', '2012-05-10', 'Perubahan Ke-1 Mencabut Keputusan Kepala Dinas PU No.19 Th.2010', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 51),
(628, 'PT. Metroprima Artha Nusa', 'Jl. Johar No.2', '', '', 'Kota Sukabumi', '', 'Dayeuh Luhur', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 36520.00, 20794.50, 15725.50, 730.40, 0.00, 0, '653/08/DTLP', '2008-04-07', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 52),
(629, 'Dase Sutisna', 'Babakan Bandung RT.03/01', '', '', 'Kota Bogor', 'Sudajaya Hilir', 'Jaya Mekar', 'Baros', 'Kota Sukabumi', 'Komersil', 2710.00, 1609.00, 1101.00, 54.20, 0.00, 0, '26 Tahun 2012', '2012-12-28', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 53),
(630, 'Jumalianto, A.Ptnh, MM', 'Villa Adi Prima RT.003/015', 'Desa Langensari', 'Sukaraja', 'Kabupaten Sukabumi', 'Jl.  Limusnunggal  RT 001/003', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 5064.00, 2765.00, 2298.00, 100.00, 0.00, 127, '31 Tahun 2016', '2016-07-26', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 54),
(631, 'Luthfi Musyahidin', 'Jl. A. Yani No.197 RT.004 RW.004', 'Kebonjati', 'Cikole', 'Kota Sukabumi', 'Jl. Limusnunggal', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 4206.67, 2016.00, 2190.68, 100.00, 0.00, 28, '72 Tahun 2021', '2021-10-21', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(632, 'Mujiono', 'Perum Purnawira Asri B 19', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Jl. Cicadas', 'Sindangsari', 'Lembursitu', 'Kota Sukabumi', 'Komersil', 2664.00, 1469.06, 1195.48, 53.28, 0.00, 0, '9 Tahun 2015', '2015-02-26', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 56),
(633, 'Mujiono', 'Purnawira Asri B 19 RT.004/RW.005', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', '', '', '', 'Kota Sukabumi', 'Komersil', 2462.27, 2237.27, 0.00, 200.00, 0.00, 25, '28 Tahun 2019', '2019-04-22', 'Perubahan ke- II Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 56),
(634, 'Mujiono', 'Purnawira Asri B 19 RT.004/RW.005', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Jl. Cicadas RT.002/RW.006', 'Sindangsari', 'Lembursitu', 'Kota Sukabumi', 'Komersil', 3500.00, 1787.76, 1712.23, 100.00, 0.00, 22, '16 Tahun 2020', '2020-03-17', '', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 58),
(635, 'Encep Rudi Siswanto', 'Kp. Subang Kidul RT.03/013', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Subangjaya', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 8300.00, 5023.00, 3277.00, 166.00, 0.00, 0, '25 Tahun 2013', '2013-12-06', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 59),
(636, 'Encep Rudi Siswanto', 'Jl. Subangjaya', 'Subangjaya', 'Subangjaya', 'Kota Sukabumi', 'Jl. Lio Santa', 'Gedong Panjang', 'Citamiang', 'Kota Sukabumi', 'Komersil', 9086.88, 4578.76, 4507.92, 200.00, 0.00, 0, '51 Tahun 2015', '2015-11-19', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 60),
(637, 'Yokeu Sukmartih', 'Jl. RE. Martadinata No.80A RT.001/RW.005', 'Kebonjati', 'Cikole', 'Kota Sukabumi', 'Jl. Baros RT.003/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Komersil', 12988.00, 6572.00, 6410.00, 240.00, 0.00, 53, '45 Tahun 2016', '2016-06-30', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 61),
(638, 'Yokeu Sukmaratih', 'Jl. RE. Martadinata No.80A RT.001/RW.005', 'Kebonjati', 'Cikole', 'Kota Sukabumi', 'Jl. Baros RT.003/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Komersil', 16338.35, 8773.00, 7565.35, 340.00, 0.00, 23, '30 TAHUN 2018', '2018-07-31', 'Perubahan ke- III Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 62),
(639, 'Ir. Gunawan Cahyadi', 'Jl. Ciaul Pasir Km.1 Perum Taman Asri', 'Subangjaya', 'Cikole', 'Kota Sukabumi', '', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 3410.00, 2045.00, 1365.00, 68.20, 0.00, 0, '653/02/DTLP', '2008-02-06', 'Perluasan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 63),
(640, 'Ir. Gunawan Cahyadi', 'Jl. Ciaul Pasir Km.1 Perum Taman Asri', 'Subangjaya', 'Cikole', 'Kota Sukabumi', '', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 3970.00, 2382.00, 1588.00, 79.40, 0.00, 0, '653/03/DTLP', '2008-02-26', 'Perluasan', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 64),
(641, 'H. Masrukin, SE.', '', '', '', '', 'Jl. Bhineka Karya RT. 001 RW. 007', 'Karamat', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 0.00, 0.00, 0.00, 0.00, 0.00, 0, '27 Tahun 2020', '2020-04-30', 'Pengesahan Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 65),
(642, 'Dino Suryadi', 'Jl. Benteng Kidul RT 002 RW 002', 'Benteng Kidul', 'Warudoyong', 'Kota Sukabumi', 'Jl. Benteng Kidul RT 002 RW 002', 'Benteng Kidul', 'Warudoyong', 'Kota Sukabumi', 'Komersil', 7651.00, 4107.67, 3296.16, 150.00, 0.00, 0, '45 Tahun 2020', '2020-09-16', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 66),
(643, 'Robert Kakan Tanuatmadja', 'Jl. Gajah Mada No.117-118', '', 'Taman Sari', 'Jakarta Barat', 'Jl. Subangjaya', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 65903.00, 43423.00, 22480.00, 1318.06, 0.00, 0, '22 Tahun 2010', '2010-11-23', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 67),
(644, 'Oki Hermawan Sumedi', 'Jl. R. Syamsudin, SH No.5 RT.006 RW.007', 'Cikole', 'Cikole', 'Kota Sukabumi', 'Jl. Ciseureuh RT.003 RW.005', 'Karangtengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 5035.00, 2808.87, 2226.13, 0.00, 0.00, 36, '86 Tahun 2021', '2021-12-30', 'Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 68),
(645, 'Oki Hermawan Sumedi', 'Jl. R. Syamsudin, SH No. 5 RT 006 RW 007', 'Cikole', 'Cikole', 'Kota Sukabumi', 'Jl. Ciseureuh RT 003 RW 005', 'Karangtengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 2696.84, 2696.84, 0.00, 0.00, 0.00, 0, '63 Tahun 2019', '2019-12-10', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 68),
(646, 'Ir. Tan Nixsun', 'Tangerang', '', '', 'Kota Tanggerang', 'Jl. Garuda', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 37770.00, 12985.24, 24784.76, 600.00, 0.00, 114, '15 Tahun 2021', '2021-02-23', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 69),
(647, 'H. Freddy', 'Kandara Residence Blok A 1 No. 12', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Subangjaya', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Komersil', 4445.00, 2598.46, 1846.54, 100.00, 0.00, 0, '22 Tahun 2015', '2015-05-04', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 70),
(648, 'Ir. H. Heri Hendriawan', '', '', '', '', 'Jl. Sarasa', 'Limusnunggal', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 5250.86, 3155.46, 2095.40, 106.00, 0.00, 40, '54 Tahun 2017', '2017-12-27', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 71),
(649, 'Hj. Rani Setiani, SE.', 'Puri Cibeureum Permai I Blok F No.1/2 RT.003 RW.011', 'Cibeureum Hilir', 'Cibeureum', 'Kota Sukabumi', 'Jl. Sarasa RT.003 RW.005', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 5221.23, 2678.23, 2543.00, 106.00, 0.00, 0, '61 Tahun 2020', '2020-12-14', 'Perubahan ke-1 Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 72),
(650, 'Hj. Rani Setiani, SE.', 'Puri Cibeureum Permai I Blok F No.1/2 RT.003 RW.011', 'Cibeureum Hilir', 'Cibeureum', 'Kota Sukabumi', 'Jl. Sarasa RT.003 RW.005', 'Babakan', 'Cibeureum', 'Kota Sukabumi', 'Komersil', 5221.23, 2892.00, 4658.46, 106.00, 0.00, 38, '80 Tahun 2021', '2021-12-08', 'Pengesahan Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 72),
(651, 'drs. Indra Bakty', 'Pondok Hijau Raya Blok c5/6 RT 007 RW 007', '', 'Ciputat Timur', 'Kota Tanggerang', 'Jl. Merbabu rt 002 rw 004', 'Karangtengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 4975.91, 4423.91, 0.00, 500.00, 0.00, 52, '47 Tahun 2019', '2019-09-26', 'Pengesahan perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 74),
(652, 'Drs. Indra Bakty', '', '', '', '', 'Jl. Merbabu', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 8697.00, 4585.80, 4120.20, 500.00, 0.00, 48, '48 Tahun 2017', '2017-11-10', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 75),
(653, 'Nita Hendrawati', 'Perum Griya Tugu Asri Blok C2/4 RT 003 RW 019', 'Tugu', 'Cimanggis', 'Kota Depok', 'Jl. Gotong Royong Gg. Nurul Iman RT 001 RW 008', 'Gunungpuyuh', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 7685.00, 3791.45, 3893.55, 200.00, 0.00, 46, '42 Tahun 2020', '2020-09-03', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 76),
(654, 'Nita Hendrawati', 'Perum Griya Tugu Asri Blok C2/4 RT 003 RW 019', 'Tugu', 'Cimanggis', 'Kota Depok', 'Jl. Gotong Royong Gg. Nurul Iman RT 001 RW 008', 'Gunungpuyuh', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 7685.00, 4429.62, 3255.38, 200.00, 0.00, 46, '48 Tahun 2020', '2020-09-23', 'Pengesahan perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 76),
(655, 'Nita Hendrawati', 'Perum Griya Tugu Asri Blok C2/4 RT.003 RW.019', 'Tugu', 'Cimanggis', 'Kota Depok', 'Jl. Gotong Royong Gg. Nurul Iman RT.001 RW.008', 'Gunungpuyuh', 'Gunungpuyuh', 'Kota Sukabumi', 'Komersil', 7217.00, 4003.62, 3213.38, 200.00, 0.00, 0, '67 Tahun 2020', '2020-12-29', 'Perubahan ke-II Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 76),
(656, 'Raden Koesoemo Hutaripto', 'Perum Baros Kencana, Jl. Zamrud IV No.95', 'Baros', 'Baros', 'Kota Sukabumi', 'Jl. Proklamasi RT.003/008 Kp. Baru', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Subsidi', 3213.00, 1931.00, 1281.15, 250.00, 0.00, 31, '50 Tahun 2016', '2016-05-04', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 77),
(657, 'Ir. Edifrizal Darma', 'Jl. Bungsan No.80', 'Bedahan', 'Sawangan', 'Kota Depok', 'Jl. Merdeka', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Subsidi', 7720.00, 3305.00, 2204.00, 154.40, 0.00, 0, '26 Tahun 2013', '2013-12-09', 'Pengesahan Baru DTRPP', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 78),
(658, 'Cecep Ismatulah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Jl. Nangela', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 6534.00, 3918.23, 2615.77, 132.00, 0.00, 0, '21 Tahun 2015', '2015-05-04', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 79),
(659, 'Cecep Ismatulah', 'Jl. Baros Km.5 Kp. Genteng RT.002/RW.002', 'Baros', 'Baros', 'Kota Sukabumi', 'Jl. Nangela', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 6534.00, 3918.23, 2615.77, 132.00, 0.00, 48, '1 Tahun 2017', '2016-01-01', 'Perubahan Ke-1 , Mencabut Keputusan Kepala DTRPP NOMOR 21 TAHUN 2015', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 79),
(660, 'Robby Cahyadi Kurniawan', '', '', '', '', 'Jl. Bantar Panjang', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 2678.00, 1620.00, 1058.00, 100.00, 0.00, 26, '12 Tahun 2017', '2017-04-28', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 80),
(661, 'Mujiono', 'Perum Purnawira Asri RT.04/05', 'Cipanengah', 'Lembursitu', 'Kota  Sukabumi', 'Jl. Tata  Nugraha', 'Jaya Mekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 2664.00, 1469.00, 1194.00, 53.28, 0.00, 14, '2 Tahun 2017', '2017-02-05', 'Pengesahan Baru DTRPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 81),
(662, 'Mujiono', 'Perum Purnawira Asri RT.04/05', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Jl. Tata  Nugraha', 'Jaya Mekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 9851.00, 5904.00, 3947.00, 200.00, 0.00, 14, '53 Tahun 2017', '2017-12-13', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 81),
(663, 'Hasri Samsudin', 'Kp. Bantar Muncang Kulon RT 001 RW 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Palasari Kp. Raweuy Utara RT 003 RW 006', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 9333.00, 8888.00, 0.00, 300.00, 0.00, 145, '26 Tahun 2019', '2019-04-08', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 82),
(664, 'Hasri Samsudin', 'Kp. Bantar Muncang Kulon RT 001 RW 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Palasari Kp. Raweuy Utara RT 003 RW 006', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 3176.00, 1800.00, 1376.00, 100.00, 0.00, 30, '09 Tahun 2020', '2020-02-25', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 83),
(665, 'Hasri Samsudin', 'Kp. Bantar Muncang Kulon RT 001 RW 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Palasari Kp. Raweuy Utara RT 003 RW 006', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 3176.00, 1800.00, 1317.00, 100.00, 0.00, 30, '38 Tahun 2020', '2020-08-13', 'Pengesahan Perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 83),
(666, 'Hasri Samsudin', 'Kp. Bantarmuncang Kulon RT. 001 RW. 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Tata Nugraha RT. 005 RW. 006', 'Jayamekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 15043.00, 8988.51, 6054.49, 300.00, 0.00, 147, '23 Tahun 2020', '2020-04-22', 'Pengesahan Perubahan', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 82),
(667, 'Hasri Samsudin', 'Kp. Bantar Muncang Kulon RT 001 RW 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Tata Nugraha RT 005 RW 007', 'Jayamekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 15043.00, 8988.51, 5957.11, 300.00, 0.00, 147, '44 Tahun 2020', '2020-09-16', 'Pengesahan perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 1, '', 1, '', 1, '', 1, '', 1, 1, 1),
(668, 'Arief Rachmat Hakim', 'Kp. Bantar Muncang Kulon RT 001 RW 007', 'Desa Sekarwangi', 'Cibadak', 'Kabupaten Sukabumi', 'Jl. Tata Nugraha RT 005 RW 007', 'Jayamekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 23373.00, 13474.51, 9876.50, 500.00, 0.00, 220, '50 Tahun 2020', '2020-10-06', 'Pengesahan perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(669, 'Nur Yahyadi', 'Pesona Taman Situ Gunung Blok A2 No.1 RT.035/RW.003', 'Desa Sukasari', 'Cisaat', 'Kabupaten Sukabumi', 'Jl. Lamping RT005/005', 'Gedongpanjang', 'Citamiang', 'Kota Sukabumi', 'Subsidi', 1545.00, 800.76, 744.24, 35.00, 0.00, 11, '20 TAHUN 2018', '2018-06-29', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 84),
(670, 'Arie Sariono Idris', 'Jl. Mangga No.37', 'Sindang Palay', 'Cibeureum', 'Kota Sukabumi', '', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 114502.00, 69292.00, 45210.00, 2290.04, 0.00, 0, '08 Tahun 2010', '2010-03-18', 'Perubahan Kedua', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 1),
(671, 'Riko Narami', 'Jl. Raya Cinangneng RT.003/RW.006', 'Cibanteng', 'Ciampea', 'Kabupaten Bogor', 'Jl. Bantar Panjang RT.003/009', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 2000.56, 1200.00, 800.56, 0.00, 0.00, 20, '31 TAHUN 2018', '2018-08-02', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 86),
(672, 'Riko Narami', 'Jl. Raya Cinangneng RT.003/RW.006', 'Desa Cibanteng', 'Ciampea', 'Kabupaten Bogor', 'Jl. Sawah Bera Blok Ciborongbok RT.001/RW.001', 'Dayeuhluhur', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 5931.00, 3217.82, 2713.18, 118.00, 0.00, 53, '50 TAHUN 2018', '2018-12-17', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 87),
(673, 'Riko Narami', 'Jl. Raya Cinangneng RT.003/RW.006', 'Cibanteng', 'Ciampea', 'Kabupaten Bogor', 'Jl. Caringin Ngumbang Kp. Bantar Panjang RT.003/RW.009', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 3571.96, 2100.00, 1471.96, 75.00, 0.00, 35, '51 TAHUN 2018', '2018-12-17', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 88),
(674, 'Riko Narami', 'Jl. Cinangneng RT 003 RW 006', '', 'Ciampea', 'Kabupaten Bogor', 'Jl. Caringin Ngumbang Kp. Bantar Panjang RT 003 RW 009', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 0.00, 4560.00, 0.00, 170.00, 0.00, 76, '37 Tahun 2019', '2019-07-03', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 88),
(675, 'Nur Hasan', 'Taman Asri Blok B4 No. 19 RT 002 RW 014', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Lingkungan RT 001 RW 005', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 0.00, 2017.00, 0.00, 73.00, 0.00, 32, '38 Tahun 2019', '2019-07-18', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 89),
(676, 'Nur Hasan', 'Taman Asri Blok B4 No. 19 RT.002 RW. 014', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Lingkungan RT.001 RW.005', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 3656.00, 2017.00, 1492.79, 73.00, 0.00, 32, '54 Tahun 2020', '2020-11-10', 'Perubahan ke-1 No. 38 Th 2019 Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 89),
(677, 'Nur Hasan', 'Taman Asri Blok B4 No. 19 RT.002 RW. 014', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Jl. Lingkungan RT.001 RW.005', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 5013.00, 2875.00, 1939.66, 173.00, 0.00, 45, '17 Tahun 2021', '2021-03-08', 'Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 89),
(678, 'Diki Darmadi', 'Perum Bumi Purnawira Asri Blok R No. 22 RT.004/RW.005', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Jl. Nangela RT.002 RW.009', 'Baros', 'Baros', 'Kota Sukabumi', 'Subsidi', 27445.00, 17303.28, 10141.72, 530.00, 0.00, 284, '34 TAHUN 2018', '2018-08-30', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 90),
(679, 'Diki Darmadi', 'Perum Bumi Purnawira Asri Blok R No.22 RT. 004 RW. 005', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Jl. Nangela RT.002 RW.009', 'Baros', 'Baros', 'Kota Sukabumi', 'Subsidi', 26423.68, 14664.51, 11149.87, 530.00, 0.00, 242, '10 Tahun 2020', '2020-02-25', 'Pengesahan Perubahan Site Plan No. 34 Tahun 2018', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 90),
(680, 'Diki Darmadi', 'Perum Bumi Purnawira Asri Blok R No. 22 RT.004 RW.005', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Jl. Nangela RT.002 RW.009', 'Baros', 'Baros', 'Kota Sukabumi', 'Subsidi', 26423.68, 15204.51, 11219.17, 530.00, 0.00, 253, '64 Tahun 2021', '2021-08-25', 'Pengesahan Perubahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 90),
(681, 'Budhi Pamuji', 'PCP Blok X No. 13 RT.003 RW.010', 'Cibeureum Hilir', 'Cibeureum', 'Kota Sukabumi', 'Jl. Subangjaya RT.001 RW.006', 'Subangjaya', 'Cikole', 'Kota Sukabumi', 'Subsidi', 8250.00, 4800.00, 3450.78, 160.00, 0.00, 80, '51 Tahun 2021', '2021-06-30', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 91),
(682, 'Rika Hendra Gunasa', 'Kp. Babakan Baru RT.004 RW.001', 'Cikundul', 'Lembursitu', 'Kota Sukabumi', 'Jl. Tata Nugraha Kp. Cicadas Kaler RT.003 RW.005', 'Jayamekar', 'Baros', 'Kota Sukabumi', 'Subsidi', 8497.56, 4620.00, 3877.56, 200.00, 0.00, 77, '89 Tahun 2021', '2021-12-30', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 92),
(683, 'Andyanto Kurniawan', '', '', '', '', 'Jl. Ciseureuh', 'Karang Tengah', 'Gunungpuyuh', 'Kota Sukabumi', 'Subsidi', 75622.85, 39676.72, 35986.15, 3000.00, 0.00, 589, '34 Tahun 2017', '2017-08-30', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 93),
(684, 'Rizky Adhinugroho', 'Jl. Parigi No.1 RT.004 RW.007', 'Cipanengah', 'Lembursitu', 'Kota Sukabumi', 'Kp. Nanggerang RT.002 RW.012', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Subsidi', 2285.73, 1380.00, 905.73, 45.70, 0.00, 23, '29 Tahun 2021', '2021-04-08', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 94),
(685, 'Lintar Agung Gumelar', 'Jl. Sriwidari Gg.VIII No.28 RT.001/RW.003', 'Sriwedari', 'Gunungpuyuh', 'Kota Sukabumi', 'Jl. Proklamasi RT.005/RW.005', 'Jayaraksa', 'Baros', 'Kota Sukabumi', 'Subsidi', 3001.54, 1980.00, 1021.54, 0.00, 0.00, 30, '40 TAHUN 2018', '2018-10-12', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 95),
(686, 'Samuel Prayasta Nuswandika', 'Pondok Bambu RT.004 RW.004', 'Pondok Bambu', 'Duren Sawit', 'Kota Jakarta Timur', 'Jl. Pasar Saptu', 'Lembursitu', 'Lembursitu', 'Kota Sukabumi', 'Subsidi', 48383.00, 19980.00, 28403.00, 900.00, 0.00, 333, '87 Tahun 2021', '2021-12-30', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 96),
(687, 'Teng Ling Ling', 'Jl. A. Yani No.167 RT.004 RW.007', 'Gunungparang', 'Cikole', 'Kota Sukabumi', 'Jl. Caringin Ngumbang', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 32202.75, 12840.00, 19362.75, 650.00, 0.00, 214, '84 Tahun 2021', '2021-12-22', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 97),
(688, 'Yanti Seprimayanti', 'Jl. Sunan Kalijaga No.3 RT.010/RW.015', 'Rawamangun', 'Pulogadung', 'Jakarta Timur', 'Jl. Cibuntu RT 003 RW 001', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 46723.00, 25735.37, 20987.63, 968.00, 0.00, 402, '11 TAHUN 2018', '2018-03-13', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 98),
(689, 'Yanti Seprimayanti', 'Jl. Sunan Kalijaga No. 3 RT 010 RW 015', 'Rawamangun', 'Pulogadung', 'Jakarta Timur', 'Jl. Cibuntu RT 003 RW 001', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 45070.00, 25644.87, 18785.13, 968.00, 0.00, 411, '40 Tahun 2020', '2020-08-31', 'Pengesahan Perubahan Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 98),
(690, 'Jujun Junaedi', 'Jl. Raya Sukalarang No.225', 'Desa Pasirhalang', 'Sukaraja', 'Kabupaten Sukabumi', 'Jl. Cemerlang', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 16099.38, 10277.00, 5822.38, 321.99, 0.00, 0, '02 Tahun 2011', '2011-01-20', 'Pengesahan Baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 99),
(691, 'Cindy Suherti Suarsa', 'Jl. Nangela Kel. Sindangpalay', 'Sindangpalay', '', 'Kota Sukabumi', 'Jl. Widyakrama RT.008 RW.005', 'Sudajayahilir', 'Baros', 'Kota Sukabumi', 'Subsidi', 7497.15, 3420.00, 4077.16, 300.00, 0.00, 57, '18 Tahun 2021', '2021-03-08', 'Pengesahan baru', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 100),
(692, 'Anditya Sapta Rahesthi', 'Jl. Raya Cinangneng No. 294 RT. 003 RW. 006', 'Desa Cibanteng', 'Ciampea', 'Kabupaten Bogor', 'Jl. Palasari Kp. Raweuy Utara RT 003 RW 007', 'Sukakarya', 'Warudoyong', 'Kota Sukabumi', 'Subsidi', 3383.00, 1800.00, 1583.00, 200.00, 0.00, 0, '39 Tahun 2020', '2020-08-18', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 101),
(693, 'Anditya Sapta Rahesthi', 'Jl. Raya Cinangneng No. 294 RT.003 RW.006', 'Desa Cibanteng', 'Ciampea', 'Kabupaten Bogor', 'Jl. Garuda RT.002 RW.002', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 6487.89, 3321.73, 3166.16, 200.00, 0.00, 0, '68 Tahun 2020', '2020-12-29', 'Pengesahan Baru Dinas Pekerjaan Umum, Penataan Ruang, Perumahan, Kawasan Permukiman dan Pertanahan', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 102);
INSERT INTO `permohonan` (`id_perumahan_permohonan`, `nama_pemohon`, `alamat_pemohon`, `kelurahan_pemohon`, `kecamatan_pemohon`, `kota_pemohon`, `alamat_perumahan`, `kelurahan_perumahan`, `kecamatan_perumahan`, `kota_perumahan`, `tipe_perumahan`, `luas_kav`, `luas_efektif`, `luas_fasum`, `luas_tpu`, `luasRTH`, `jumlah_unit`, `nomor_surat_pengesahan`, `tanggal_terbit`, `keterangan`, `berkas_permohonan`, `status_berkas_permohonan`, `berkas_prasarana`, `status_berkas_prasarana`, `berkas_sarana`, `status_berkas_sarana`, `berkas_berita_acara`, `status_berkas_berita_acara`, `berkas_lainnya`, `status_berkas_lainnya`, `status_penyerahan`, `id_perumahan`) VALUES
(694, 'Fahruddin', '', '', '', '', 'Jl. Nangela', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 5082.00, 3049.20, 2032.80, 100.00, 0.00, 53, '38 Tahun 2017', '2017-09-25', 'Pengesahan Baru DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 103),
(695, 'Jumalianto, A', '', '', '', '', 'Jl. Nangela', 'Sindangpalay', 'Cibeureum', 'Kota Sukabumi', 'Subsidi', 15287.28, 9158.65, 5535.57, 340.00, 0.00, 127, '08 Tahun 2017', '2017-02-14', 'DPUPRPKPP', '', 0, '', 0, '', 0, '', 0, '', 0, 0, 104),
(721, 'Budhi Pamuji', 'PCP Blok X No. 13 RT.003 RW.010 Kel. Cibeureum Hilir Kec. Cibeureum', 'Cibeureum Hilir', 'Cikole', 'Sukabumi', 'Jl. Subangjaya RT.001 RW.006 Kel. Subangjaya Kec. Cikole', 'Subangjaya', 'Cikole', 'Sukabumi', 'Subsidi', 8250.00, 4800.00, 3451.00, 160.00, 1486.75, 80, '51 Tahun 2021', '2021-06-30', 'Pengesahan baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 114),
(722, 'Rizky Adhinugroho', 'Jl. Parigi No.1 RT.004 RW.007 Kel. Cipanengah Kec. Lembursitu', 'Cipanengah', 'Lembursitu', 'Sukabumi', 'Kp. Nanggerang RT.002 RW.012 Kel.Lembursitu Kec. Lembursitu', 'Lembursitu', 'Lembursitu', 'Sukabumi', 'Subsidi', 2286.00, 1380.00, 906.00, 46.00, 535.15, 23, '29 Tahun 2021', '2021-08-04', 'Pengesahan Baru', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 115),
(723, 'Samuel Prayasta Nuswandika', 'Pondok Bambu RT.004 RW.004 Kel. Pondok Bambu Kec. Duren Sawit Kota Jakarta Timur', 'Pondok Bambu', 'Duren Sawit', 'Jakarta Timur', 'Jl. Pasar Saptu Kel. Lembursitu Kec. Lembursitu', 'Lembursitu', 'Lembursitu', 'Sukabumi', 'Subsidi', 48383.00, 19980.00, 28403.00, 900.00, 0.00, 333, '87 Tahun 2021', '2021-12-30', 'Pengesahan Baru', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 96),
(724, 'Oki Hermawan Sumedi', 'Jl. R. Syamsudin, SH No.5 RT.006 RW.007', 'Cikole', 'Cikole', 'Sukabumi', 'Jl. Ciseureuh RT.003 RW.005 Kel. Karang Tengah Kec. Gunungpuyuh', 'Karang Tengah', 'Gunungpuyuh', 'Sukabumi', 'Komersil', 5035.00, 2809.00, 2225.99, 0.00, 0.00, 36, '86 Tahun 2021', '2021-12-30', 'Perubahan', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 68),
(725, 'Teng Ling Ling', 'Jl. A. Yani No. 167 RT.004 RW.007 Kel. Gunungparang Kec. Cikole', 'Gunungparang ', 'Cikole', 'Sukabumi', 'Jl. Caringin Ngumbang Kel. Sukakarya Kec. Warudoyong', 'Sukakarya', 'Warudoyong', 'Sukabumi', 'Subsidi', 32203.00, 12840.00, 19363.00, 650.00, 7652.52, 214, '84 Tahun 2021', '2021-12-22', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 118),
(726, 'Mohamad Iqbal', 'Jl. Gunung Karang Residence Blok B No. 11 RT.003 RW.001 Kel. Limusnunggal Kec. Cibeureum', 'Limusnunggal ', 'Cibeureum', 'Sukabumi', 'Jl. Sejahtera RT.002 RW.020 Kel. Dayeuhluhur Kec. Warudoyong ', 'Dayeuhluhur ', 'Warudoyong ', 'Sukabumi', 'Campuran', 32.36, 17.97, 14.39, 650.00, 6950.56, 262, ' 19 Tahun 2021 ', '2021-03-16', 'Pengesahan Perubahan ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 119),
(727, 'Andri Potera', 'Jl. Sedap Malam II No. 18 Taman Yasmin 3 Kel. Curugmekar Kec. Bogor Barat', 'Curugmekar', 'Bogor Barat', 'Bogor', 'Jl. Lingkar Selatan Kel. Limusnunggal Kec. Cibeureum', 'Limusnunggal', 'Cibeureum', 'Sukabumi', 'Komersil', 136.12, 54.19, 79.65, 4450.00, 24580.60, 107, '81 Tahun 2021', '2021-12-10', 'Pengesahan Baru', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 36),
(728, 'Antony Ho', 'Jl. Urip Sumoharjo No. 111 RT.002 RW.005 Kel. Medono Kec. Pekalongan Barat Kota Pekalongan', 'Medono', 'Pekalongan Barat Kota', 'Pekalongan', 'Jl. Rancakadu Kp. Cikaret RT.003 RW.007 Kel. Sindangpalay Kec. Cibeureum', 'Sindangpalay', 'Cibeureum', 'Sukabumi', 'Campuran', 50188.00, 22492.00, 27697.00, 1000.00, 9045.56, 323, '78 Tahun 2021', '2021-11-26', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 121),
(729, 'Luthfi Musyahidin', 'Jl. A. Yani No. 197 RT.004 RW.004 Kel. Kebonjati Kec. Cikole', 'Kebonjati ', 'Cikole', 'Sukabumi', 'Jl. Limusnunggal Kel. Limusnunggal Kec. Cibeureum', 'Limusnunggal', 'Cibeureum', 'Sukabumi', 'Komersil', 4207.00, 2016.00, 2191.00, 100.00, 766.17, 28, '72 Tahun 2021', '2021-10-21', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 55),
(730, 'Ir. Tan Nixsun', 'Tangerang', 'Tangerang', 'Tangerang', 'Tangerang', 'Jl. Garuda Kel. Sindangpalay Kec. Cibeureum', 'Sindangpalay ', 'Cibeureum', 'Sukabumi', 'Komersil', 37770.00, 12985.00, 24785.00, 600.00, 7264.93, 114, '15 Tahun 2021', '2021-02-23', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 69),
(731, 'Rika Hendra Gunasa', 'Kp. Babakan Baru RT.004 RW.001 Kel. Cikundul Kec. Lembursitu', 'Cikundul', 'Lembursitu', 'Sukabumi', 'Jl. Tata Nugraha Kp. Cicadas Kaler RT.003 RW.005 Kel. Jayamekar Kec. Baros', 'Jayamekar', 'Baros', 'Sukabumi', 'Subsidi', 8498.00, 4620.00, 3878.00, 200.00, 1538.35, 77, '89 Tahun 2021', '2021-12-31', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 92),
(732, 'M. Abdul Karim', 'Jl. Nanggeleng RT.001 RW.008 Kel. Nanggeleng Kec. Citamiang', 'Nanggeleng ', 'Citamiang', 'Sukabumi', 'Jl. Raya Baros Kelurahan Jayaraksa Kecamatan Baros', 'Jayaraksa ', 'Baros', 'Sukabumi', 'Komersil', 10123.00, 5214.00, 5140.00, 200.00, 2243.75, 64, '85 Tahun 2021', '2021-12-22', 'Pengesahan Baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 49),
(733, 'Cindy Suherti Suarsa', 'Jl. Nangela Kel. Sindangpalay', 'Sindangpalay', 'Cibeureum', 'Sukabumi', 'Jl. Widyakrama RT.008 RW.005 Kel. Sudajaya Hilir Kec. Baros', 'Sudajaya Hilir', 'Baros', 'Sukabumi', 'Subsidi', 7497.00, 3420.00, 4077.00, 300.00, 1593.16, 57, '18 Tahun 2021', '2021-03-08', 'Pengesahan baru ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 100),
(734, 'Fakhri Nur Ahmad', 'Perumahan Bumi Sariwangi 1 Blok I No. 8B RT.008 RW. 014 Kel. Sariwangi Kecamatan Parongpong Kabupaten Bandung Barat', 'Sariwangi', 'Parongpong', 'Bandung Barat', 'Jl. Sejahtera RT.003 RW.011 Kel. Sukakarya Kec. Warudoyong', 'Sukakarya', 'Warudoyong', 'Sukabumi', 'Komersil', 33046.00, 15679.00, 17367.00, 661.00, 5985.78, 68, '50 Tahun 2021', '2021-06-22', 'Pengesahan Perubahan ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 40),
(735, 'Diki Darmadi', 'Perum Bumi Purnawira Asri Blok R No. 22 RT.004 RW.005 Kel. Lembursitu Kec. Lembursitu', 'Lembursitu ', 'Lembursitu', 'Sukabumi', 'Jl. Nangela RT.002 RW.009 Kel. Baros Kec. Baros', 'Baros', 'Baros', 'Sukabumi', 'Subsidi', 26424.00, 15205.00, 11219.00, 530.00, 4773.55, 253, '64 Tahun 2021', '2021-08-25', 'Pengesahan Perubahan', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 90),
(736, 'Nur Hasan', 'Taman Asri Blok B4 No. 19 RT.002 RW. 014 Kel. Subangjaya Kec. Cikole', 'Subangjaya ', 'Cikole', 'Sukabumi', 'Jl. Pangaritan RT.001 RW.005 Kel. Sindangpalay Kec. Cibeureum', 'Sindangpalay ', 'Cibeureum', 'Sukabumi', 'Komersil', 5013.00, 2875.00, 1940.00, 173.00, 927.90, 45, '17 Tahun 2021', '2021-03-08', 'Pengesahan Perubahan ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 89),
(737, 'Hj. Rani Setiani, SE.', 'Puri Cibeureum Permai I Blok F No.1/2 RT.003 RW.011 Kel. Cibeureum Hilir Kec. Cibeureum', 'Cibeureum Hilir', 'Cibeureum', 'Sukabumi', 'Jl. Sarasa RT.003 RW.005 Kel. Babakan Kec. Cibeureum', 'Babakan', 'Cibeureum', 'Sukabumi', 'Komersil', 5221.00, 2892.00, 4658.00, 106.00, 0.00, 38, '80 Tahun 2021', '2021-12-08', 'Pengesahan Perubahan ', NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 73);

-- --------------------------------------------------------

--
-- Table structure for table `perumahan`
--

CREATE TABLE `perumahan` (
  `id_perumahan` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `perusahaan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_permohonan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `perumahan`
--

INSERT INTO `perumahan` (`id_perumahan`, `nama`, `perusahaan`, `longitude`, `latitude`, `id_permohonan`) VALUES
(1, '', 'Perorang', '', '', 0),
(2, 'Pondok Hijau Regency', 'PT. Graha Karya Utama', '', '', 0),
(3, 'Graha Cikundul Asri (Korpri)', 'PT. Istana Harum Cendana', '', '', 0),
(4, 'Griya Sartika', 'PT. Kusumah Dinata Persada', '', '', 0),
(5, 'Haidar Sentosa Residence', 'PT. Rianmas Sentosa Abadi', '', '', 0),
(6, 'Mutiara Cibeureum Residence', 'PT. Sinar Mutiara Agung', '', '', 0),
(7, 'Cluster Sudajaya Residence', 'CV. Kharisma Santika Persada', '', '', 0),
(8, 'Sriwedari Town House', 'Perorangan', '', '', 0),
(9, 'Gunung Karang Residence', 'Perorangan', '', '', 0),
(10, 'Cluster Ciandam Village', 'Perorangan', '', '', 0),
(11, 'Cipelang Indah Residence', 'Perorangan', '', '', 0),
(12, 'Pakuan Residence', 'Perorangan', '', '', 0),
(13, 'Botanika Sriwidari', 'Perorangan', '', '', 0),
(14, 'The Emerald Residence', 'Perorangan', '', '', 0),
(15, 'Jingga Residence', 'Perorangan', '', '', 0),
(16, 'Subang Jaya Residence 2', 'Perorangan', '', '', 0),
(17, 'Amaranta Residence (dan Ruko)', 'Perorangan', '', '', 0),
(18, 'Andara Residence', 'Perorangan', '', '', 0),
(19, 'Ganesa', 'Perorangan', '', '', 0),
(20, 'Assyifa', 'Perorangan', '', '', 0),
(21, 'Asri Village', 'Perorangan', '', '', 0),
(22, 'Irma Yulandi, S.H.', 'Perorangan', '', '', 0),
(23, 'Tan Le Gak', 'Perorangan', '', '', 0),
(24, 'Ny. Hj. Nyi Elom Romlah', 'Perorangan', '', '', 0),
(25, 'Samsi Resort', 'Perorangan', '', '', 0),
(26, 'Cluster Balandongan Residence (dan Toko)', 'Perorangan', '', '', 0),
(27, 'Sakinah Residence', 'Perorangan', '', '', 0),
(28, 'Benhill Residence', 'Perorangan', '', '', 0),
(29, 'Idod Juhandi', 'Perorangan', '', '', 0),
(30, 'Cluster Grange Park', 'Perorangan', '', '', 0),
(31, 'Subangjaya Residence', 'PT. Alghina Alam Semesta', '', '', 0),
(32, 'Villa Alam Asri', 'PT. Alghina Alam Semesta', '', '', 0),
(33, 'Mahkota Cisarua', 'PT. Amanah Ibu Rama', '', '', 0),
(34, 'Mega Residence Sriwidari', 'PT. Banyu Sejahtera', '', '', 0),
(35, 'Mega Residence', 'PT. Banyu Sejahtera', '', '', 0),
(36, 'Alam Sewarna', 'PT. Botos Amari', '', '', 0),
(37, 'Puri Cibeureum Permai 1', 'PT. Bumi Cipta Harapan Persada', '106.95358', '-6.92324', 0),
(38, 'Puri Cibeureum Permai 2', 'PT. Bumi Cipta Harapan Persada', '106.95581', '-6.92351', 0),
(39, 'Golden Town House', 'PT. Bumi Cipta Harapan Persada', '', '', 0),
(40, 'Grand Cikareo Regency', 'PT. Bumi Sagara Raharja', '', '', 0),
(41, 'Griya Sela Bumi Indah', 'PT. Catur Adidaya', '', '', 0),
(42, 'PT. Daya Utama Perkasa', 'PT. Daya Utama Perkasa', '', '', 0),
(43, 'Qianna Residence', 'PT. Devindo Karya Persada', '', '', 0),
(44, 'Gading Kencana Asri', 'PT. Galih Pratama Suryawisesa', '', '', 0),
(45, 'Taman Genting Puri', 'PT. Genting Puri', '106.95440', '-6.922222', 0),
(46, 'Griya Prana', 'PT. Inti Innovaco', '', '', 0),
(47, 'Griya Prana Estate', 'PT. Inti Innovaco', '106.93912', '-6.91249', 0),
(48, 'Royal Kabandungan Regency', 'PT. Jaya Abadi Regency', '', '', 0),
(49, 'Bellva Residence', 'PT. Kareem Tipar Property', '', '', 0),
(50, 'Kampung Qur\'an', 'PT. Khalifa Bumi Kersa Sadaya', '', '', 0),
(51, 'Sarasa Land', 'PT. Lintang Agung Jaya Utama', '', '', 0),
(52, 'Nirwana Grha', 'PT. Metroprima Artha Nusa', '', '', 0),
(53, 'Perumahan (dan Toko)', 'PT. Mitra Harapan Persada', '', '', 0),
(54, 'Daun Mas Residence', 'PT. Nasyithaa Sukses Mandiri', '', '', 0),
(55, 'Zephyra New Village', 'PT. Nextar Lambang Tiga Enam', '', '', 0),
(56, 'Taman Resik Residence', 'Perorangan', '', '', 0),
(57, 'Taman Resik Residence', 'PT. Pandawalima Putra Reality', '', '', 0),
(58, 'Humanis Residence', 'PT. Pandawalima Putra Reality', '', '', 0),
(59, 'Pesona Gardenia', 'PT. Pantja Putra Pandawa', '', '', 0),
(60, 'Santa City View', 'PT. Pantja Putra Pandawa', '', '', 0),
(61, 'Allila Puri', 'PT. Pilar Sejahtera Abadi', '', '', 0),
(62, 'Alilla Residence', 'PT. Pilar Sejahtera Abadi', '', '', 0),
(63, 'Taman Asri', 'PT. Prakarsa Mitra Mandiri', '', '', 0),
(64, 'Purnawira Asri', 'PT. Prakarsa Mitra Mandiri', '106.90922', '-6.96291', 0),
(65, 'Graha Taman', 'PT. Sanggraha Pelita Sentosa', '', '', 0),
(66, 'Vanama Residence', 'PT. Santosa Karya Lestari', '', '', 0),
(67, 'Kandara Residence', 'PT. Sejahtera Bersama Mas', '', '', 0),
(68, 'Grand Malika', 'PT. Sinergy Global Corp', '', '', 0),
(69, 'Cluster Grand Palay', 'PT. Starsurya Tata Lestari', '', '', 0),
(70, 'Griya Subangjaya', 'PT. Sukabumi Mandiri Maju Mapan', '', '', 0),
(71, 'Cluster Rinjani Residence', '', '', '', 0),
(72, 'Cluster Rinjani', '', '', '', 0),
(73, 'Cluster Rinjani', 'Perorangan', '', '', 0),
(74, 'perumahan', '', '', '', 0),
(75, 'Taman Merbabu Indah', '', '', '', 0),
(76, 'Dandellion Garden', '', '', '', 0),
(77, 'Cikundul Garden', 'CV. Cempaka Berkah Rizky', '', '', 0),
(78, 'Cikundul Residence', 'Perorangan', '106.91027', '-6.97523', 0),
(79, 'Griya Sentosa', 'Perorangan', '', '', 0),
(80, 'Cemerlang Mansion', '', '', '', 0),
(81, 'Resik Residence', 'PT. Pandawalima Lima Putra Reality', '', '', 0),
(82, 'Shifa Residence', 'PT. Alrifara Mandiri Pratama', '106.90922', '-6.97523', 0),
(83, 'Shifa Residence 2', 'PT. Alrifara Mandiri Pratama', '', '', 0),
(84, 'Lamping Residance', 'PT. Arya Adi Widhayaka', '', '', 0),
(85, 'Sindangpalay Asri', 'PT. Ciawi Permai Star Abadi', '', '', 0),
(86, 'Rahesta Cemerlang', 'PT. Cosra Arthomoro', '', '', 0),
(87, 'Rahesta Residence', 'PT. Cosra Arthomoro', '', '', 0),
(88, 'Rahesta Cemerlang II', 'PT. Cosra Arthomoro', '', '', 0),
(89, 'Pesona Sindangpalay Asri', 'PT. Daffa Putra Pradana', '', '', 0),
(90, 'Sapu Lidi Residence', 'PT. Das Putra Gemilang', '', '', 0),
(91, 'Kanahaya City', 'PT. Duta Kanahaya Sawargi', '', '', 0),
(92, 'Griya Lembayung Regency', 'PT. Graha Properti Utama', '', '', 0),
(93, 'Karang Kencana', 'PT. Indo Bangun Gemilang', '', '', 0),
(94, 'Bumi Nanggerang Mandiri', 'PT. Inti Deraya Sejahtera Utama', '', '', 0),
(95, 'Pesona Cikundul', 'PT. Kamila Global Mandiri', '', '', 0),
(96, 'Graha Situ Indah', 'PT. Mahadewa Putra Kencana', '', '', 0),
(97, 'Benteng Residence', 'PT. Maju Mandiri Sukabumi', '', '', 0),
(98, 'Pesona Mayanti', 'PT. Mayanti Jaya Mustika', '', '', 0),
(99, 'Cemerlang Permai', 'PT. Nusantara Persada Sukabumi', '', '', 0),
(100, 'Kanigara Garden', 'PT. Pilar Ksatria Tidar Nusantara', '', '', 0),
(101, 'Griya Rahesthi', 'PT. Rahesthi Artha Anggana', '', '', 0),
(102, 'Rahesthi Residence', 'PT. Rahesthi Artha Anggana', '', '', 0),
(103, 'Pesona Shynala II', 'PT. Rahman Pradana', '', '', 0),
(104, 'Villa Dream Valley', 'Villa Dream Valley', '', '', 0),
(114, 'Kanahaya City', 'PT. Duta Kanahaya Sawargi', '106.948782', '-6.908453716', 0),
(115, 'Bumi Nanggerang Mandiri', 'PT. Inti Deraya Sejahtera Utama', '106.8879137', '-6.968254192', 0),
(116, 'Graha Situ Indah', 'PT. Mahadewa Putra Kencana', '106.8757974', '-6.968082845', 0),
(117, 'Grand Malika', 'PT. Sinergy Global Corp', '106.9076166', '-6.907713853', 0),
(118, 'Benteng Residence', 'PT. Maju Mandiri Sukabumi', '106.9102704', '-6.927750355', 0),
(119, 'Griya Sartika', 'PT. Kusumah Dinata Persada', '106.9095131', '-6.945033327', 0),
(120, 'Alam Sewarna', 'PT. Botos Amari', '106.9373542', '-6.951040569', 0),
(121, 'Mutiara Cibeureum Residence', 'PT. Sinar Mutiara Agung', '106.9389079', '-6.945315227', 0),
(122, 'Zephyra New Village', 'PT. Nextar Lambang Tiga Enam', '106.9389079', '-6.945315227', 0),
(123, 'Cluster Grand Palay', 'PT. Starsurya Tata Lestari', '106.9469761', '-6.956768236', 0),
(124, 'Griya Lembayung Regency', 'PT. Graha Properti Utama', '106.9253679', '-6.955444711', 0),
(125, 'Bellva Residence', 'PT. Kareem Tipar Property', '106.9350703', '-6.963974684', 0),
(126, 'Kanigara Garden', 'PT. Pilar Ksatria Tidar Nusantara', '106.921551', '-6.956792222', 0),
(127, 'Grand Cikareo Regency', 'PT. Bumi Sagara Raharja', '106.9092615', '-6.941884766', 0),
(128, 'Sapu Lidi Residence', 'PT. DAS Putra Gemilang', '106.9514748', '-6.9636513', 0),
(129, 'Pesona Sindangpalay Asri', 'PT. Daffa Putra Pradana', '106.9416103', '-6.959006087', 0),
(130, 'Cluster Rinjani', 'Hj. Rani Setiani  SE.', '106.9518099', '-6.940607698', 0),
(132, 'Golden Nirwana Regency', 'PT. Bumi Rajawali Sentosa', '106,914438202', '-6,95681778393', 0),
(133, 'Mega Residence', 'PT. Banyu Sejahtera', '106,926698016', '-6,91304166925', 0),
(134, 'Qianna Residence 2', 'PT. Setia Budi Persada', '106,946173387', '-6,93586105942', 0),
(135, 'The Emerald Residence', 'PT. Rajawali Muda Karya Persada', '106,914213372', '-6,93249176686', 0),
(136, 'Mekar Jaya Asri 4', 'PT. Raytama Bintang Arbani', '106,924432525', '-6,95792677272', 0),
(137, 'Anyelir Residence', 'PT. Catur Wira Sembada', '106,924432525', '-6,94057268128', 0),
(138, 'Graha Situ Indah', 'PT. Mahadewa Putra Kencana', '106,875797389', '-6,9680828454', 0),
(139, 'Golden Nirwana Regency', 'PT. Bumi Rajawali Sentosa', '106,915663014', '-6,95815087223', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rpp`
--

CREATE TABLE `rpp` (
  `id` int(11) NOT NULL,
  `TanggalSuratPermohonan` date NOT NULL,
  `TanggalDisposisi` date NOT NULL,
  `NamaPemohon` varchar(100) NOT NULL,
  `Lokasi` varchar(255) NOT NULL,
  `KoordinatX` varchar(30) NOT NULL,
  `KoordinatY` varchar(30) NOT NULL,
  `nib` varchar(10) NOT NULL,
  `TipeHak` varchar(20) NOT NULL,
  `luas` varchar(10) NOT NULL,
  `rpp` varchar(100) NOT NULL,
  `kawasan` varchar(50) NOT NULL,
  `NomorSuratTugas` varchar(50) NOT NULL,
  `TanggalSuratTugas` date NOT NULL,
  `NomorSKRK` varchar(50) NOT NULL,
  `TanggalSKRK` date NOT NULL,
  `ket` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rpp`
--

INSERT INTO `rpp` (`id`, `TanggalSuratPermohonan`, `TanggalDisposisi`, `NamaPemohon`, `Lokasi`, `KoordinatX`, `KoordinatY`, `nib`, `TipeHak`, `luas`, `rpp`, `kawasan`, `NomorSuratTugas`, `TanggalSuratTugas`, `NomorSKRK`, `TanggalSKRK`, `ket`) VALUES
(1, '2024-01-18', '2024-01-18', 'Elsa Sinta Yulia', 'Jl. Garuda Kelurahan Baros Kecamatan Baros', '106.947247', '-6.958172', '506', 'Hak Milik', '149', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/181/V/6/DPUTR/2024', '2024-01-19', 'PU.06.02/266/V/6/DPUTR/2024', '2024-01-31', 'Pembangunan Dapat Dilaksanakan'),
(2, '2024-01-22', '2024-01-22', 'Hj.Euis', 'Jl. Lamping RT.003/RW.005 Kelurahan Gedongpanjang Kecamatan Citamiang', '106.928993', '-6.948521', '1944', 'Hak Milik', '247', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/204/V/6/DPUTR/2024', '2024-01-24', 'PU.06.02/238/V/6/DPUTR/2024', '2024-01-29', 'Pembangunan Dapat Dilaksanakan'),
(3, '2024-01-22', '2024-01-22', 'Iceu Hertinovita', 'Jl. Lamping RT.003/RW.005 Kelurahan Gedongpanjang Kecamatan Citamiang', '106.929158', '-6.948484', '1327', 'Hak Milik', '120', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/203/V/6/DPUTR/2024', '2024-01-24', 'PU.06.02/239/V/6/DPUTR/2024', '2024-01-24', 'Pembangunan Dapat Dilaksanakan'),
(4, '2024-01-12', '2024-01-12', 'Lilis Rosmiati', 'Blok Babakan Bandung RT.001/RW.003 Kelurahan Subangjaya Kecamatan Cikole', '106.943392', '-6.924731', '538', 'Hak Milik', '140', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/0127/V/6/DPUTR/2024', '2024-01-15', 'PU.06.02/169/V/6/DPUTR/2024', '2024-01-18', 'Pembangunan Dapat Dilaksanakan'),
(5, '2024-01-10', '2024-01-10', 'Malia Surjani', 'Jl. Sejahtera Cikareo RT.001/RW.020 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.909859', '-6.941244', '2758', 'Hak Milik', '1650', 'Gudang dan Unit Pengolahan', 'Perdagangan dan Jasa, Kawasan Perlindungan Setempa', 'KP.06.01/0106/V/6/DPUTR/2024', '2024-01-11', 'PU.06.02/196/V/6/DPUTR/2024', '2024-01-23', 'Pembangunan Hanya Dapat Dilaksanakan pada Zona Perdagangan dan Jasa'),
(6, '2024-01-10', '2024-01-10', 'Malia Surjani', 'Jl. Sejahtera Cikareo RT.001/RW.020 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.90962', '-6.94119', '2759', 'Hak Milik', '650', 'Gudang dan Unit Pengolahan', 'Kawasan Perdagangan dan Jasa serta Kawasan Perlind', 'KP.06.01/0106/V/6/DPUTR/2024', '2024-01-11', 'PU.06.02/196/V/6/DPUTR/2024', '2024-01-23', 'Pembangunan Hanya Dapat Dilaksanakan pada Zona Perdagangan dan Jasa'),
(7, '2024-01-08', '2024-01-08', 'Roro Arumriasari Artawinata, S.E.', 'Perum BTN Sudajaya Hilir RT.003/RW.006 Kelurahan Jayaraksa Kecamatan Baros', '106.931135', '-6.953352', '2515', 'Hak Milik', '96', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/0080/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/139/V/6/DPUTR/2024', '2024-01-16', 'Pembangunan Dapat Dilaksanakan'),
(8, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.910774', '-6.927004', '9970', 'Hak Milik', '1788', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(9, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.911035', '-6.926717', '5859', 'Hak Milik', '1035', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(10, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.911241', '-6.926294', '9973', 'Hak Milik', '1678', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(11, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.911081', '-6.925952', '9972', 'Hak Milik', '2890', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(12, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.911345', '-6.925725', '9974', 'Hak Milik', '420', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(13, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.910913', '-6.925346', '9977', 'Hak Milik', '784', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(14, '2024-01-08', '2024-01-08', 'Teng Ling Ling', 'Caringin Ngumbang Kelurahan Sukakarya Kecamatan Warudoyong', '106.910852', '-6.924953', '9978', 'Hak Milik', '313', 'Perumahan', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota dan K', 'KP.06.01/0081/V/6/DPUTR/2024', '2024-01-09', 'PU.06.02/185/V/6/DPUTR/2024', '2024-01-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(15, '2024-01-16', '2024-01-16', 'Uky Subagya, S.T', 'Sudajaya RT.001/RW.003 Kelurahan Jayaraksa Kecamatan Baros', '106.932129', '-6.954454', '1406', 'Hak Milik', '91', 'Rumah Tinggal', 'Kawasan Permukiman dan Kawasan Tanaman Pangan', 'KP.06.01/141/V/6/DPUTR/2024', '2024-01-16', 'PU.06.02/255/V/6/DPUTR/2024', '2024-01-30', 'Pembangunan Hanya Dapat Dilaksanakan pada Zona Perumahan'),
(16, '2024-02-07', '2024-02-07', 'Afriyanti Nurmayasari', 'Jl. Benteng RT.001/RW.002 Kelurahan Benteng Kecamatan Warudoyong', '106.915222', '-6.923474', '2354', 'Hak Milik', '175', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/345/V/6/DPUTR/2024', '2024-02-12', 'PU.06.02/402/V/6/DPUTR/2024', '2024-02-16', 'Pembangunan Dapat Dilaksanakan'),
(17, '2024-01-25', '2024-01-25', 'Asep Wahyudi', 'Jl. Kibitay RT.003/RW.007 Kelurahan Situmekar Kecamatan Lembursitu', '106.895587', '-6.968537', '2982', 'Kosong', '442672', 'Home Industri Spare Part Mobil', 'Kawasan Permukiman', 'KP.06.01/237/V/6/DPUTR/2024', '2024-01-29', 'PU.06.02/338/V/6 DPUTR/2024', '2024-02-07', 'Pembangunan Dapat Dilaksanakan'),
(18, '2024-01-09', '2024-01-22', 'Dindin Karyadi', 'Jl. Mesjid RT.003/RW.004 Kelurahan Gunungparang Kecamatan Cikole', '106.925165', '-6.919965', '1378', 'Hak Milik', '140', 'Kios dan Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/205/V/6/DPUTR/2024', '2024-01-24', 'PU.06.02/309/V/6/DPUTR/2024', '2024-02-05', 'Pembangunan Dapat Dilaksanakan'),
(19, '2024-02-06', '2024-02-07', 'Firman Mawardi', 'Jl. H. Hamid RT.001/RW.001 Kelurahan Sindangpalay Kecamatan Cibeureum', '106.951575', '-6.955669', '4454', 'Kosong', '14450', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/344/V/6/DPUTR/2024', '2024-02-12', 'PU.06.02/401/V/6/DPUTR/2024', '2024-02-16', 'Pembangunan Dapat Dilaksanakan'),
(20, '2024-02-20', '2024-02-20', 'H. Makfud', 'Jl. Titiran No.24 RT.001/RW.001 Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.925678', '-6.913381', '327', 'Hak Milik', '229', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/444/V/6/DPUTR/2024', '2024-02-21', 'PU.06.02/516/V/6/DPUTR/2024', '2024-02-28', 'Pembangunan Dapat Dilaksanakan'),
(21, '2024-02-15', '2024-02-15', 'Ideh Komalasari (CV. Intan Jaya Abadi)', 'Jl. Merdeka TPSA KM.6 Kp. Saluyu Kelurahan Situmekar Kecamatan Lembursitu', '106.899004', '-6.971251', '2885', 'Hak Milik', '4020', 'Peternakan Ayam Petelur', 'Kawasan Permukiman', 'KP.06.01/411/V/6/DPUTR/2024', '2024-02-19', 'PU.06.02/534/V/6/DPUTR/2024', '2024-02-29', 'Pembangunan Dapat Dilaksanakan'),
(22, '2024-02-12', '2024-02-12', 'Isabel Gunarto', 'Jl. Suryakencana Kelurahan Cikole Kecamatan Cikole', '106.933793', '-6.91227', '939', 'Hak Milik', '520', 'Playground dan Cafe', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/365/V/6/DPUTR/2024', '2024-02-13', 'PU.06.02/498/V/6/DPUTR/2024', '2024-02-26', 'Pembangunan Dapat Dilaksanakan'),
(23, '2024-01-31', '2024-01-31', 'Istiyani', 'Jl. Cijambe RT.001/RW.009 Kelurahan Sukakarya Kecamatan Warudoyong', '106.906857', '-6.930858', '8434', 'Kosong', '737', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/298/V/6/DPUTR/2024', '2024-02-02', 'PU.06.02/379/V/6/DPUTR/2024', '2024-02-15', 'Pembangunan Dapat Dilaksanakan'),
(24, '2024-02-12', '2024-02-12', 'Ivan Refdinal', 'Jl. Pelabuhan ll No. 63 A RT.006/RW.002 Kelurahan Tipar Kecamatan Citamiang', '106.92674', '-6.927085', '371', 'Hak Milik', '201', 'Klinik', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/353/V/6/DPUTR/2024', '2024-02-12', 'PU.06.02/497/V/6/DPUTR/2024', '2024-02-26', 'Pembangunan Dapat Dilaksanakan'),
(25, '2024-01-22', '2024-01-22', 'Mohamad Yasir Fadlan Husein', 'Jl. Blok Salakaso RT.001/RW.003 Kelurahan Babakan Cibeureum Kecamatan Cibeureum', '106.956413', '-6.927428', '4812', 'Kosong', '230', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/206/V/6/DPUTR/2024', '2024-01-24', 'PU.06.02/308/V/6/DPUTR/2024', '2024-02-05', 'Pembangunan Dapat Dilaksanakan'),
(26, '2024-02-23', '2024-02-23', 'Roma Rizky Elhadi', 'Gg. Gelatik RT.011/RW.004 Kelurahan Gunung Puyuh Kecamatan Gunungpuyuh', '106.918962', '-6.911107', '1436', 'Hak Milik', '100', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/481/V/6/DPUTR/2024', '2024-02-26', 'PU.06.02/526/V/6/DPUTR/2024', '2024-02-29', 'Pembangunan Dapat Dilaksanakan'),
(27, '2024-02-19', '2024-02-19', 'Ruben Aldo Hasonangan Simanjuntak', 'Jl. RH. Didi Sukardi Kelurahan Gedongpanjang Kecamatan Citamiang', '106.933612', '-6.943399', '2327', 'Hak Milik', '148', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/443/V/6/DPUTR/2024', '2024-02-21', 'PU.06.02/515/V/6/DPUTR/2024', '2024-02-28', 'Pembangunan Dapat Dilaksanakan'),
(28, '2024-02-16', '2024-02-19', 'Seung Il Ryu', 'Jl. Lingkar Selatan (Letkol Eddie Soekardi) Kelurahan Jayaraksa Kecamatan Baros', '106.931071', '-6.950572', '906', 'Hak Milik', '681', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/421/V/6/DPUTR/2024', '2024-02-19', 'PU.06.02/532/V/6/DPUTR/2024', '2024-02-29', 'Pembangunan Dapat Dilaksanakan'),
(29, '2024-01-31', '2024-01-31', 'Sri Hartati', 'Jl. Cemerlang RT.004/RW.010 Kelurahan Sukakarya Kecamatan Warudoyong', '106.905203', '-6.932543', '5210', 'Hak Milik', '612', 'Gudang', 'Kawasan Permukiman', 'KP.06.01/300/V/6/DPUTR/2024', '2024-02-02', 'PU.06.02/359/V/6/DPUTR/2024', '2024-02-12', 'Pembangunan Dapat Dilaksanakan'),
(30, '2024-02-12', '2024-02-12', 'Yuniarti Mertjusuar', 'JL. R. E. Martadinata, Laks RT.005/RW.006 Kelurahan Kebonjati Kecamatan Cikole', '106.935333', '-6.92071', '917', 'Hak Milik', '56', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/352/V/6/DPUTR/2024', '2024-02-12', 'PU.06.02/380/V/6/DPUTR/2024', '2024-02-15', 'Pembangunan Dapat Dilaksanakan'),
(31, '2024-03-25', '2024-03-25', 'Adi Mulyono', 'Jl. Pramuka RT.005/RW.005 Kelurahan Gedongpanjang Kecamatan Citamiang', '106.927113', '-6.944929', '2096', 'Hak Milik', '1050', 'Menara Telekomunikasi', 'Kawasan Permukiman', 'KP.06.01/847/V/6/DPUTR/2024', '2024-03-25', 'PU.06.02/918/V/6/DPUTR/2024', '2024-03-28', 'Pembangunan Dapat Dilaksanakan'),
(32, '2024-03-18', '2024-03-19', 'Alvi Nugraha Pradana Putra', 'Pesona Limusnunggal Blok 003 Kelurahan Limusnunggal kecamatan Cibeureum', '106.940175', '-6.944245', '1298', 'Hak Milik', '151', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/800/V/6/DPUTR/2024', '2024-03-20', 'PU.06.02/918/V/6/DPUTR/2024', '2024-03-28', 'Pembangunan Dapat Dilaksanakan'),
(33, '2024-03-15', '2024-03-19', 'Citra Juwita', 'Blok Caringin Ngumbang RT.001/RW.006 Kelurahan Sukakarya Kecamatan Warudoyong', '106.909615', '-6.929419', '363', 'Hak Milik', '216', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/801/V/6/DPUTR/2024', '2024-03-20', 'PU.06.02/897/V/6/DPUTR/2024', '2024-03-26', 'Pembangunan Dapat Dilaksanakan'),
(34, '2024-03-13', '2024-03-13', 'Dhenda Subagja H', 'Puri Cibeureum Permai Jl. Semeru Blok.08 No.15 RT.002/RW.010 Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.954116', '-6.923798', '273', 'Hak Milik', '106', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/767/V/6/DPUTR/2024', '2024-03-15', 'PU.06.02/820/V/6/DPUTR/2024', '2024-03-21', 'Pembangunan Dapat Dilaksanakan'),
(35, '2024-03-21', '2024-03-22', 'Eming', 'Kp. Liung Tutut RT.003/RW.003 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.914459', '-6.932295', '3508', 'Hak Milik', '248', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/843/V/6/DPUTR/2024', '2024-03-25', 'PU.06.02/848/V/6/DPUTR/2024', '2024-03-25', 'Pembangunan Dapat Dilaksanakan'),
(36, '2024-03-01', '2024-03-01', 'Herman Jaya', 'Jl. Jend. A. Yani No.315 Kelurahan Kebonjati Kecamatan Cikole', '106.935089', '-6.922983', ' ', 'Hak Milik', '75', 'Ruko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/564/V/6/DPUTR/2024', '2024-03-04', 'PU.06.02/729/V/6/DPUTR/2024', '2024-03-13', 'Pembangunan Dapat Dilaksanakan'),
(37, '2024-02-29', '2024-02-29', 'Ikrom', 'Jl. Pelabuhan RT.007/RW.002 Kelurahan Cikondang Kecamatan Citamiang', '106.92301', '-6.941475', '1111', 'Hak Milik', '37', 'Tempat Usaha', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/531/V/6/DPUTR/2024', '2024-02-29', 'PU.06.02/728/V/6/DPUTR/2024', '2024-03-13', 'Pembangunan Dapat Dilaksanakan'),
(38, '2024-03-13', '2024-03-13', 'Inawati', 'Gg. Cereme RT.004/RW.005 Kelurahan Kebonjati Kecamatan Cikole', '106.933196', '-6.921765', ' ', ' ', '0', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/766/V/6/DPUTR/2024', '2024-03-15', 'PU.06.02/821/V/6/DPUTR/2024', '2024-03-21', 'Pembangunan Dapat Dilaksanakan'),
(39, '2024-02-26', '2024-02-28', 'Meking Musa', 'Jl. Stadion Benteng RT.001/RW.005 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.920063', '-6.931353', '796', 'Hak Milik', '153', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/528/V/6/DPUTR/2024', '2024-02-29', 'PU.06.02/730/V/6/DPUTR/2024', '2024-03-13', 'Pembangunan Dapat Dilaksanakan'),
(40, '2024-03-18', '2024-03-20', 'Rasona Sunara Akbar', 'Jl. Taman Bahagia Gang Famili RT.001/RW.001 Kelurahan Benteng Kecamatan Warudoyong', '106.916139', '-6.927306', '1860', 'Hak Milik', '211', 'Rumah Kontrakan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/805/V/6/DPUTR/2024', '2024-03-20', 'PU.06.02/806/V/6/DPUTR/2024', '2024-03-20', 'Pembangunan Dapat Dilaksanakan'),
(41, '2024-02-29', '2024-02-29', 'Sarmudin', 'Bukit Prana Babakan Jampang RT.001/RW.018 Kelurahan Cisarua Kecamatan Cikole', '106.941987', '-6.908935', '829', 'Hak Milik', '355', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/530/V/6/DPUTR/2024', '2024-02-29', 'PU.06.02/727/V/6/DPUTR/2024', '2024-03-13', 'Pembangunan Dapat Dilaksanakan'),
(42, '2024-03-25', '2024-03-26', 'Ade Riyanto', 'Perum Nirwana Graha Blok B RT.003/RW.010 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.917496', '-6.938054', '2127', 'Hak Milik', '150', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/904/V/6/DPUTR/2024', '2024-03-27', 'PU.06.02/1011/V/6/DPUTR/2024', '2024-04-05', 'Pembangunan Dapat Dilaksanakan'),
(43, '2024-03-25', '2024-03-26', 'Ade Riyanto', 'Perum Nirwana Graha Blok B RT.003/RW.010 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.917496', '-6.938054', '541', 'Hak Guna Bangunan', '23706', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/904/V/6/DPUTR/2024', '2024-03-27', 'PU.06.02/1011/V/6/DPUTR/2024', '2024-04-05', 'Pembangunan Dapat Dilaksanakan'),
(44, '2024-04-24', '2024-04-24', 'Aris Maulana', 'Kp. Baru RT.001/RW.008 Kelurahan Cikundul Kecamatan Lembursitu', '106.9169', '-6.973127', '2327', 'Hak Milik', '745', 'Pengelolaan Limbah', 'Kawasan Perdagangan dan jasa, Kawasan Permukiman d', 'KP.06.01/1105/V/6/DPUTR/2024', '2024-04-24', 'PU.06.02/1161/V/6/DPUTR/2024', '2024-04-30', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa dan Kawasan Permukiman'),
(45, '2024-04-01', '2024-04-02', 'Asep Mulyana', 'Jl. Lingkungan Kelurahan Lembursitu Kecamatan Lembursitu', '106.877417', '-6.970371', '4364', 'Hak Milik', '1632', 'Perumahan', 'Kawasan Permukiman', 'KP.06.01/993/V/6/DPUTR/2024', '2024-04-03', 'PU.06.02/1014/V/6/DPUTR/2024', '2024-04-05', 'Pembangunan Dapat Dilaksanakan'),
(46, '2024-04-16', '2024-04-19', 'Bachtiar Rifai', 'Jl. Garuda Caringin RT.003/RW.010 Kelurahan Baros Kecamatan Baros', '106.947354', '-6.958135', '1584', 'Hak Milik', '258', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1080/V/6/DPUTR/2024', '2024-04-22', 'PU.06.02/1092/V/6/DPUTR/2024', '2024-04-23', 'Pembangunan Dapat Dilaksanakan'),
(47, '2024-04-24', '2024-04-25', 'Elsa Lawati', 'Jl. Gudang RT.001/RW.005 Kelurahan Kebonjati Kecamatan Cikole', '106.934218', '-6.922129', '166', 'Hak Milik', '664', 'Pencucian Mobil Dan Kafe', 'Kawasan Permukiman', 'KP.06.01/1117/V/6/DPUTR/2024', '2024-04-25', 'PU.06.02/1142/V/6/DPUTR/2024', '2024-04-29', 'Pembangunan Dapat Dilaksanakan'),
(48, '2024-03-21', '2024-03-21', 'Galih Marelia Anggraeni, S.F., Apt', 'Jl. Perpustakaan Kelurahan Cikole Kecamatan Cikole', '106.931093', '-6.917407', '41', 'Hak Pakai', '1410', 'Pembangunan Gedung', 'Kawasan Permukiman', 'KP.06.01/842/V/6/DPUTR/2024', '2024-03-25', 'PU.06.02/1012/V/6/DPUTR/2024', '2024-04-05', 'Pembangunan Dapat Dilaksanakan'),
(49, '2024-03-25', '2024-03-26', 'Hikmat Taufik, S.M', 'Jl. Ciandam Kelurahan Babakan Kecamatan Cibeureum', '106.953324', '-6.937359', '3874', 'Hak Milik', '2992', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/919/V/6/DPUTR/2024', '2024-03-28', 'PU.06.02/921/V/6/DPUTR/2024', '2024-03-28', 'Pembangunan Dapat Dilaksanakan'),
(50, '2024-03-28', '2024-03-28', 'Hj. Megi Novalia, S.IP', 'Komplek Dayuharta RT.002/RW.004 Kelurahan Keramat Kecamatan Gunungpuyuh', '106.918737', '-6.905824', '2172', 'Hak Milik', '72', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/996/V/6/DPUTR/2024', '2024-04-02', 'PU.06.02/1013/V/6/DPUTR/2024', '2024-04-05', 'Pembangunan Dapat Dilaksanakan'),
(51, '2024-04-24', '2024-04-24', 'Lim Winady', 'Jl. Proklamasi Kelurahan Cikundul Kecamatan Lembursitu', '106.907829', '-6.963379', '227', 'Hak Milik', '2100', 'Rumah Makan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1106/V/6/DPUTR/2024', '2024-04-24', 'PU.06.02/1159/V/6/DPUTR/2024', '2024-04-30', 'Pembangunan Dapat Dilaksanakan'),
(52, '2024-04-17', '2024-04-18', 'Madna', 'Perum Asri Village 3 N.06 Kelurahan Karamat Kecamatan Gunungpuyuh', '106.918632', '-6.905326', '543', 'Hak Milik', '122', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1067/V/6/DPUTR/2024', '2024-04-04', 'PU.06.02/1108/V/6/DPUTR/2024', '2024-04-24', 'Pembangunan Dapat Dilaksanakan'),
(53, '2024-04-24', '2024-04-25', 'Mila Karmilasari', 'Jl. Limusnunggal RT.001/RW.007 Kelurahan Limusnunggal Kecamatan Cibeureum', '106.938513', '-6.945377', '3115', 'Hak Milik', '3626', 'Perumahan', 'Kawasan Permukiman', 'KP.06.01/1118/V/6/DPUTR/2024', '2024-04-25', 'PU.06.02/1162/V/6/DPUTR/2024', '2024-04-30', 'Pembangunan Dapat Dilaksanakan'),
(54, '2024-04-24', '2024-04-24', 'Mira Hafiedz Suhendra', 'Jl. Lingkar Selatan Kp. Ciendog RT.004/RW.018 Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.914578', '-6.945469', '6828', 'Hak Milik', '674', 'Klinik dan Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1115/V/6/DPUTR/2024', '2024-04-25', 'PU.06.02/1155/V/6/DPUTR/2024', '2024-04-30', 'Pembangunan Dapat Dilaksanakan'),
(55, '2024-03-28', '2024-04-02', 'Muhamad Ashidiqi Aulia Rahman', 'Jl. Gudang RT.001/RW.005 Kelurahan Kebonjati Kecamatan Cikole', '106.917728', '-6.920715', '749', 'Hak Milik', '530', 'Rumah Makan', 'Kawasan Permukiman', 'KP.06.01/965/V/6/DPUTR/2024', '2024-04-02', 'PU.06.02/996/V/6/DPUTR/2024', '2024-04-04', 'Pembangunan Dapat Dilaksanakan'),
(56, '2024-04-22', '2024-04-23', 'Nina Ruslinawati', 'Jl. Pasir Mulus No.84 RT.004/RW.007 Kelurahan Nanggeleng Kecamatan Citamiang', '106.935956', '-6.938078', '4052', 'Hak Milik', '139', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1091/V/6/DPUTR/2024', '2024-04-23', 'PU.06.02/1158/V/6/DPUTR/2024', '2024-04-30', 'Pembangunan Dapat Dilaksanakan'),
(57, '2024-04-25', '2024-04-25', 'Abelya Safitri', 'Jl. Karamat RT.003/RW.004 Kelurahan Karamat Kecamatan Gunungpuyuh', '106.916596', '-6.908125', '2206', 'Hak Milik', '83', 'Rumah Tinggal', 'Kawasan Tanaman Pangan', 'KP.06.01/1119/V/6/DPUTR/2024', '2024-04-25', 'PU.06.02/1138/V/6/DPUTR/2024', '2024-04-29', 'Pembangunan Tidak Dapat Dilaksanakan'),
(58, '2024-05-14', '2024-05-15', 'Ari Permana', 'Jl. Lingkar Selatan RT.001/RW.005 Kelurahan Babakan Kecamatan Cibeureum', '106.952055', '-6.937123', '4272', 'Hak Milik', '160', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1333/V/6/DPUTR/2024', '2024-05-16', 'PU.06.02/1297/V/6/DPUTR/2024', '2024-05-17', 'Pembangunan Dapat Dilaksanakan'),
(59, '2024-05-14', '2024-05-15', 'Ari Permana', 'Jl. Lingkar Selatan RT.001/RW.005 Kelurahan Babakan Kecamatan Cibeureum', '106.952055', '-6.937123', '3669', 'Kosong', '155', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1333/V/6/DPUTR/2024', '2024-05-16', 'PU.06.02/1297/V/6/DPUTR/2024', '2024-05-17', 'Pembangunan Dapat Dilaksanakan'),
(60, '2024-05-20', '2024-05-20', 'Halimah Nurani', 'Gg. Kaswari No.17 Kelurahan Selabatu Kecamatan Cikole', '106.931053', '-6.911635', '1876', 'Hak Milik', '60', 'Rumah Tinggal dan Tempat Usaha', 'Kawasan Permukiman', 'KP.06.01/1312/V/6/DPUTR/2024', '2024-05-20', 'PU.06.02/1409/V/6/DPUTR/2024', '2024-05-31', 'Pembangunan Dapat Dilaksanakan'),
(61, '2024-05-14', '2024-05-15', 'Hj. Siti Nurhayati', 'Jl. Lingkar Selatan RT.001/RW.005 Kelurahan Babakan Kecamatan Cibeureum', '106.951881', '-6.937257', '2499', 'Hak Milik', '395', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1334/V/6/DPUTR/2024', '2024-05-16', 'PU.06.02/1295/V/6/DPUTR/2024', '2024-05-17', 'Pembangunan Dapat Dilaksanakan'),
(62, '2024-05-22', '2024-05-22', 'Irpan Maolana', 'Kp. Limusnunggal RT.004/RW.006 Kelurahan Limusnunggal Kecamatan Cibeureum', '106.942663', '-6.941814', '4201', 'Hak Guna Bangunan', '141', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1356/V/6/DPUTR/2024', '2024-05-27', 'PU.06.02/1411/V/6/DPUTR/2024', '2024-05-31', 'Pembangunan Dapat Dilaksanakan'),
(63, '2024-05-07', '2024-05-07', 'Merry Heumasse', 'Kp. Babakan Jampang RT.001/RW.018 Kelurahan Cisarua Kecamatan Cikole', '106.941622', '-6.909161', '445', 'Hak Milik', '163', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1244/V/6/DPUTR/2024', '2024-05-08', 'PU.06.02/1452/V/6/DPUTR/2024', '2024-06-04', 'Pembangunan Dapat Dilaksanakan'),
(64, '2024-05-15', '2024-05-15', 'Peni Pahlawanda (PT. Vita Medika LAB)', 'Jl. Suryakencana No.4 RT.003/RW.005 Kelurahan Gunungparang Kecamatan Cikole', '106.928308', '-6.919242', '865', 'Hak Milik', '491', 'Administrasi Perizinan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1314/V/6/DPUTR/2024', '2024-05-16', 'PU.06.02/1296/V/6/DPUTR/2024', '2024-05-17', 'Pembangunan Dapat Dilaksanakan'),
(65, '2024-05-28', '2024-05-28', 'Pramanik Gantini', 'Jl. Sudajaya Kelurahan Jayaraksa Kecamatan Baros', '106.933746', '-6.953288', '1330', 'Hak Milik', '68', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1378/V/6/DPUTR/2024', '2024-05-28', 'KP.06.02/1520/V/6/DPUTR/2024', '2024-06-10', 'Pembangunan Dapat Dilaksanakan'),
(66, '2024-05-13', '2024-05-13', 'Putry Anggraeni Aly', 'Jl. Taman Asri Raya Blok R2 No.6 RT.001/RW.014 Kelurahan Subangjaya Kecamatan Cikole', '106.945783', '-6.910847', '3096', 'Hak Guna Bangunan', '774', 'Renovasi Sarana Gedung Olahraga (GOR)', 'Kawasan Permukiman dan Kawasan Perdagangan dan Jas', 'KP.06.01/1255/V/6/DPUTR/2024', '2024-05-13', 'PU.06.02/1408/V/6/DPUTR/2024', '2024-05-31', 'Pembangunan Dapat Dilaksanakan'),
(67, '2024-05-13', '2024-05-13', 'Risa Nur\'aeni', 'Kaveling Bumi Ciwaringin Jl. Damai No.2 RT.002/RW.006 Kelurahan Jaya mekar Kecamatan Baros', '106.928743', '-6.952939', '571', 'Hak Milik', '350', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1245/V/6/DPUTR/2024', '2024-05-08', 'PU.06.02/1268/V/6/DPUTR/2024', '2024-05-15', 'Pembangunan Dapat Dilaksanakan'),
(68, '2024-05-16', '2024-05-16', 'Rosliana Dewi SKp, MH.Kes', 'Perum Taman Asri Blok B.14 No.25 RT.006/RW.014 Kelurahan Subangjaya Kecamatan Cikole', '106.946914', '-6.913653', '629', 'Hak Milik', '72', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1284/V/6/DPUTR/2024', '2024-05-16', 'PU.06.02/1410/V/6/DPUTR/2024', '2024-05-31', 'Pembangunan Dapat Dilaksanakan'),
(69, '2024-05-20', '2024-05-20', 'Siti Nurjanah', 'Jl. Pasir Ipis Kelurahan Subangjaya Kecamatan Cikole', '106.947785', '-6.917053', '1151', 'Hak Milik', '530', 'Rumah Tinggal', 'Kawasan Tanaman Pangan', 'KP.06.01/1311/V/6/DPUTR/2024', '2024-05-20', 'PU.06.02/1346/V/6/DPUTR/2024', '2024-05-22', 'Pembangunan Tidak Dapat Dilaksanakan'),
(70, '2024-05-28', '2024-05-28', 'Suparman', 'Jl. Azminta Azmali RT.008/RW.001 Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.922251', '-6.913044', '595', 'Hak Milik', '97', 'Rumah Kost', 'Kawasan Permukiman', 'KP.06.01/1379/V/6/DPUTR/2024', '2024-05-28', 'PU.06.02/1430/V/6/DPUTR/2024', '2024-05-31', 'Pembangunan Dapat Dilaksanakan'),
(71, '2024-05-14', '2024-05-28', 'Sutrisna', 'Jl. Pajagalan Kelurahan Nyomplong Kecamatan Warudoyong', '106.921657', '-6.925138', ' ', ' ', '0', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1377/V/6/DPUTR/2024', '2024-05-27', 'PU.06.02/1367/V/6/DPUTR/2024', '2024-05-27', 'Pembangunan Dapat Dilaksanakan'),
(72, '2024-06-21', '2024-06-21', 'Anggi Zaskia', 'Jl. Tegal Jambu RT.007/RW.005 Kelurahan Situmekar Kecamatan Lembursitu', '106.895756', '-6.968286', '1352', 'Hak Milik', '136', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1635/V/6/DPUTR/2024', '2024-06-24', 'KP.06.02/1690/V/6/DPUTR/2024', '2024-06-28', 'Pembangunan Dapat Dilaksanakan'),
(73, '2024-06-24', '2024-06-26', 'Cucum Sumiati', 'Gg. Nirwana Kelurahan Gunung Puyuh Kecamatan Gunungpuyuh', '106.917957', '-6.915111', ' ', 'Hak Milik', '224', 'Rumah Kos', 'Kawasan Permukiman', 'KP.06.01//V/6/DPUTR/2024', '2024-06-26', 'KP.06.02/1696/V/6/DPUTR/2024', '2024-06-28', 'Pembangunan Dapat Dilaksanakan'),
(74, '2024-06-24', '2024-06-26', 'Dr. Sugiharto, S.P.SI., M.M', 'Perum Taman Asri Blok B6 No.5 RT.003/RW.014 Kelurahan Subangjaya Kecamatan Cikole', '106.947556', '-6.9125', '524', 'Hak Milik', '160', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1667/V/6/DPUTR/2024', '2024-06-26', 'KP.06.02/1674/V/6/DPUTR/2024', '2024-06-27', 'Pembangunan Dapat Dilaksanakan'),
(75, '2024-06-25', '2024-06-26', 'Eman Sulaeman', 'Jl. Pelabuhan II RT.001/RW.006 Kelurahan Lembursitu Kecamatan Lembursitu', '106.889984', '-6.95988', '5723', 'Hak Milik', '1558', 'Mini Soccer', 'Kawasan Permukiman', 'KP.06.01/1664/V/6/DPUTR/2024', '2024-06-26', 'KP.06.02/1694/V/6/DPUTR/2024', '2024-06-28', 'Pembangunan Dapat Dilaksanakan'),
(76, '2024-06-24', '2024-06-25', 'Hendrik', 'Jl. Pabuaran RT.004/RW.001 Kelurahan Nyomplong Kecamatan Warudoyong', '106.920994', '-6.931119', '2037', 'Hak Milik', '172', 'Tempat Usaha', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1651/V/6/DPUTR/2024', '2024-06-25', 'KP.06.02/1675/V/6/DPUTR/2024', '2024-06-27', 'Pembangunan Dapat Dilaksanakan'),
(77, '2024-06-03', '2024-06-03', 'Lim Tek Kwang', 'Jl. Perniaga RT.001/RW.008 Kelurahan Gunungparang Kecamatan Cikole', '106.929082', '-6.922666', '801', 'Hak Milik', '148', 'Ruko', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1455/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1584/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(78, '2024-06-03', '2024-06-03', 'Magdalena Jusak', 'Jl. Pasar Wangi No.15 RT.004/RW.006 Kelurahan Nyomplong Kecamatan Warudoyong', '106.926985', '-6.923582', '1858', 'Hak Milik', '125', 'Ruko', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1456/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1580/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(79, '2024-06-20', '2024-06-21', 'Noer Isbandiah Subandi', 'Jl. Bhayangkara No.133 Blok C Kelurahan Karamat Kecamatan Gunungpuyuh', '106.92174', '-6.910273', '809', 'Hak Milik', '82', 'Ruko', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1534/V/6/DPUTR/2024', '2024-06-24', 'KP.06.02/1627/V/6/DPUTR/2024', '2024-06-24', 'Pembangunan Dapat Dilaksanakan'),
(80, '2024-05-28', '2024-06-03', 'Raden Muhammad Rizky Nurullah', 'Gg. Duren RT.001/RW.008 Kelurahan Dayeuh Luhur Kecamatan Warudoyong', '106.919981', '-6.939272', '5798', 'Kosong', '306', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1457/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1545/V/6/DPUTR/2024', '2024-06-11', 'Pembangunan Dapat Dilaksanakan'),
(81, '2024-05-30', '2024-05-31', 'Ratu Beranne Suharja, S.E', 'Jl. Pelabuhan II No.463 RT.004/RW.001 Kelurahan Sindangsari Kecamatan Lembursitu', '106.916542', '-6.94751', '169', 'Hak Milik', '393', 'Klinik Pratama', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1438/V/6/DPUTR/2024', '2024-06-03', 'KP.06.02/1521/V/6/DPUTR/2024', '2024-06-10', 'Pembangunan Dapat Dilaksanakan'),
(82, '2024-05-30', '2024-05-31', 'Ratu Beranne Suharja, S.E', 'Jl. R.A. Kosasih No.376 RT.003/RW.009 Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.954579', '-6.919618', '1066', 'Hak Milik', '140', 'Klinik Pratama', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1437/V/6/DPUTR/2024', '2024-06-03', 'KP.06.02/1583/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(83, '2024-06-04', '2024-06-04', 'RS Fauzia Nurunisa', 'Jl. Cicadas Kaveling RT.002/RW.008 Kelurahan Sudajaya Hilir Kecamatan Baros', '106.917262', '-6.962633', '2486', 'Hak Milik', '104', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1463/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1585/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(84, '2024-06-07', '2024-06-07', 'Siti Intan Artini', 'Jl. Sriwidari Kelurahan Selabatu Kecamatan Cikole', '106.927081', '-6.915459', '1405', 'Hak Milik', '256', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1532/V/6/DPUTR/2024', '2024-06-10', 'KP.06.02/1637/V/6/DPUTR/2024', '2024-06-24', 'Pembangunan Dapat Dilaksanakan'),
(85, '2024-06-07', '2024-06-07', 'Siti Intan Artini', 'Jl. Sriwidari Kelurahan Selabatu Kecamatan Cikole', '106.927081', '-6.915459', '1781', 'Hak Milik', '132', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1532/V/6/DPUTR/2024', '2024-06-10', 'KP.06.02/1637/V/6/DPUTR/2024', '2024-06-24', 'Pembangunan Dapat Dilaksanakan'),
(86, '2024-06-24', '2024-06-25', 'Siti Mila Kudsiyah', 'Kp. Gedang Panjang RT.003/RW.008 Kelurahan Limusnunggal Kecamatan Cibeureum', '106.942136', '-6.946203', '4037', 'Hak Milik', '128', 'Ruko', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1663/V/6/DPUTR/2024', '2024-06-21', 'KP.06.02/1655/V/6/DPUTR/2024', '2024-06-25', 'Pembangunan Dapat Dilaksanakan'),
(87, '2024-06-26', '2024-06-26', 'Ujang Saepullah', 'Jl. Cemerlang RT.001/RW.010 Kelurahan Sukakarya Kecamatan Warudoyong', '106.902806', '-6.927857', '30', 'Hak Milik', '560', 'Rumah Tinggal', 'Kawasan Peruntukan Industri', 'KP.06.01/1666/V/6/DPUTR/2024', '2024-06-26', 'KP.06.02/1697/V/6/DPUTR/2024', '2024-06-28', 'Pembangunan Dapat Dilaksanakan'),
(88, '2024-06-04', '2024-06-04', 'Waway Suherli', 'Jl. Suryakencana RT.005/RW.008 Kelurahan Selabatu Kecamatan Cikole', '106.93394', '-6.911445', '1165', 'Hak Milik', '25', 'Tempat Usaha Terapi, Café dan Resto', 'Kawasan Perdagangan dan jasa', 'KP.06.01/1464/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1587/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(89, '2024-06-03', '2024-06-03', 'Wina Fuji Lestari', 'Jl. Benteng Kidul RT.001/RW.002 Kelurahan Benteng Kecamatan Warudoyong', '106.915121', '-6.92538', '2829', 'Hak Milik', '237', 'Kos-Kosan', 'Kawasan Permukiman', 'KP.06.01/1458/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1573/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(90, '2024-05-21', '2024-05-21', 'Wiwin Windiari', 'Kp. Limusnunggal RT.003/RW.001 Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.940723', '-6.938916', '2472', 'Hak Milik', '150', 'Tempat Usaha', 'Kawasan Permukiman', 'KP.06.01/1332/V/6/DPUTR/2024', '2024-05-21', 'KP.06.02/1569/V/6/DPUTR/2024', '2024-06-13', 'Pembangunan Dapat Dilaksanakan'),
(91, '2024-06-04', '2024-06-04', 'Wiwin Winiarti, A. Md. Keb', 'Jl. Cicadas Kaveling RT.002/RW.008 Kelurahan Sudajaya Hilir Kecamatan Baros', '106.917265', '-6.962905', '2588', 'Hak Milik', '75', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1462/V/6/DPUTR/2024', '2024-06-04', 'KP.06.02/1586/V/6/DPUTR/2024', '2024-06-14', 'Pembangunan Dapat Dilaksanakan'),
(92, '2024-07-04', '2024-07-05', 'Abelya Safitri', 'RT.003/RW.004 Kelurahan Karamat Kecamatan Gunungpuyuh', '106.916578', '-6.908275', '2204', 'Hak Milik', '161', 'Rumah Tinggal', 'Kawasan Tanaman Pangan', 'KP.06.01/1777/V/6/DPUTR/2024', '2024-07-08', 'PU.06.02/1935/V/6/DPUTR/2024', '2024-07-19', 'Pembangunan Tidak Dapat Dilaksanakan'),
(93, '2024-07-05', '2024-07-05', 'Alaminuji', 'Jl. K.H. Ahmad Sanusi RT.001/RW.002 Kelurahan Sukakarya Kecamatan Warudoyong', '106.906172', '-6.91515', '9375', 'Hak Milik', '480', 'Klinik Mecca Madina', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1775/V/6/DPUTR/2024', '2024-07-08', 'PU.06.02/1939/V/6/DPUTR/2024', '2024-07-22', 'Pembangunan Dapat Dilaksanakan'),
(94, '2024-07-10', '2024-07-10', 'Bachtiar Rifai (PT. Sumber Alfaria Trijaya Tbk)', 'Jl. Benteng Kidul Kp. Benteng Kidul RT.002/RW.001 Kelurahan Benteng Kecamatan Warudoyong', '106.915231', '-6.927225', '3108', 'Kosong', '663', 'Minimarket', 'Kawasan Permukiman', 'KP.06.01/1842/V/6/DPUTR/2024', '2024-07-11', 'PU.06.02/1983/V/6/DPUTR/2024', '2024-07-24', 'Pembangunan Dapat Dilaksanakan'),
(95, '2024-07-03', '2024-07-15', 'Dewi Kunia, S. ST. AK', 'Jl. Suryakencana No.43 Kelurahan Selabatu Kecamatian Cikole', '106.9323', '-6.915459', '1525', 'Hak Pakai', '9497', 'Rintek TPS dan Penampungan Sampah Medis B3', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1791/V/6/DPUTR/2024', '2024-07-15', 'PU.06.02/1904/V/6/DPUTR/2024', '2024-07-17', 'Pembangunan Dapat Dilaksanakan'),
(96, '2024-07-15', '2024-07-16', 'H. Dadang Suparman', 'Jl. Sindangsari RT.002/RW.004 Kelurahan Sindangsari Kecamatan Lembursitu', '106.914364', '-6.952842', '1707', 'Hak Milik', '1497', 'Tempat Usaha (Kios)', 'Kawasan Permukiman', 'KP.06.01/1908/V/6/DPUTR/2024', '2024-07-18', 'PU.06.02/2001/V/6/DPUTR/2024', '2024-07-26', 'Pembangunan Dapat Dilaksanakan'),
(97, '2024-07-16', '2024-07-16', 'Herlan', 'Jl. Cemerlang RT.002/RW. 010 Kelurahan Sukakarya Kecamatan Warudoyong', '106.903156', '-6.930562', '399', 'Hak Milik', '2345', 'Tempat Usaha', 'Kawasan Peruntukan Industri', 'KP.06.01/1909/V/6/DPUTR/2024', '2024-07-18', 'PU.06.02/2013/V/6/DPUTR/2024', '2024-07-29', 'Pembangunan Dapat Dilaksanakan'),
(98, '2024-07-01', '2024-07-01', 'Melita', 'Gg. Raksa 2 Kekenceng RT.002/RW.008 Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.949913', '-6.922721', '3952', 'Hak Milik', '512', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1703/V/6/DPUTR/2024', '2024-07-01', 'PU.06.02/1818/V/6/DPUTR/2024', '2024-07-10', 'Pembangunan Dapat Dilaksanakan'),
(99, '2024-07-09', '2024-07-09', 'Moch. Raja Nabil Ichsan', 'Jl. Sriwidari Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.928791', '-6.913026', '53', 'Hak Milik', '384', 'Tempat Usaha (Café dan carwash)', 'Kawasan Permukiman', 'KP.06.01/1805/V/6/DPUTR/2024', '2024-07-09', 'PU.06.02/1968/V/6/DPUTR/2024', '2024-07-23', 'Pembangunan Dapat Dilaksanakan'),
(100, '2024-07-05', '2024-07-05', 'Muhamad Iqbal Suranta Sembiring Meliala, S.Pi', 'RT.001/RW.013 Kelurahan Nanggeleng Kecamatan Citamiang', '106.935484', '-6.935331', '2562', 'Hak Milik', '113', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1776/V/6/DPUTR/2024', '2024-07-08', 'PU.06.02/1933/V/6/DPUTR/2024', '2024-07-19', 'Pembangunan Dapat Dilaksanakan'),
(101, '2024-07-18', '2024-07-18', 'Nanang Rohyat', 'Jl. Cikareo No. 3 RT.003/RW.011 Kelurahan Sukakarya Kecamatan Warudoyong', '106.908031', '-6.941088', '88', 'Hak Milik', '1125', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa, Kawasan Permukiman, ', 'KP.06.01/1938/V/6/DPUTR/2024', '2024-07-22', 'PU.06.02/2051/V/6/DPUTR/2024', '2024-07-31', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa serta Kawasan Permukiman'),
(102, '2024-07-22', '2024-07-22', 'Sendi Priadi', 'Jl. Cemerlang RT.004/RW.010 Kelurahan Sukakarya Kecamatan Warudoyong', '106.904586', '-6.933154', '5202', 'Hak Milik', '348', 'Lembaga Kursus (Kelengkapan Persyaratan SPPL)', 'Kawasan Peruntukan Industri', 'KP.06.01/1944/V/6/DPUTR/2024', '2024-07-22', 'PU.06.02/2015/V/6/DPUTR/2024', '2024-07-29', 'Pembangunan Dapat Dilaksanakan'),
(103, '2024-07-01', '2024-07-01', 'Sylvia Herdini', 'Jl. Bhayangkara No. 20 Kelurahan Gunung Puyuh Kecamatan Gunungpuyuh', '106.916745', '-6.917453', '1064', 'Hak Milik', '205', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/1705/V/6/DPUTR/2024', '2024-07-01', 'PU.06.02/1817/V/6/DPUTR/2024', '2024-07-10', 'Pembangunan Dapat Dilaksanakan'),
(104, '2024-07-09', '2024-07-09', 'Windu Wulan', 'Puri Cibeureum Permai (PCP) II Jl. Asoka Blok OO No. 9 kelurahan Babakan Kecamatan Cibeureum', '106.954026', '-6.92898', '1649', 'Hak Milik', '60', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1806/V/6/DPUTR/2024', '2024-07-09', 'PU.06.02/1969/V/6/DPUTR/2024', '2024-07-23', 'Pembangunan Dapat Dilaksanakan'),
(105, '2024-07-07', '2024-07-08', 'Yuta Ningrum', 'Jl. Taman Asri 6 Blok A9 No. 2 RT.004/RW.014 Kelurahan Subangjaya Kecamatan Cikole', '106.947715', '-6.912216', '1294', 'Hak Milik', '144', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1791/V/6/DPUTR/2024', '2024-07-08', 'PU.06.02/1819/V/6/DPUTR/2024', '2024-07-10', 'Pembangunan Dapat Dilaksanakan'),
(106, '2024-07-01', '2024-07-01', 'Zeta Talita', 'Kp. Tegalpari Kelurahan Gunung Puyuh Kecamatan Gunungpuyuh', '106.918469', '-6.909754', '675', 'Hak Guna Bangunan', '80', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/1704/V/6/DPUTR/2024', '2024-07-01', 'PU.06.02/1816/V/6/DPUTR/2024', '2024-07-10', 'Pembangunan Dapat Dilaksanakan'),
(107, '2024-07-29', '2024-08-05', 'Ali Sundiharja, Drg', 'Jl. Nyomplong No.1 Kelurahan Nyomplong Kecamatan Warudoyong', '106.921978', '-6.923609', '2198', 'Hak Milik', '495', 'Klinik', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2124/V/6/DPUTR/2024', '2024-08-05', 'PU.06.02/2110/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Dapat Dilaksanakan'),
(108, '2024-07-30', '2024-07-30', 'Arvin Risman', 'Jl. R.E. Martadinata , Laks No.59 RT.004/RW.006 Kelurahan Cikole Kecamatan Cikole', '106.933327', '-6.920779', '908', 'Hak Milik', '1547', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2034/V/6/DPUTR/2024', '2024-07-30', 'PU.06.02/2107/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Dapat Dilaksanakan'),
(109, '2024-07-31', '2024-07-30', 'Bachtiar Rifai', 'Jl. Bhayangkara RT.001/RW.015 Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.921206', '-6.910926', '1583', 'Hak Milik', '205', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2081/V/6/DPUTR/2024', '2024-08-01', 'PU.06.02/2119/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Dapat Dilaksanakan'),
(110, '2024-08-05', '2024-08-06', 'Budiyanto Tirta Saputra', 'Jl. Lettu Bakri No.37 RT.005/RW.006 Kelurahan Nyomplong Kecamatan Warudoyong', '106.925407', '-6.923874', '54', 'Hak Milik', '753', 'Ruko dan Home Industry', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2154/V/6/DPUTR/2024', '2024-08-08', 'PU.06.02/2240/V/6/DPUTR/2024', '2024-08-16', 'Pembangunan Dapat Dilaksanakan'),
(111, '2024-08-06', '2024-08-06', 'Dany Indra Brata Solisa', 'Gg. H. Juwaeni Kelurahan Cisarua Kecamatan Cikole', '106.937761', '-6.923655', '88', 'Hak Milik', '129', 'Rumah Kost', 'Kawasan Permukiman', 'KP.06.01/2138/V/6/DPUTR/2024', '2024-08-06', 'PU.06.02/2212/V/6/DPUTR/2024', '2024-08-14', 'Pembangunan Dapat Dilaksanakan'),
(112, '2024-08-19', '2024-08-19', 'Handoko Daryono', 'Jl. Rumah Sakit RT.003/RW.004 Kelurahan Cikole Kecamatan Cikole', '106.934603', '-6.914519', '603', 'Hak Milik', '1403', 'Perluasan Tempat Usaha dan Kelengkapan Administrasi SLF', 'Kawasan Permukiman', 'KP.06.01/2266/V/6/DPUTR/2024', '2024-08-20', 'PU.06.02/2347/V/6/DPUTR/2024', '2024-08-27', 'Pembangunan Dapat Dilaksanakan'),
(113, '2024-08-20', '2024-08-20', 'Iis Ismaniar, Am.Kep', 'Jl. Nurul Iman No. 78 RT.005/RW.005 Kelurahan Gunung Puyuh Kecamatan Gunungpuyuh', '106.914554', '-6.914948', '1225', 'Hak Milik', '2782', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2285/V/6/DPUTR/2024', '2024-08-21', 'PU.06.02/2348/V/6/DPUTR/2024', '2024-08-27', 'Pembangunan Dapat Dilaksanakan'),
(114, '2024-08-07', '2024-08-07', 'Irina Suguanto', 'Jl. Ahmad Yani RT.002/RW.005 Kelurahan Nyomplong Kecamatan Warudoyong', '106.923403', '-6.921662', ' ', 'Hak Milik', '280', 'Ruko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2156/V/6/DPUTR/2024', '2024-08-08', 'PU.06.02/2213/V/6/DPUTR/2024', '2024-08-14', 'Pembangunan Dapat Dilaksanakan'),
(115, '2024-07-28', '2024-07-30', 'Ivan Wijaya', 'Jl. Widyakrama RT.001/RW.007 Kelurahan Sudajaya Hilir Kecamatan Baros', '106.919852', '-6.963248', '2068', 'Hak Milik', '1294', 'Rumah Tinggal', 'Kawasan Permukiman dan Kawasan Tanaman Pangan', 'KP.06.01/2034/V/6/DPUTR/2024', '2024-07-30', 'PU.06.02/2107/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(116, '2024-07-28', '2024-07-30', 'Ivan Wijaya', 'Jl. Widyakrama RT.001/RW.007 Kelurahan Sudajaya Hilir Kecamatan Baros', '106.91977', '-6.963062', '2115', 'Hak Milik', '600', 'Rumah Tinggal', 'Kawasan Permukiman dan Kawasan Tanaman Pangan', 'KP.06.01/2034/V/6/DPUTR/2024', '2024-07-30', 'PU.06.02/2107/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(117, '2024-07-28', '2024-07-30', 'Ivan Wijaya', 'Jl. Widyakrama RT.001/RW.007 Kelurahan Sudajaya Hilir Kecamatan Baros', '106.919597', '-6.963009', '2116', 'Hak Milik', '1200', 'Rumah Tinggal', 'Kawasan Permukiman dan Kawasan Tanaman Pangan', 'KP.06.01/2034/V/6/DPUTR/2024', '2024-07-30', 'PU.06.02/2107/V/6/DPUTR/2024', '2024-08-02', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(118, '2024-08-21', '2024-08-21', 'Iwan Iskandar', 'Jl. Pasundan RT.005/RW.004 Kelurahan Nyomplong Kecamatan Warudoyong', '106.922791', '-6.923584', ' ', ' ', '0', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2300/V/6/DPUTR/2024', '2024-08-22', 'PU.06.02/2350/V/6/DPUTR/2024', '2024-08-27', 'Pembangunan Dapat Dilaksanakan'),
(119, '2024-08-07', '2024-08-08', 'Rahmat Bilal', 'Jl .Asmud Lubis, Kapt. No. 13 RT.001/RW.006 Kelurahan Selabatu Kecamatan Cikole', '106.933083', '-6.902472', '738', 'Hak Milik', '150', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2159/V/6/DPUTR/2024', '2024-08-08', 'PU.06.02/1929/V/6/DPUTR/2024', '2022-08-19', 'Pembangunan Dapat Dilaksanakan'),
(120, '2024-07-31', '2024-07-31', 'RS KARTIKA KASIH (PT. KARTIKA PARAMA MEDIKA)', 'Jl. Ahmad Yani No.18 A Kelurahan Nyomplong Kecamatan Warudoyong', '106.923821', '-6.922027', '769', 'Hak Guna Bangunan', '415', 'Rumah Sakit', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2082/V/6/DPUTR/2024', '2024-08-01', 'PU.06.02/2210/V/6/DPUTR/2024', '2024-08-14', 'Pembangunan Dapat Dilaksanakan'),
(121, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.906314', '-6.975005', '3566', 'Hak Milik', '2830', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2024', '2024-08-21', 'PU.06.02/2394/V/6/DPUTR/2024', '2024-08-30', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(122, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.90669', '-6.974301', '3954', 'Hak Milik', '1810', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2025', '2024-08-22', 'PU.06.02/2394/V/6/DPUTR/2025', '2024-08-31', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(123, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.906232', '-6.975444', '3955', 'Hak Milik', '1445', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2026', '2024-08-23', 'PU.06.02/2394/V/6/DPUTR/2026', '0000-00-00', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(124, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.906705', '-6.974729', '3765', 'Hak Milik', '435', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2027', '2024-08-24', 'PU.06.02/2394/V/6/DPUTR/2027', '0000-00-00', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(125, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.9066', '-6.975431', '3567', 'Hak Milik', '1460', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2028', '2024-08-25', 'PU.06.02/2394/V/6/DPUTR/2028', '0000-00-00', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(126, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.906644', '-6.975058', '3766', 'Hak Milik', '1725', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2029', '2024-08-26', 'PU.06.02/2394/V/6/DPUTR/2029', '0000-00-00', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(127, '2024-08-20', '2024-08-21', 'Shintaty', 'Jl. Merdeka II No. 35 RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.906422', '-6.974368', '3767', 'Hak Milik', '3060', 'Gudang Penyimpanan', 'Kawasan Perdagangan dan Jasa serta Kawasan Ruang T', 'KP.06.01/2286/V/6/DPUTR/2030', '2024-08-27', 'PU.06.02/2394/V/6/DPUTR/2030', '0000-00-00', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Perdagangan dan Jasa'),
(128, '2024-08-22', '2024-08-22', 'Wawan Suwandi', 'Jl. Ciandam RT.001/RW.004 Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.947803', '-6.932029', '3237', 'Hak Milik', '52', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2301/V/6/DPUTR/2024', '2024-08-22', 'PU.06.02/2351/V/6/DPUTR/2024', '2024-08-27', 'Pembangunan Dapat Dilaksanakan'),
(129, '2024-08-06', '2024-08-07', 'Yayasan Sukabumi Study Center', 'Kp. Parung RT.002/RW.006 Kelurahan Karang Tengah Kecamatan Gunungpuyuh', '106.913049', '-6.907969', '6128', 'Hak Milik', '1551', 'Bangunan Kelas', 'Kawasan Permukiman', 'KP.06.01/2155/V/6/DPUTR/2024', '2024-08-08', 'PU.06.02/2269/V/6/DPUTR/2024', '2024-08-20', 'Pembangunan Dapat Dilaksanakan'),
(130, '2024-08-06', '2024-08-08', 'Yayasan Sukabumi Study Center', 'Jl. Babakan Jampang RT.003/RW.010 Kelurahan Karang Tengah Kecamatan Gunung Puyuh', '106.912917', '-6.907467', '489', 'Hak Milik', '815', 'Bangunan Asrama', 'Kawasan Permukiman dan Kawasan Ruang Terbuka Hijau', 'KP.06.01/2170/V/6/DPUTR/2024', '2024-08-09', 'PU.06.02/2271/V/6/DPUTR/2024', '2024-08-20', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(131, '2024-07-30', '2024-07-30', 'Yoga Olgivana', 'Jl. Stadion Kelurahan Dayeuhluhur Kecamatan Warudoyong', '106.919202', '-6.932336', '2247', 'Hak Milik', '200', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2079/V/6/DPUTR/2024', '2024-08-01', 'PU.06.02/2206/V/6/DPUTR/2024', '2024-08-13', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(132, '2024-08-20', '2024-08-21', 'Yudi Prasetia', 'Jl. Pajagalan Komplek Ruko Danalaga Square Blok C No. 1 Kelurahan Nyomplong Kecamatan Warudoyong', '106.925692', '-6.925534', '1050', 'Hak Guna Bangunan', '210', 'Toko Obat/Apotek', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2299/V/6/DPUTR/2024', '2024-08-22', 'PU.06.02/2349/V/6/DPUTR/2024', '2024-08-27', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(133, '2024-09-13', '2024-09-18', 'Ade Suherman', 'Jl. Limusnunggal Kp. Cibungur RT.004/RW.003 Kelurahan Sindangpalay Kecamatan Cibeureum', '106.946567', '-6.951233', '435', 'Hak Milik', '60', 'Rumah Toko/Kios', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2580/V/6/DPUTR/2024', '2024-09-18', 'PU.06.02/2666/V/6/DPUTR/2024', '2024-09-26', 'Pembangunan Dapat Dilaksanakan'),
(134, '2024-09-23', '2024-09-23', 'Anggi Rhamdani', 'Pesona Limusnunggal Kelurahan Limusnunggal Kecamatan Cibeureum Kota Sukabumi', '106.941838', '-6.943227', '1383', 'Hak Milik', '240', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2639/V/6/DPUTR/2024', '2024-09-24', 'PU.06.02/2696/V/6/DPUTR/2024', '2024-09-30', 'Pembangunan Dapat Dilaksanakan'),
(135, '2024-09-04', '2024-09-04', 'Arpi Zulkifli', 'Jl. Saniin RT.010/RW.002 Kelurahan Benteng Kecamatan Warudoyong', '106.917162', '-6.922143', '2670', 'Hak Milik', '295', 'Gudang', 'Kawasan Permukiman', 'KP.06.01/2471/V/6/DPUTR/2024', '2024-09-05', 'PU.06.02/2582/V/6/DPUTR/2024', '2024-09-18', 'Pembangunan Dapat Dilaksanakan'),
(136, '2024-09-06', '2024-09-06', 'Budiyanto', 'Komplek Ruko Danalaga Square Kelurahan Nyomplong Kecamatan Warudoyong', '106.926045', '-6.926482', '1140', 'Hak Guna Bangunan', '98', 'Food Court', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2504/V/6/DPUTR/2024', '2024-09-09', 'PU.06.02/2604/V/6/DPUTR/2024', '2024-09-20', 'Pembangunan Dapat Dilaksanakan'),
(137, '2024-09-23', '2024-09-23', 'Dandi Mauladi (PT. Agros Terra Gas)', 'Jl. Cemerlang Kelurahan Sukaraya Kecamatan Warudoyong Kota Sukabumi', '106.902159', '-6.927274', '9476', 'Hak Milik', '3314', 'SPPBE', 'Kawasan Peruntukan Industri, Kawasan Ruang Terbuka', 'KP.06.01/2632/V/6/DPUTR/2024', '2024-09-23', 'PU.06.02/2673/V/6/DPUTR/2024', '2024-09-27', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Peruntukan Industri'),
(138, '2024-09-03', '2024-09-05', 'Daniel Suyarto', 'Jl. Dwikora RT.001/RW.003 Kelurahan Nyomplong, Kecamatan Warudoyong', '106.921967', '-6.932176', '2388', 'Hak Milik', '2178', 'Pabrik', 'Kawasan Permukiman', 'KP.06.01/2481/V/6/DPUTR/2024', '2024-09-06', 'PU.06.02/2551/V/6/DPUTR/2024', '2024-09-17', 'Pembangunan Dapat Dilaksanakan');
INSERT INTO `rpp` (`id`, `TanggalSuratPermohonan`, `TanggalDisposisi`, `NamaPemohon`, `Lokasi`, `KoordinatX`, `KoordinatY`, `nib`, `TipeHak`, `luas`, `rpp`, `kawasan`, `NomorSuratTugas`, `TanggalSuratTugas`, `NomorSKRK`, `TanggalSKRK`, `ket`) VALUES
(139, '2024-09-19', '2024-09-19', 'Dewi Susianti', 'Jl. Cemerlang Kp.Tegal Padul RT.004/RW.003 Kelurahan Sukaraya Kecamatan Warudoyong Kota Sukabumi', '106.90544', '-6.920116', '9392', 'Hak Milik', '307', 'Rumah Tinggal', 'Kawasan Peruntukan Industri', 'KP.06.01/2597/V/6/DPUTR/2024', '2024-09-20', 'PU.06.02/2679/V/6/DPUTR/2024', '2024-09-27', 'Pembangunan Dapat Dilaksanakan'),
(140, '2024-09-20', '2024-09-20', 'Eviyawati', 'Jl. Dayeuh Luhur RT.002/RW.006 Kelurahan Dayeuh Luhur Kecamatan warudoyong', '106.921284', '-6.938538', '4276', 'Hak Milik', '118', 'RumahTinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2630/V/6/DPUTR/2024', '2024-09-23', 'PU.06.02/2694/V/6/DPUTR/2024', '2024-09-30', 'Pembangunan Dapat Dilaksanakan'),
(141, '2024-09-16', '2024-09-17', 'Frans Suwandi', 'Jl Pasundan RT.004/RW.007 Kelurahan Nyomplong Kecamatan Warudoyong Kota Sukabumi', '106.924693', '-6.924064', '301', 'Hak Milik', '375', 'Rumah Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2564/V/6/DPUTR/2024', '2024-09-17', 'PU.06.02/2668/V/6/DPUTR/2024', '2024-09-26', 'Pembangunan Dapat Dilaksanakan'),
(142, '2024-09-17', '2024-09-17', 'H. Wawan Setiawan', 'Jl. Ciandam RT.001, RW.004 Kelurahan Cibeureum Hilir Kecamtan Cibeureum Kota Sukabumi', '106.948548', '-6.932082', '18', 'Hak Milik', '390', 'Gudang', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2578/V/6/DPUTR/2024', '2024-09-18', 'PU.06.02/2678/V/6/DPUTR/2024', '2024-09-27', 'Pembangunan Dapat Dilaksanakan'),
(143, '2024-09-23', '2024-09-23', 'Herwanto', 'Jl. Bhayangkara Gg. Dua Ratus Kelurahan Sriwidari Kecamatan Gunung Puyuh Kota Sukabumi', '106.92844', '-6.912162', ' ', 'Hak Milik', '817', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2631/V/6/DPUTR/2024', '2024-09-23', 'PU.06.02/2695/V/6/DPUTR/2024', '2024-09-30', 'Pembangunan Dapat Dilaksanakan'),
(144, '2024-09-04', '2024-09-04', 'Hilman Pribadi', 'Jl. Lingkar Selatan RT.003/RW.011 Kelurahan Sukakarya Kecamatan Warudoyong', '106.908949', '-6.939356', '2400', 'Kosong', '1066', 'Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2472/V/6/DPUTR/2024', '2024-09-05', 'PU.06.02/2581/V/6/DPUTR/2024', '2024-09-18', 'Pembangunan Dapat Dilaksanakan'),
(145, '2024-09-04', '2024-09-04', 'Hilman Pribadi', 'Jl. Lingkar Selatan RT.003/RW.011 Kelurahan Sukakarya Kecamatan Warudoyong', '106.908949', '-6.939356', '10186', 'Kosong', '230', 'Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2472/V/6/DPUTR/2024', '2024-09-05', 'PU.06.02/2581/V/6/DPUTR/2024', '2024-09-18', 'Pembangunan Dapat Dilaksanakan'),
(146, '2024-09-02', '2024-09-02', 'Ina Marlina', 'Jl. Pelabuhan ll Blok Cipanengah Kelurahan Cipanengah Kecamatan Lembursitu', '106.909508', '-6.95578', '1213', 'Hak Milik', '148', 'Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2432/V/6/DPUTR/2024', '2024-08-03', 'PU.06.02/2522/V/6/DPUTR/2024', '2024-09-11', 'Pembangunan Dapat Dilaksanakan'),
(147, '2024-09-13', '2024-09-18', 'Ismat Ahmad, ST.', 'Jl. Gotong Royong RT.004/RW.012 Kelurahan Gunung Puyuh Kecamatan Gunung Puyuh  Kota Sukabumi', '106.91687', '-6.914255', '594', 'Hak Milik', '649', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2579/V/6/DPUTR/2024', '2024-09-18', 'PU.06.02/2667/V/6/DPUTR/2024', '2024-09-26', 'Pembangunan Dapat Dilaksanakan'),
(148, '2024-09-02', '2024-09-02', 'Kuncoro', 'Jl. Taman Bahagia Gg. Famili, Kelurahan Benteng Kecamatan Warudoyong', '106.916197', '-6.925008', '415', 'Hak Milik', '860', 'Kontrakan', 'Kawasan Permukiman', 'KP.06.01/2430/V/6/DPUTR/2024', '2024-09-03', 'PU.06.02/2521/V/6/DPUTR/2024', '2024-09-11', 'Pembangunan Dapat Dilaksanakan'),
(149, '2024-09-02', '2024-09-04', 'Rahayu Puji Lestari (SHM 27)', 'Jl. Perda Suryanta RT.004/RW.013 Kelurahan Nanggeleng Kecamatan Citamiang', '106.93711', '-6.936035', '3789', 'Hak Milik', '212', 'Klinik', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2470/V/6/DPUTR/2024', '2024-09-05', 'PU.06.02/2583/V/6/DPUTR/2024', '2024-09-18', 'Pembangunan Dapat Dilaksanakan'),
(150, '2024-09-02', '2024-09-04', 'Rahayu Puji Lestari (SHM 908)', 'Jl. Perda Suryanta RT.004/RW.013 Kelurahan Nanggeleng Kecamatan Citamiang', '106.937149', '-6.935925', '138', 'Hak Milik', '90', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', ' ', '1990-01-01', 'PU.06.02/2584/V/6/DPUTR/2024', '2024-09-18', 'Pembangunan Dapat Dilaksanakan'),
(151, '2024-09-06', '2024-09-06', 'Resti Wulan Dari', 'Kp. Babakan Kramat RT.003/Rw.004 Kelurahan Karamat Kecamatan Gunungpuyuh', '106.919991', '-6.905126', '2014', 'Kosong', '640', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2506/V/6/DPUTR/2024', '2024-09-09', 'PU.06.02/2607/V/6/DPUTR/2024', '2024-09-20', 'Pembangunan Dapat Dilaksanakan'),
(152, '2024-09-09', '2024-09-10', 'Riska Noviani', 'Jl. Kopeng No. 10 RT.002/RW.003 Kelurahan Karamat Kecamatan Gunungpuyuh', '106.92169', '-6.908333', ' ', 'Hak Milik', '155', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2512/V/6/DPUTR/2024', '2024-09-10', 'PU.06.02/2596/V/6/DPUTR/2024', '2024-09-20', 'Pembangunan Dapat Dilaksanakan'),
(153, '2024-09-02', '2024-09-02', 'Susilawati', 'Jl. Ciandam Kelurahan Cibeureum Hilir Kecamatan Cibeureum', '106.947037', '-6.931857', ' ', 'Hak Milik', '1100', 'Rumah Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2429/V/6/DPUTR/2024', '2024-09-03', 'PU.06.02/2520/V/6/DPUTR/2024', '2024-09-11', 'Pembangunan Dapat Dilaksanakan'),
(154, '2024-09-24', '2024-09-24', 'Yanti Deana Ryanthi', 'Jl. Bhayangkara No.188, Kelurahan Sriwidari Kecamatan Gunung Puyuh Kota Sukabumi', '106.927117', '-6.910973', ' ', 'Hak Milik', '231', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2642/V/6/DPUTR/2024', '2024-09-24', 'PU.06.02/2697/V/6/DPUTR/2024', '2024-09-30', 'Pembangunan Dapat Dilaksanakan'),
(155, '2024-10-01', '2024-10-01', 'Ade Muslihat, S.PD.I', 'Jl. Merbabu RT.005/RW.008 Kelurahan Karang Tengah Kecamatan Gunungpuyuh', '106.914282', '-6.896168', '359', 'Hak Milik', '473', 'Perluasan Fasilitas Pendidikan', 'Kawasan Permukiman', 'KP.06.01/2729/V/6/DPUTR/2024', '2024-10-03', 'PU.06.02/2784/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(156, '2024-10-03', '2024-10-03', 'Bachtiar Rifai (PT. Sumber Alfaria Trijaya)', 'Jl. Pelabuhan ll Kp. Kadulawang RT.003/RW.001 Kelurahan Situmekar Kecamatan Lembursitu', '106.901878', '-6.957971', '2778', 'Hak Milik', '361', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2744/V/6/DPUTR/2024', '2024-10-04', 'PU.06.02/2785/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(157, '2024-10-01', '2024-10-01', 'Dagus Surahman, S.Ag', 'Jl.Proklamasi RT.002/RW.001 Kelurahan Jayamekar Kecamatan Baros Kota Sukabumi', '106.923614', '-6.967499', '2949', 'Hak Pakai', '889', 'KUA Baros', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2701/V/6/DPUTR/2024', '2024-10-01', 'PU.06.02/2782/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(158, '2024-10-10', '2024-10-10', 'Dedeh Indriati', 'Jl. Pengadilan RT.004/RW.005 Kelurahan Nyomplong Kecamatan Warudoyong', '106.923848', '-6.922435', '2124', 'Hak Milik', '216', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2904/V/6/DPUTR/2024', '2024-10-14', 'PU.06.02/3059/V/6/DPUTR/2024', '2024-10-23', 'Pembangunan Dapat Dilaksanakan'),
(159, '2024-10-22', '2024-10-24', 'Dedy Safari', 'Jl. Ranca Kadu Kelurahan Sindangpalay Kecamatan Cibeureum', '106.957988', '-6.947713', '753', 'Hak Milik', '260', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3088/V/6/DPUTR/2024', '2024-10-25', 'PU.06.02/3155/V/6/DPUTR/2024', '2024-10-31', 'Pembangunan Dapat Dilaksanakan'),
(160, '2024-09-19', '2024-09-20', 'Dian Sri Susiyanti', 'Jl. Merbabu Perum Gading Kencana Asri Blok E IX No.1 Kelurahan Karang Tengah Kecamatan Gunung Puyuh Kota Sukabumi', '106.915388', '-6.904736', '1882', 'Hak Guna Bangunan', '165', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2629/V/6/DPUTR/2024', '2024-09-23', 'PU.06.02/2743/V/6/DPUTR/2024', '2024-10-04', 'Pembangunan Dapat Dilaksanakan'),
(161, '2024-10-01', '2024-10-01', 'Didin Saripudin', 'Jl. Abdul Aziz, KH RT.004/RW.016 Kelurahan Karang Tengah Kecamatan Gunungpuyuh', '106.910469', '-6.89933', '5915', 'Hak Pakai', '400', 'Perluasan Fasilitas Pendidikan', 'Kawasan Permukiman dan Kawasan Ruang Terbuka Hijau', 'KP.06.01/2730/V/6/DPUTR/2024', '2024-10-03', 'PU.06.02/2786/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Hanya Dapat Dilaksanakan pada Kawasan Permukiman'),
(162, '2024-10-08', '2024-10-08', 'Drs. Hadi Pranoto', 'Jl. Ciaul Pasir Kelurahan Cisarua Kecamatan Cikole', '106.943995', '-6.920295', '5800', 'Hak Milik', '1000', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2778/V/6/DPUTR/2024', '2024-10-08', 'PU.06.02/2935/V/6/DPUTR/2024', '2024-10-15', 'Pembangunan Dapat Dilaksanakan'),
(163, '2024-07-29', '2024-07-29', 'Ir. Irwan Kesuma, M.Si', 'Jl. Pembangunan RT.001/RW.006 Kelurahan Babakan Kecamatan Cibeureum', '106.957761', '-6.932617', '4674', 'Kosong', '24630', 'Handhole Galian Jaringan Fibre Optik', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2104/V/6/DPUTR/2024', '2024-08-02', 'PU.06.02/3074/V/6/DPUTR/2024', '2024-10-24', 'Pembangunan Dapat Dilaksanakan'),
(164, '2024-09-30', '2024-10-01', 'Muhamad Allia', 'Gg. Pemakaman RT.001/RW.004 Kelurahan Cikundul Kecamatan Lembursitu', '106.904907', '-6.973275', '3517', 'Kosong', '448', 'Bengkel Karoseri', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2702/V/6/DPUTR/2024', '2024-10-01', 'PU.06.02/2911/V/6/DPUTR/2024', '2024-10-14', 'Pembangunan Dapat Dilaksanakan'),
(165, '2024-10-15', '2024-10-15', 'Nicky Florensius Hermawan', 'Jl. Titiran RT.002/RW.001 Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.925833', '-6.913255', '975', 'Hak Milik', '668', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/3009/V/6/DPUTR/2024', '2024-10-17', 'PU.06.02/3061/V/6/DPUTR/2024', '2024-10-23', 'Pembangunan Dapat Dilaksanakan'),
(166, '2024-10-03', '2024-10-08', 'Nur Masni Napia', 'Pesona Limusnunggal Blok E No.8 RT.004/RW.007 Kelurahan Limusnunggal Kecamatan Cibeureum', '106.941847', '-6.94243', '1770', 'Hak Milik', '301', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/2779/V/6/DPUTR/2024', '2024-10-08', 'PU.06.02/2936/V/6/DPUTR/2024', '2024-10-15', 'Pembangunan Dapat Dilaksanakan'),
(167, '2024-09-26', '2024-09-26', 'Wahyu Fibrianti (PT. Bagus Gayatri Utama)', 'JL. Pelabuhan No.33 RT.001/ RW.002 Kelurahan Cikondang Kecamatan Citamiang Kota Sukabumi', '106.920192', '-6.94356', ' ', 'Hak Milik', '413', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2684/V/6/DPUTR/2024', '2024-09-30', 'PU.06.02/2728/V/6/DPUTR/2024', '2024-10-03', 'Pembangunan Dapat Dilaksanakan'),
(168, '2024-10-01', '2024-10-02', 'Puspa Rini, SH', 'Jl. Benteng Kidul RT.005/RW.002 Kelurahan Benteng Kecamatan Warudoyong', '106.915362', '-6.925187', '3107', 'Kosong', '1611', 'Minimarket dan Ruko', 'Kawasan Permukiman', 'KP.06.01/2732/V/6/DPUTR/2024', '2024-10-03', 'PU.06.02/2783/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(169, '2024-09-04', '2024-09-04', 'Rico Julian Dira', 'Jl. Raya Baros RT.003/RW.006 Kelurahan Baros Kecamatan Baros', '106.940202', '-6.96525', '5023', 'Hak Milik', '205', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2464/V/6/DPUTR/2024', '2024-09-05', 'PU.06.02/2934/V/6/DPUTR/2024', '2024-10-15', 'Pembangunan Dapat Dilaksanakan'),
(170, '2024-10-07', '2024-10-07', 'Selly Darmawan', 'Jl. Bhayangkara Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.920361', '-6.914104', ' ', 'Hak Milik', '1010', 'Rumah Makan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2777/V/6/DPUTR/2024', '2024-10-08', 'PU.06.02/2933/V/6/DPUTR/2024', '2024-10-15', 'Pembangunan Dapat Dilaksanakan'),
(171, '2024-10-07', '2024-10-07', 'Selly Darmawan', 'Jl. Bhayangkara Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.920361', '-6.914104', '357', 'Hak Milik', '917', 'Rumah Makan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2777/V/6/DPUTR/2024', '2024-10-08', 'PU.06.02/2933/V/6/DPUTR/2024', '2024-10-15', 'Pembangunan Dapat Dilaksanakan'),
(172, '2024-09-24', '2024-09-25', 'Sidik Permana \n(PT. INDOMARCO PRISTAMA)', 'Jl. Suryakencana No.08 RT.001/RW.002 Kelurahan Selabatu Kecamatan Cikole', '106.928036', '-6.918981', ' ', 'Hak Pakai', '1385', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2654/V/6/DPUTR/2024', '2024-09-25', 'PU.06.02/3156/V/6/DPUTR/2024', '2024-10-31', 'Pembangunan Dapat Dilaksanakan'),
(173, '2024-09-24', '2024-09-25', 'Sidik Permana \n(PT. INDOMARCO PRISTAMA)', 'Jl. Suryakencana No.08 RT.001/RW.002 Kelurahan Selabatu Kecamatan Cikole', '106.928036', '-6.918981', '809', 'Hak Guna Bangunan', '1385', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2654/V/6/DPUTR/2024', '2024-09-25', 'PU.06.02/3156/V/6/DPUTR/2024', '2024-10-31', 'Pembangunan Dapat Dilaksanakan'),
(174, '2024-09-27', '2024-09-27', 'Yongki Cahyadi', 'Jl. Pabuaran kelurahan Nyomplong Kecamatan warudoyong Kota Sukabumi', '106.920446', '-6.928761', '266', 'Hak Milik', '200', 'Rumah Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2685/V/6/DPUTR/2024', '2024-09-30', 'PU.06.02/2781/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(175, '2024-09-27', '2024-09-27', 'Yongki Cahyadi', 'Jl. Pabuaran kelurahan Nyomplong Kecamatan warudoyong Kota Sukabumi', '106.920311', '-6.928736', '861', 'Hak Milik', '186', 'Rumah Tinggal', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2686/V/6/DPUTR/2024', '2024-09-30', 'PU.06.02/2780/V/6/DPUTR/2024', '2024-10-08', 'Pembangunan Dapat Dilaksanakan'),
(176, '2024-10-10', '2024-10-10', 'Yusuf', 'Jl. R.A Kosasih RT.001/RW.001 Kelurahan Babakan Kecamatan Cibeureum', '106.959419', '-6.918856', '2342', 'Hak Milik', '464', 'Rumah Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/2917/V/6/DPUTR/2024', '2024-10-14', 'PU.06.02/3058/V/6/DPUTR/2024', '2024-10-23', 'Pembangunan Dapat Dilaksanakan'),
(177, '2024-11-06', '2024-11-06', 'Aprilia Putri Halwani', 'Jl. Cicadas RT.003/RW.006 Kelurahan Sindangsari Kecamatan Lembursitu Kota Sukabumi', '106.914686', '-6.961221', '2026', 'Kosong', '189816', 'Perumahan', 'Kawasan Permukiman', 'KP.06.01/3225/V/6/DPUTR/2024', '2024-11-07', 'PU.06.02/3398/V/6/DPUTR/2024', '2024-11-20', 'Pembangunan Dapat Dilaksanakan'),
(178, '2024-11-08', '2024-11-12', 'Atut Wigaty Adman', 'Jl. Lingkar Selatan (Letkol Eddie Soekardi) Blok Sudajaya Kelurahan Jayaraksa Kecamatan Baros Kota Sukabumi', '106.931903', '-6.950828', '1494', 'Hak Milik', '69', 'Rumah Toko', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3268/V/6/DPUTR/2024', '2024-11-12', 'PU.06.02/3396/V/6/DPUTR/2024', '2024-11-26', 'Pembangunan Dapat Dilaksanakan'),
(179, '2024-11-12', '2024-11-12', 'Bachtiar Rifai (PT.Sumber Alfaria Trijaya)', 'Jl. Raya Baros Kp. Genteng RT.001/ RW.001 Kelurahan Baros Kecamatan Baros Kota Sukabumi', '106.937998', '-6.963954', '5350', 'Hak Guna Bangunan', '2192', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3302/V/6/DPUTR/2024', '2024-11-14', 'PU.06.02/3499/V/6/DPUTR/2024', '2024-11-26', 'Pembangunan Dapat Dilaksanakan'),
(180, '2024-11-12', '2024-11-12', 'Bachtiar Rifai (PT.Sumber Alfaria Trijaya)', 'Jl. Jend. Sudirman No. 43 Gg Rawasalak RT.002/RW.012 Kelurahan Sriwidari Kecamatan Gunungpuyuh Kota Sukabumi', '106.920033', '-6.919754', '1813', 'Hak Milik', '490', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3304/V/6/DPUTR/2024', '2024-11-14', 'PU.06.02/3498/V/6/DPUTR/2024', '2024-11-26', 'Pembangunan Dapat Dilaksanakan'),
(181, '2024-11-12', '2024-11-12', 'Bachtiar Rifai (PT.Sumber Alfaria Trijaya)', 'Jl. Pelda Suryanta No. 24 RT.001/RW.004 Kelurahan Nanggeleng Kecamatan Citamiang Kota Sukabumi', '106.933889', '-6.932244', '3972', 'Kosong', '0', 'Minimarket', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3303/V/6/DPUTR/2024', '2024-11-14', 'PU.06.02/3500/V/6/DPUTR/2024', '2024-11-26', 'Pembangunan Dapat Dilaksanakan'),
(182, '2024-11-19', '2024-11-19', 'Cindy Suherti Suarsa (PT. Tarusbawa Pusaka Negara)', 'Jl. Limusnunggal RT.004/RW.003 Kelurahan Sindangpalay dan Kelurahan Limusnunggal Kecamatan Cibeureum Kota Sukabumi', '106.944354', '-6.94945', '2693', 'Hak Milik', '2113', 'Perumahan', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3397/V/6/DPUTR/2024', '2024-11-20', 'PU.06.02/3517/V/6/DPUTR/2024', '2024-11-28', 'Pembangunan Dapat Dilaksanakan'),
(183, '2024-10-31', '2024-10-31', 'Enjang Nurjaman', 'Jl. R. A. Kosasih No. 73 RT.001 /RW.001 Kelurahan Babakan Kecamatan Cibeureum Kota Sukabumi', '106.959277', '-6.918911', '3665', 'Hak Milik', '137', 'Kios', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3152/V/6/DPUTR/2024', '2024-10-31', 'PU.06.02/3306/V/6/DPUTR/2024', '2024-11-14', 'Pembangunan Dapat Dilaksanakan'),
(184, '2024-11-22', '2024-11-22', 'Fany Fuji Indriaty', 'Jl. Proklamasi Kelurahan Jayaraksa Kecamatan Baros', '106.929142', '-6.964973', '2454', 'Hak Milik', '161', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/3455/V/6/DPUTR/2024', '2024-11-25', 'PU.06.02/3550/V/6/DPUTR/2024', '2024-11-29', 'Pembangunan Dapat Dilaksanakan'),
(185, '2024-11-21', '2024-11-21', 'H. Johan Firmansyah, S.Sos', 'Jl. Sriwidari No.69 Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.92702', '-6.915213', ' ', 'Hak Milik', '430', 'Penginapan', 'Kawasan Permukiman', 'KP.06.01/3436/V/6/DPUTR/2024', '2024-11-22', 'PU.06.02/3548/V/6/DPUTR/2024', '2024-11-29', 'Pembangunan Dapat Dilaksanakan'),
(186, '2024-11-18', '2024-11-18', 'Hendra Ramlan', 'Jl. Proklamasi RT.001/RW.001 Kelurahan Jayamekar Kecamatan Baros', '106.923362', '-6.96782', '1978', 'Hak Milik', '238', 'Gudang Cabai', 'Kawasan Ruang Terbuka Hijau (RTH) Taman Kota', 'KP.06.01/3350/V/6/DPUTR/2024', '2024-11-19', 'PU.06.02/3528/V/6/DPUTR/2024', '2024-11-28', 'Pembangunan Tidak Dapat Dilaksanakan'),
(187, '2024-11-20', '2024-11-20', 'Hj. Ecin Kuraesin,S.Pd.', 'Jl. Jogray RT.008/RW.005 Kelurahan Subangjaya Kecamatan Cikole', '106.952812', '-6.907404', '1038', 'Hak Milik', '700', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/3395/V/6/DPUTR/2024', '2024-11-20', 'PU.06.02/3547/V/6/DPUTR/2024', '2024-11-29', 'Pembangunan Dapat Dilaksanakan'),
(188, '2024-11-12', '2024-11-12', 'Hj. Lilis Supartini', 'Jl.Otista Gg.Pembangunan RT.002/ RW.004 Kelurahan Nanggeleng Kecamatan Citamiang Kota Sukabumi', '106.933466', '-6.928654', '4192', 'Kosong', '173', 'Rumah Kost', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3269/V/6/DPUTR/2024', '2024-11-12', 'PU.06.02/3497/V/6/DPUTR/2024', '2024-11-26', 'Pembangunan Dapat Dilaksanakan'),
(189, '2024-11-11', '2024-11-15', 'Kristianto Dimas Tri Kuntjoro', 'Jl. Bhayangkara Kelurahan Sriwidari Kecamatan Gunungpuyuh', '106.926792', '-6.911956', '1314', 'Hak Guna Bangunan', '3668', 'Sertifikat Laik Fungsi (SLF) Hotel Laska', 'Kawasan Perdagangan dan Jasa', 'KP.06.01/3318/V/6/DPUTR/2024', '2024-11-18', 'PU.06.02/3527/V/6/DPUTR/2024', '2024-11-28', 'Pembangunan Dapat Dilaksanakan'),
(190, '2024-11-21', '2024-11-21', 'Papat Patimah', 'Jl. Merdeka RT.004/RW.004 Kelurahan Cipanengah Kecamatan Lembursitu', '106.909272', '-6.961283', '3070', 'Hak Milik', '459', 'Rumah Tinggal', 'Kawasan Permukiman', 'KP.06.01/3437/V/6/DPUTR/2024', '2024-11-22', 'PU.06.02/3549/V/6/DPUTR/2024', '2024-11-29', 'Pembangunan Dapat Dilaksanakan'),
(191, '2024-11-13', '2024-11-13', 'Pebri Iriansyah, S.STP', 'Jl.Kabandungan Kelurahan Selabatu kecamatan Cikole Kota Sukabumi', '106.929419', '-6.911454', '133', 'Hak Pakai', '725', 'Gedung Serbaguna Kelurahan Selabatu', 'Kawasan Permukiman', 'KP.06.01/3299/V/6/DPUTR/2024', '2024-11-13', 'PU.06.02/3511/V/6/DPUTR/2024', '2024-11-28', 'Pembangunan Dapat Dilaksanakan'),
(192, '2024-11-05', '2024-11-05', 'Saputra', 'Gg. Gunung Karang RT.003/RW.010 Kelurahan Limusnunggal Kecamatan Cibeureum Kota Sukabumi', '106.935437', '-6.948175', '3943', 'Hak Milik', '291', 'Konveksi', 'Kawasan Permukiman', 'KP.06.01/3198/V/6/DPUTR/2024', '2024-11-05', 'PU.06.02/3355/V/6/DPUTR/2024', '2024-11-19', 'Pembangunan Dapat Dilaksanakan');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gambar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `gambar`) VALUES
(7, '64f1f1dc5db78.jpg'),
(8, 'fb.jpg'),
(9, 'fb1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pengguna_username_unique` (`nama_pengguna`);

--
-- Indexes for table `permohonan`
--
ALTER TABLE `permohonan`
  ADD PRIMARY KEY (`id_perumahan_permohonan`);

--
-- Indexes for table `perumahan`
--
ALTER TABLE `perumahan`
  ADD PRIMARY KEY (`id_perumahan`);

--
-- Indexes for table `rpp`
--
ALTER TABLE `rpp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `permohonan`
--
ALTER TABLE `permohonan`
  MODIFY `id_perumahan_permohonan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=738;

--
-- AUTO_INCREMENT for table `perumahan`
--
ALTER TABLE `perumahan`
  MODIFY `id_perumahan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `rpp`
--
ALTER TABLE `rpp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2025;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
