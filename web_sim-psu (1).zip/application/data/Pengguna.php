<?php

class Pengguna
{
	public $id;
	public $namaLengkap;
	public $foto;
	public $username;
	public $password;
	public $role;
}
