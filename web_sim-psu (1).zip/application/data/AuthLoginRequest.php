<?php

class AuthLoginRequest
{
	public $username = null;
	public $password = null;
}
