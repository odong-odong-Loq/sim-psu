<?php

class Berita
{
	public $id;
	public $gambar;
	public $judul;
	public $slug;
	public $isi;
	public $tanggalDibuat;
	public $idPengguna;
}
