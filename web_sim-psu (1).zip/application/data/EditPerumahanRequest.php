<?php

class EditPerumahanRequest
{
	public $id;
	public $nama;
	public $perusahaan;
	public $longitude;
	public $latitude;
}
