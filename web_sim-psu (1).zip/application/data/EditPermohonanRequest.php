<?php

class EditPermohonanRequest
{
	public $id;
	public $namaPemohon;
	public $alamatPemohon;
	public $kelurahanPemohon;
	public $kecamatanPemohon;
	public $kotaPemohon;
	public $alamatPerumahan;
	public $kelurahanPerumahan;
	public $kecamatanPerumahan;
	public $kotaPerumahan;
	public $tipePerumahan;
	public $luasKav;
	public $luasEfektif;
	public $luasFasum;
	public $luasTpu;
	public $jumlahUnit;
	public $nomorSuratPengesahan;
	public $tanggalTerbit;
	public $keterangan;
	public $berkasPermohonan;
	public $statusBerkasPermohonan = 0;
	public $berkasPrasarana;
	public $statusBerkasPrasarana = 0;
	public $berkasSarana;
	public $statusBerkasSarana = 0;
	public $berkasBeritaAcara;
	public $statusBerkasBeritaAcara = 0;
	public $berkasLainnya;
	public $statusBerkasLainnya = 0;
	public $statusPenyerahan = 0;
	public $idPerumahan;
}
