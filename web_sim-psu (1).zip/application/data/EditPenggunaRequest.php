<?php

class EditPenggunaRequest
{
	public $id;
	public $namaLengkap;
	public $username;
	public $password;
}
