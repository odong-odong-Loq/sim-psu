<?php

class Slide
{
	public $id;
	public $gambar;
}
