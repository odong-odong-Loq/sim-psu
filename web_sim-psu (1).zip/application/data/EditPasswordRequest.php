<?php

class EditPasswordRequest
{
	public $id;
	public $password;
	public $passwordBaru;
}
