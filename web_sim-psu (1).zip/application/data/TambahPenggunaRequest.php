<?php

class TambahPenggunaRequest
{
	public $namaLengkap;
	public $username;
	public $password;
}
