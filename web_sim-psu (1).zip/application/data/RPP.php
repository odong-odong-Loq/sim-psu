<?php

class RPP
{
	public $id;
	public $TanggalSuratPermohonan;
	public $TanggalDisposisi;
	public $NamaPemohon;
	public $Lokasi;
	public $KoordinatX;
	public $KoordinatY;
	public $nib;
	public $TipeHak;
	public $luas;
	public $rpp;
	public $kawasan;
	public $NomorSuratTugas;
	public $TanggalSuratTugas;
	public $NomorSKRK;
	public $TanggalSKRK;
	public $ket;
	 
}
