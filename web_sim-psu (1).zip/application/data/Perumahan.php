<?php

class Perumahan
{
	public $id;
	public $nama;
	public $perusahaan;
	public $longitude;
	public $latitude;
}
