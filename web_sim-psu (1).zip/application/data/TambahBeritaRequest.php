<?php

class TambahBeritaRequest
{
	public $judul;
	public $isi;
}
