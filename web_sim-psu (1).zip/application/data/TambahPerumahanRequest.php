<?php

class TambahPerumahanRequest
{
	public $nama;
	public $perusahaan;
	public $longitude;
	public $latitude;
}
