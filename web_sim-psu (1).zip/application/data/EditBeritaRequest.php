<?php

class EditBeritaRequest
{
	public $id;
	public $judul;
	public $isi;
}
