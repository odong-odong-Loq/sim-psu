<?php

class EditProfileRequest
{
	public $id;
	public $namaLengkap;
	public $foto;
}
