<?php

class Permohonan
{
	public $id;
	public $namaPemohon;
	public $alamatPemohon;
	public $kelurahanPemohon;
	public $kecamatanPemohon;
	public $kotaPemohon;
	public $alamatPerumahan;
	public $kelurahanPerumahan;
	public $kecamatanPerumahan;
	public $kotaPerumahan;
	public $tipePerumahan;
	public $luasKav;
	public $luasEfektif;
	public $luasFasum;
	public $luasTpu;
	public $jumlahUnit;
	public $nomorSuratPengesahan;
	public $tanggalTerbit;
	public $keterangan;
	public $berkasPermohonan;
	public $statusBerkasPermohonan;
	public $berkasPrasarana;
	public $statusBerkasPrasarana;
	public $berkasSarana;
	public $statusBerkasSarana;
	public $berkasBeritaAcara;
	public $statusBerkasBeritaAcara;
	public $berkasLainnya;
	public $statusBerkasLainnya;
	public $statusPenyerahan;
	public $idPerumahan;
	public $perumahan;
}
