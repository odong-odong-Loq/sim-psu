<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<h3>
			<strong>DASAR HUKUM PRASARANA, SARANA, DAN UTILITAS UMUM </strong>
		</h3>
		<hr>
		<div class="row">
			<p></p>
			<ol>
				<li>Undang-Undang Nomor 1 Tahun 2011 tentang Perumahan dan Kawasan Permukiman</li>
				<li>Peraturan Menteri Dalam Negeri Nomor 9 Tahun 2009 tentang Pedoman Penyerahan Prasarana, Sarana, dan
					Utilitas Perumahan dan Permukiman di Daerah
				</li>
				<li>Peraturan Menteri Pekerjaan Umum dan Perumahan Rakyat Republik Indonesia Nomor 7 Tahun 2022 Tentang
					Pelaksanaan Bantuan Pembangunan Perumahan dan Penyediaan Rumah Khusus
				</li>
				<li>Peraturan Daerah Kota Sukabumi Nomor 12 Tahun 2016 Tentang Penyelenggaraan Prasarana, Sarana, Dan
					Utilitas Umum Perumahan
				</li>
				<li>Keputusan Wali Kota Sukabumi Nomor 188.45/203-DPUTR/2022 Tentang Pembentukan Tim Verifikasi
					Penyerahan Prasarana, Sarana, dan Utilitas Umum Perumahan di Kota Sukabumi
				</li>
			</ol>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
