<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Data Perumahan</h3>
							<div class="card-actions">
								<a href="#" class="btn btn-icon btn-sm btn-primary" data-bs-toggle="modal"
								   data-bs-target="#tambah-perumahan-modal">
									<i class="fa-solid fa-plus"></i>
									<span class="ms-1 d-none d-sm-block">Tambah Perumahan</span>
								</a>
							</div>
						</div>
						<div class="card-body">
							<table class="table table-vcenter table-striped" id="tabel-perumahan">
								<thead>
								<tr>
									<th width="1%" class="text-center bg-primary text-light">No</th>
									<th class="bg-primary text-light">Nama</th>
									<th class="bg-primary text-light">Perusahaan</th>
									<th class="bg-primary text-light">Latitude</th>
									<th class="bg-primary text-light">Longitude</th>
									<th width="5%" class="text-center bg-primary text-light">Aksi</th>
								</tr>
								</thead>
								<tbody class="table-tbody">
								<?php foreach ($perumahan as $index => $data): ?>
									<tr>
										<td class="text-center px-0"><?= $index + 1 ?></td>
										<td><?= $data->nama ?></td>
										<td><?= $data->perusahaan ?></td>
										<td><?= $data->latitude ?></td>
										<td><?= $data->longitude ?></td>
										<td class="text-center">
											<div class="d-inline-block">
												<div class="btn-list flex-nowrap">
													<a href="<?= base_url() ?>perumahan/edit?id=<?= $data->id ?>"
													   class="btn btn-icon btn-sm btn-success">
														<i class="fa-solid fa-pen-to-square"></i>
														<span class="ms-1 d-none d-sm-block">Edit</span>
													</a>
													<a href="#" class="btn btn-icon btn-sm btn-danger"
													   data-bs-toggle="modal"
													   data-bs-target="#hapus-perumahan-modal"
													   data-value="<?= $data->id ?>"
													   onclick="hapusPerumahanHandler(this)">
														<i class="fa-solid fa-trash"></i>
														<span class="ms-1 d-none d-sm-block">Hapus</span>
													</a>
												</div>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/perumahan/tambah-modal") ?>
<?php $this->load->view("pengguna/partials/perumahan/edit-modal") ?>
<?php $this->load->view("pengguna/partials/perumahan/hapus-modal") ?>

<script>
	function hapusPerumahanHandler(el) {
		$('#hapus-perumahan-modal :input[name="id"]').val($(el).data('value'));
	}

	document.addEventListener("DOMContentLoaded", function (event) {
		$('#tabel-perumahan').DataTable({
			"paging": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			language: {
				"paginate": {
					"previous": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-left</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg></span>',
					"next": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-right</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg></span>',
				},
			},
		});

		$("#tabel-perumahan_wrapper").children(".row")[0].classList.add("mb-3");
		$("#tabel-perumahan_wrapper").children(".row")[2].classList.add("mb-3");
		$("#tabel_perumahan_length").addClass("mt-2");
		$("#tabel-perumahan_info").addClass("mt-2");
		$("#tabel-perumahan_paginate").addClass("mt-2");
		$("#tabel-perumahan_filter").addClass("mt-2 mt-sm-0");

		<?php if ($this->session->flashdata('show_tambah_perumahan_modal') !== null): ?>
		$('#tambah-perumahan-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_edit_perumahan_modal') !== null): ?>
		$('#edit-perumahan-modal').modal('show')
		<?php endif; ?>
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
