<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Edit Permohonan</h3>
							<div class="card-actions">
								<a href="<?= base_url() ?>permohonan" class="btn btn-icon btn-sm btn-primary">
									<i class="fa-solid fa-table"></i>
									<span class="ms-1 d-none d-sm-block">Data Permohonan</span>
								</a>
							</div>
						</div>
						<form id="form" action="<?= base_url() ?>permohonan/post-edit" method="post"
							  enctype="multipart/form-data">
							<div class="card-body">
								<input type="hidden" id="id" name="id" value="<?= $permohonan->id ?>">

								<div class="row">
									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="nomor_surat_pengesahan">
												Nomor Surat Pengesahan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['nomor_surat_pengesahan']) ? 'is-invalid' : '' ?>"
													   id="nomor_surat_pengesahan" name="nomor_surat_pengesahan"
													   placeholder="Masukkan nomor surat pengesahan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['nomor_surat_pengesahan'] ?? $permohonan->nomorSuratPengesahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['nomor_surat_pengesahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="tanggal_terbit">
												Tanggal Terbit
											</label>
											<div class="col">
												<input type="date"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['tanggal_terbit']) ? 'is-invalid' : '' ?>"
													   id="tanggal_terbit" name="tanggal_terbit"
													   placeholder="Masukkan alamat"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['tanggal_terbit'] ?? $permohonan->tanggalTerbit ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['tanggal_terbit'] ?? '' ?>
												</div>
											</div>
										</div>
									</div>

									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="keterangan">
												Keterangan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['keterangan']) ? 'is-invalid' : '' ?>"
													   id="keterangan" name="keterangan"
													   placeholder="Masukkan keterangan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['keterangan'] ?? $permohonan->keterangan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['keterangan'] ?? '' ?>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">Data Pemohon
								</div>
								<div class="row">
									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="nama_pemohon">
												Nama Lengkap
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['nama_pemohon']) ? 'is-invalid' : '' ?>"
													   id="nama_pemohon" name="nama_pemohon"
													   placeholder="Masukkan nama lengkap"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['nama_pemohon'] ?? $permohonan->namaPemohon ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['nama_pemohon'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="alamat_pemohon">
												Alamat
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['alamat_pemohon']) ? 'is-invalid' : '' ?>"
													   id="alamat_pemohon" name="alamat_pemohon"
													   placeholder="Masukkan alamat"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['alamat_pemohon'] ?? $permohonan->alamatPemohon ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['alamat_pemohon'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kecamatan_pemohon">
												Kecamatan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kecamatan_pemohon']) ? 'is-invalid' : '' ?>"
													   id="kecamatan_pemohon" name="kecamatan_pemohon"
													   placeholder="Masukkan kecamatan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kecamatan_pemohon'] ?? $permohonan->kecamatanPemohon ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kecamatan_pemohon'] ?? '' ?>
												</div>
											</div>
										</div>
									</div>

									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kelurahan_pemohon">
												Kelurahan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kelurahan_pemohon']) ? 'is-invalid' : '' ?>"
													   id="kelurahan_pemohon" name="kelurahan_pemohon"
													   placeholder="Masukkan kelurahan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kelurahan_pemohon'] ?? $permohonan->kelurahanPemohon ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kelurahan_pemohon'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kota_pemohon">
												Kota
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kota_pemohon']) ? 'is-invalid' : '' ?>"
													   id="kota_pemohon" name="kota_pemohon"
													   placeholder="Masukkan kota"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kota_pemohon'] ?? $permohonan->kotaPemohon ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kota_pemohon'] ?? '' ?>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">Data Perumahan
								</div>
								<div class="row">
									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="id_perumahan">
												Perumahan
											</label>
											<div class="col">
												<select type="text"
														class="form-select <?= isset($this->session->flashdata('validation_errors')['id_perumahan']) ? 'is-invalid' : '' ?>"
														id="id_perumahan"
														name="id_perumahan"
														required
												>
													<option value="">Pilih Perumahan</option>
													<?php foreach ($perumahan as $data): ?>
														<option
															value="<?= $data->id ?>" <?= $data->id == $permohonan->idPerumahan ? 'selected' : '' ?> ><?= $data->nama ?></option>
													<?php endforeach; ?>
												</select>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['id_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="tipe_perumahan">
												Tipe
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['tipe_perumahan']) ? 'is-invalid' : '' ?>"
													   id="tipe_perumahan" name="tipe_perumahan"
													   placeholder="Masukkan tipe"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['tipe_perumahan'] ?? $permohonan->tipePerumahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['tipe_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="alamat_perumahan">
												Alamat
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['alamat_perumahan']) ? 'is-invalid' : '' ?>"
													   id="alamat_perumahan" name="alamat_perumahan"
													   placeholder="Masukkan alamat"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['alamat_perumahan'] ?? $permohonan->alamatPerumahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['alamat_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kecamatan_perumahan">
												Kecamatan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kecamatan_perumahan']) ? 'is-invalid' : '' ?>"
													   id="kecamatan_perumahan" name="kecamatan_perumahan"
													   placeholder="Masukkan kecamatan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kecamatan_perumahan'] ?? $permohonan->kecamatanPerumahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kecamatan_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kelurahan_perumahan">
												Kelurahan
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kelurahan_perumahan']) ? 'is-invalid' : '' ?>"
													   id="kelurahan_perumahan" name="kelurahan_perumahan"
													   placeholder="Masukkan kecamatan"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kelurahan_perumahan'] ?? $permohonan->kelurahanPerumahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kelurahan_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="kota_perumahan">
												Kota
											</label>
											<div class="col">
												<input type="text"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['kota_perumahan']) ? 'is-invalid' : '' ?>"
													   id="kota_perumahan" name="kota_perumahan"
													   placeholder="Masukkan kota"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['kota_perumahan'] ?? $permohonan->kotaPerumahan ?>"
													   required
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['kota_perumahan'] ?? '' ?>
												</div>
											</div>
										</div>
									</div>

									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="jumlah_unit">
												Jumlah Unit
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['jumlah_unit']) ? 'is-invalid' : '' ?>"
													   id="jumlah_unit" name="jumlah_unit"
													   placeholder="Masukkan jumlah unit"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['jumlah_unit'] ?? $permohonan->jumlahUnit ?>"
													   required
													   min="0"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['jumlah_unit'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="luas_kav">
												Luas Kav
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['luas_kav']) ? 'is-invalid' : '' ?>"
													   id="luas_kav" name="luas_kav"
													   placeholder="Masukkan luas kav"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['luas_kav'] ?? $permohonan->luasKav ?>"
													   required
													   min="0"
													   step=".01"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['luas_kav'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="luas_efektif">
												Luas Efektif
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['luas_efektif']) ? 'is-invalid' : '' ?>"
													   id="luas_efektif" name="luas_efektif"
													   placeholder="Masukkan luas efektif"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['luas_efektif'] ?? $permohonan->luasEfektif ?>"
													   required
													   min="0"
													   step=".01"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['luas_efektif'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="luas_fasum">
												Luas Fasum
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['luas_fasum']) ? 'is-invalid' : '' ?>"
													   id="luas_fasum" name="luas_fasum"
													   placeholder="Masukkan luas fasum"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['luas_fasum'] ?? $permohonan->luasFasum ?>"
													   required
													   min="0"
													   step=".01"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['luas_fasum'] ?? '' ?>
												</div>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="luas_tpu">
												Luas TPU
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['luas_tpu']) ? 'is-invalid' : '' ?>"
													   id="luas_tpu" name="luas_tpu"
													   placeholder="Masukkan luas tpu"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['luas_tpu'] ?? $permohonan->luasTpu ?>"
													   required
													   min="0"
													   step=".01"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['luas_tpu'] ?? '' ?>
												</div>
											</div>
										</div>
										
										<div class="mb-3 row">
											<label class="col-12 col-form-label required" for="luas_tpu">
												Luas RTH
											</label>
											<div class="col">
												<input type="number"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['luasRTH']) ? 'is-invalid' : '' ?>"
													   id="luas_tpu" name="luasRTH"
													   placeholder="Masukkan luas RTH"
													   value="<?= $this->session->flashdata('old_edit_permohonan')['luasRTH'] ?? $permohonan->luasRTH ?>"
													   required
													   min="0"
													   step=".01"
												>
												<div class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['luasRTH'] ?? '' ?>
												</div>
											</div>
										</div>
										
									</div>
								</div>

								<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">Berkas
									Permohonan
								</div>
								<div class="row">
									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label" for="berkas_permohonan">
												Berkas Permohonan
											</label>
											<div class="col">
												<input type="file"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['berkas_permohonan']) ? 'is-invalid' : '' ?>"
													   id="berkas_permohonan" name="berkas_permohonan"
												>
												<small class="form-hint">Maksimal ukuran berkas 5MB dan ekstensi yang
													diperbolehkan doc, docx, dan pdf.</small>
												<div id="berkas_permohonan_invalid_feedback" class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['berkas_permohonan'] ?? '' ?>
												</div>
												<label class="form-check mt-2 mb-1">
													<input class="form-check-input" type="checkbox" value="1"
														   name="status_berkas_permohonan"
														<?= $permohonan->statusBerkasPermohonan == 1 ? 'checked' : '' ?>
													>
													<span class="form-check-label">Terverifikasi</span>
												</label>
												<?php if ($permohonan->berkasPermohonan != null) : ?>
													<span class="small">
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasPermohonan ?>"
													   download>Download berkas</a>
													|
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasPermohonan ?>"
													   target="_blank">Preview berkas</a>
												</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="mb-3 row">
											<label class="col-12 col-form-label" for="berkas_prasarana">
												Berkas Prasarana
											</label>
											<div class="col">
												<input type="file"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['berkas_prasarana']) ? 'is-invalid' : '' ?>"
													   id="berkas_prasarana" name="berkas_prasarana"
												>
												<small class="form-hint">Maksimal ukuran berkas 5MB dan ekstensi yang
													diperbolehkan doc, docx, dan pdf.</small>
												<div id="berkas_prasarana_invalid_feedback" class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['berkas_prasarana'] ?? '' ?>
												</div>
												<label class="form-check mt-2 mb-1">
													<input class="form-check-input" type="checkbox" value="1"
														   name="status_berkas_prasarana"
														<?= $permohonan->statusBerkasPrasarana == 1 ? 'checked' : '' ?>
													>
													<span class="form-check-label">Terverifikasi</span>
												</label>
												<?php if ($permohonan->berkasPrasarana != null) : ?>
													<span class="small">
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasPrasarana ?>"
													   download>Download berkas</a>
													|
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasPrasarana ?>"
													   target="_blank">Preview berkas</a>
												</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="mb-3 mb-sm-0 row">
											<label class="col-12 col-form-label" for="berkas_sarana">
												Berkas Sarana
											</label>
											<div class="col">
												<input type="file"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['berkas_sarana']) ? 'is-invalid' : '' ?>"
													   id="berkas_sarana" name="berkas_sarana"
												>
												<small class="form-hint">Maksimal ukuran berkas 5MB dan ekstensi yang
													diperbolehkan doc, docx, dan pdf.</small>
												<div id="berkas_sarana_invalid_feedback" class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['berkas_sarana'] ?? '' ?>
												</div>
												<label class="form-check mt-2 mb-1">
													<input class="form-check-input" type="checkbox" value="1"
														   name="status_berkas_sarana"
														<?= $permohonan->statusBerkasSarana == 1 ? 'checked' : '' ?>
													>
													<span class="form-check-label">Terverifikasi</span>
												</label>
												<?php if ($permohonan->berkasSarana != null) : ?>
													<span class="small">
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasSarana ?>"
													   download>Download berkas</a>
													|
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasSarana ?>"
													   target="_blank">Preview berkas</a>
												</span>
												<?php endif; ?>
											</div>
										</div>
									</div>

									<div class="col-12 col-sm-6">
										<div class="mb-3 row">
											<label class="col-12 col-form-label" for="berkas_berita_acara">
												Berkas Berita Acara
											</label>
											<div class="col">
												<input type="file"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['berkas_berita_acara']) ? 'is-invalid' : '' ?>"
													   id="berkas_berita_acara" name="berkas_berita_acara"
												>
												<small class="form-hint">Maksimal ukuran berkas 5MB dan ekstensi yang
													diperbolehkan doc, docx, dan pdf.</small>
												<div id="berkas_berita_acara_invalid_feedback" class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['berkas_berita_acara'] ?? '' ?>
												</div>
												<label class="form-check mt-2 mb-1">
													<input class="form-check-input" type="checkbox" value="1"
														   name="status_berkas_berita_acara"
														<?= $permohonan->statusBerkasBeritaAcara == 1 ? 'checked' : '' ?>
													>
													<span class="form-check-label">Terverifikasi</span>
												</label>
												<?php if ($permohonan->berkasBeritaAcara != null) : ?>
													<span class="small">
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasBeritaAcara ?>"
													   download>Download berkas</a>
													|
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasBeritaAcara ?>"
													   target="_blank">Preview berkas</a>
												</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="mb-0 mb-sm-3 row">
											<label class="col-12 col-form-label" for="berkas_lainnya">
												Berkas Lainnya
											</label>
											<div class="col">
												<input type="file"
													   class="form-control <?= isset($this->session->flashdata('validation_errors')['berkas_lainnya']) ? 'is-invalid' : '' ?>"
													   id="berkas_lainnya" name="berkas_lainnya"
												>
												<small class="form-hint">Maksimal ukuran berkas 5MB dan ekstensi yang
													diperbolehkan doc, docx, dan pdf.</small>
												<div id="berkas_lainnya_invalid_feedback" class="invalid-feedback">
													<?= $this->session->flashdata('validation_errors')['berkas_lainnya'] ?? '' ?>
												</div>
												<label class="form-check mt-2 mb-1">
													<input class="form-check-input" type="checkbox" value="1"
														   name="status_berkas_lainnya" <?= $permohonan->statusBerkasLainnya == 1 ? 'checked' : '' ?>
													>
													<span class="form-check-label">Terverifikasi</span>
												</label>
												<?php if ($permohonan->berkasLainnya != null) : ?>
													<span class="small">
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasLainnya ?>"
													   download>Download berkas</a>
													|
													<a href="<?= base_url() ?>public/uploads/permohonan/<?= $permohonan->berkasLainnya ?>"
													   target="_blank">Preview berkas</a>
												</span>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class=" card-footer text-end">
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		$("#id_perumahan").select2({
			theme: 'bootstrap-5'
		});

		$(".select2-container").css("width", "100%");

		$.validator.addMethod('filesize', function (value, element, param) {
			return this.optional(element) || (element.files[0].size <= param * 1000000)
		}, 'Ukuran berkas lebih dari {0}MB');

		$("#form").validate({
			ignore: "input:not(#berkas_permohonan,#berkas_prasarana,#berkas_sarana,#berkas_berita_acara,#berkas_lainnya),select",
			errorClass: "is-invalid",
			rules: {
				berkas_permohonan: {
					required: false,
					extension: "doc|docx|pdf",
					filesize: 5
				},
				berkas_prasarana: {
					required: false,
					extension: "doc|docx|pdf",
					filesize: 5
				},
				berkas_sarana: {
					required: false,
					extension: "doc|docx|pdf",
					filesize: 5
				},
				berkas_berita_acara: {
					required: false,
					extension: "doc|docx|pdf",
					filesize: 5
				},
				berkas_lainnya: {
					required: false,
					extension: "doc|docx|pdf",
					filesize: 5
				},
			},
			messages: {
				berkas_permohonan: {
					extension: "Ekstensi berkas tidak valid."
				},
				berkas_prasarana: {
					extension: "Ekstensi berkas tidak valid."
				},
				berkas_sarana: {
					extension: "Ekstensi berkas tidak valid."
				},
				berkas_berita_acara: {
					extension: "Ekstensi berkas tidak valid."
				},
				berkas_lainnya: {
					extension: "Ekstensi berkas tidak valid."
				},
			},
			errorPlacement: function (error, element) {
				if (element.attr("name") == "berkas_permohonan") {
					$("#berkas_permohonan_invalid_feedback").html(error);
				} else if (element.attr("name") == "berkas_prasarana") {
					$("#berkas_prasarana_invalid_feedback").html(error);
				} else if (element.attr("name") == "berkas_sarana") {
					$("#berkas_sarana_invalid_feedback").html(error);
				} else if (element.attr("name") == "berkas_berita_acara") {
					$("#berkas_berita_acara_invalid_feedback").html(error);
				} else if (element.attr("name") == "berkas_lainnya") {
					$("#berkas_lainnya_invalid_feedback").html(error);
				}
			},
		});
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
