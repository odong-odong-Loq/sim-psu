<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Data Penyerahan Aset</h3>
						</div>
						<div class="card-body">
							<form action="<?= base_url() ?>penyerahan-aset" method="get" class="mb-4 d-flex align-items-center gap-2 justify-content-center justify-content-sm-start">
								<label class="form-check-inline mr-1 mr-sm-2">
									Filter Tahun:
								</label>
								<select class="form-select d-inline w-auto mr-sm-2" name="tahun">
									<?php foreach ($tahunData as $tahun): ?>
										<option
											value="<?= $tahun ?>" <?= $selectedTahun == $tahun ? "selected" : "" ?>><?= $tahun ?>
										</option>
									<?php endforeach; ?>
								</select>

								<button type="submit" class="btn btn-primary">Filter</button>
							</form>
							<table class="table table-vcenter table-striped" id="tabel-permohonan">
								<thead>
								<tr>
									<th width="1%" class="text-center bg-primary text-light">No</th>
									<th class="bg-primary text-light">Pemohon</th>
									<th class="bg-primary text-light">Perumahan</th>
									<th class="bg-primary text-light">Perusahaan</th>
									<th class="bg-primary text-light text-center">Kelengkapan Berkas</th>
									<th width="5%" class="text-center bg-primary text-light">Aksi</th>
								</tr>
								</thead>
								<tbody class="table-tbody">
								<?php foreach ($permohonan as $index => $data): ?>
									<tr>
										<td class="text-center px-0"><?= $index + 1 ?></td>
										<td><?= $data->namaPemohon ?></td>
										<td><?= $data->perumahan->nama ?></td>
										<td><?= $data->perumahan->perusahaan ?></td>
										<td class="text-center">
											<?= ($data->statusBerkasPermohonan + $data->statusBerkasPrasarana + $data->statusBerkasSarana + $data->statusBerkasBeritaAcara + $data->statusBerkasLainnya) * 20 ?>
											%
										</td>
										<td class="text-center">
											<div class="d-inline-block">
												<div class="btn-list flex-nowrap">
													<a href="<?= base_url() ?>permohonan/detail?id=<?= $data->id ?>"
													   class="btn btn-icon btn-sm btn-info">
														<i class="fa-solid fa-circle-info"></i>
														<span class="ms-1 d-none d-sm-block">Detail</span>
													</a>
												</div>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/permohonan/detail-modal") ?>

<script>
	function hapusPermohonanHandler(el) {
		$('#hapus-permohonan-modal :input[name="id"]').val($(el).data('value'));
	}

	document.addEventListener("DOMContentLoaded", function (event) {
		$('#tabel-permohonan').DataTable({
			"paging": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			language: {
				"paginate": {
					"previous": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-left</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg></span>',
					"next": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-right</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg></span>',
				},
			},
		});

		$("#tabel-permohonan_wrapper").children(".row")[0].classList.add("mb-3");
		$("#tabel-permohonan_wrapper").children(".row")[2].classList.add("mb-3");
		$("#tabel_permohonan_length").addClass("mt-2");
		$("#tabel-permohonan_info").addClass("mt-2");
		$("#tabel-permohonan_paginate").addClass("mt-2");
		$("#tabel-permohonan_filter").addClass("mt-2 mt-sm-0");

		<?php if ($this->session->flashdata('show_tambah_permohonan_modal') !== null): ?>
		$('#tambah-permohonan-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_edit_permohonan_modal') !== null): ?>
		$('#edit-permohonan-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_detail_permohonan_modal') !== null): ?>
		$('#detail-permohonan-modal').modal('show')
		<?php endif; ?>
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
