<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-sm-6 col-lg-4">
					<div class="card card-sm">
						<div class="card-body">
							<div class="row align-items-center">
								<div class="col-auto">
									<span class="bg-primary text-white avatar">
										<i class="fa-solid fa-handshake"></i>
									</span>
								</div>
								<div class="col">
									<div class="font-weight-medium">
										<?= $jumlahPenyerahanAset ?> Permohonan
									</div>
									<div class="text-secondary">
										sudah diserahkan
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-sm-6 col-lg-4">
					<div class="card card-sm">
						<div class="card-body">
							<div class="row align-items-center">
								<div class="col-auto">
									<span class="bg-yellow text-white avatar">
										<i class="fa-solid fa-file-circle-check"></i>
									</span>
								</div>
								<div class="col">
									<div class="font-weight-medium">
										<?= $jumlahPermohonanTerverifikasi ?> Permohonan
									</div>
									<div class="text-secondary">
										belum dilakukan penyerahan
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-sm-6 col-lg-4">
					<div class="card card-sm">
						<div class="card-body">
							<div class="row align-items-center">
								<div class="col-auto">
									<span class="bg-secondary text-white avatar">
										<i class="fa-solid fa-file"></i>
									</span>
								</div>
								<div class="col">
									<div class="font-weight-medium">
										<?= $jumlahPermohonan ?> Permohonan
									</div>
									<div class="text-secondary">
										berkas belum lengkap
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/close-tag") ?>
