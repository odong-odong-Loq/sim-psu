<div class="modal modal-blur fade" id="detail-permohonan-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Detail Permohonan</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Nomor Surat Pengesahan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['nomorSuratPengesahan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Tanggal Terbit</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['tanggalTerbit'] ?? '' ?>
							</span>
						</address>
					</div>

					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Keterangan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['keterangan'] ?? '' ?>
							</span>
						</address>
					</div>
				</div>

				<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">
					Data Pemohon
				</div>
				<div class="row">
					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Nama Lengkap</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['namaPemohon'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Alamat</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['alamatPemohon'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Kecamatan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kecamatanPemohon'] ?? '' ?>
							</span>
						</address>
					</div>

					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Kelurahan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kecamatanPemohon'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Kota</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kotaPemohon'] ?? '' ?>
							</span>
						</address>
					</div>
				</div>

				<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">
					Data Perumahan
				</div>
				<div class="row">
					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Perumahan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['perumahan']['nama'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Tipe</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['tipePerumahan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Alamat</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['alamatPerumahan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Kecamatan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kecamatanPerumahan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Kelurahan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kelurahanPerumahan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Kota</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['kotaPerumahan'] ?? '' ?>
							</span>
						</address>
					</div>

					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Jumlah Unit</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['jumlahUnit'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Luas Kav</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['luasKav'] ?? '' ?>m<sup>2</sup>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Luas Efektif</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['luasEfektif'] ?? '' ?>m<sup>2</sup>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Luas Fasum</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['luasFasum'] ?? '' ?>m<sup>2</sup>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Luas TPU</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['luasTpu'] ?? '' ?>m<sup>2</sup>
							</span>
						</address>
												
						<address class="row">
							<strong class="col-12">Luas RTH</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['luasRTH'] ?? '' ?>m<sup>2</sup>
							</span>
						</address>
					</div>
				</div>


				<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">
					Berkas Permohonan
				</div>
				<div class="row">
					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Berkas Permohonan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['berkasPermohonan'] ?? '' ?>
								<?php if ($this->session->flashdata('permohonan')['statusBerkasPermohonan'] != 0) : ?>
									<span class="badge bg-blue text-light badge-pill"
										  style="font-size: .1rem;padding: 0">
										<i class="fa-regular fa-circle-check"></i>
									</span>
								<?php endif; ?>
								<?php if ($this->session->flashdata('permohonan')['berkasPermohonan'] != null) : ?>
									<div class="small">
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasPermohonan'] ?>"
										   download>Download berkas
										</a>
										|
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasPermohonan'] ?>"
										   target="_blank">Preview berkas</a>
									</div>
								<?php endif; ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Berkas Prasarana</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['berkasPrasarana'] ?? '' ?>
								<?php if ($this->session->flashdata('permohonan')['statusBerkasPrasarana'] != 0) : ?>
									<span class="badge bg-blue text-light badge-pill"
										  style="font-size: .1rem;padding: 0">
										<i class="fa-regular fa-circle-check"></i>
									</span>
								<?php endif; ?>
								<?php if ($this->session->flashdata('permohonan')['berkasPrasarana'] != null) : ?>
									<div class="small">
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasPrasarana'] ?>"
										   download>Download berkas
										</a>
										|
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasPrasarana'] ?>"
										   target="_blank">Preview berkas</a>
									</div>
								<?php endif; ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Berkas Sarana</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['berkasSarana'] ?? '' ?>
								<?php if ($this->session->flashdata('permohonan')['statusBerkasSarana'] != 0) : ?>
									<span class="badge bg-blue text-light badge-pill"
										  style="font-size: .1rem;padding: 0">
										<i class="fa-regular fa-circle-check"></i>
									</span>
								<?php endif; ?>
								<?php if ($this->session->flashdata('permohonan')['berkasSarana'] != null) : ?>
									<div class="small">
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasSarana'] ?>"
										   download>Download berkas
										</a>
										|
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasSarana'] ?>"
										   target="_blank">Preview berkas</a>
									</div>
								<?php endif; ?>
							</span>
						</address>
					</div>

					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Berkas Berita Acara</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['berkasBeritaAcara'] ?? '' ?>
								<?php if ($this->session->flashdata('permohonan')['statusBerkasBeritaAcara'] != 0) : ?>
									<span class="badge bg-blue text-light badge-pill"
										  style="font-size: .1rem;padding: 0">
										<i class="fa-regular fa-circle-check"></i>
									</span>
								<?php endif; ?>
								<?php if ($this->session->flashdata('permohonan')['berkasBeritaAcara'] != null) : ?>
									<div class="small">
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasBeritaAcara'] ?>"
										   download>Download berkas
										</a>
										|
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasBeritaAcara'] ?>"
										   target="_blank">Preview berkas</a>
									</div>
								<?php endif; ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Berkas Lainnya</strong>
							<span class="col-12">
								<?= $this->session->flashdata('permohonan')['berkasLainnya'] ?? '' ?>
								<?php if ($this->session->flashdata('permohonan')['statusBerkasLainnya'] != 0) : ?>
									<span class="badge bg-blue text-light badge-pill"
										  style="font-size: .1rem;padding: 0">
										<i class="fa-regular fa-circle-check"></i>
									</span>
								<?php endif; ?>
								<?php if ($this->session->flashdata('permohonan')['berkasLainnya'] != null) : ?>
									<div class="small">
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasLainnya'] ?>"
										   download>Download berkas
										</a>
										|
										<a href="<?= base_url() ?>public/uploads/permohonan/<?= $this->session->flashdata('permohonan')['berkasLainnya'] ?>"
										   target="_blank">Preview berkas</a>
									</div>
								<?php endif; ?>
							</span>
						</address>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn ms-auto" data-bs-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>
