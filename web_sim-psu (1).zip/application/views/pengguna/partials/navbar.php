<header class="navbar navbar-expand-md d-none d-lg-flex d-print-none">
	<div class="container-xl">
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu"
				aria-controls="navbar-menu" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="navbar-nav flex-row justify-content-end w-100">
			<div class="nav-item dropdown">
				<a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown"
				   aria-label="Open user menu">
					<span class="avatar avatar-sm avatar-rounded"
						  style="background-image: url(<?= base_url() ?>public/uploads/pengguna/<?= $this->session->userdata("pengguna")["foto"] ?>)"></span>
					<div class="d-none d-xl-block ps-2">
						<div><?= $this->session->userdata("pengguna")["namaLengkap"] ?></div>
						<div
							class="mt-1 small text-secondary"><?= $this->session->userdata("pengguna")["role"] ?></div>
					</div>
				</a>
				<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
					<a href="<?= base_url() ?>pengaturan"
					   class="dropdown-item small">Pengaturan</a>
					<a href="<?= base_url() ?>logout"
					   class="dropdown-item small">Logout</a>
				</div>
			</div>
		</div>
	</div>
</header>
