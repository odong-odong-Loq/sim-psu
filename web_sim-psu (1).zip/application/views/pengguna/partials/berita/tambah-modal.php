<div class="modal modal-blur fade" id="tambah-berita-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Tambah Berita</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>berita/post-tambah" method="post" enctype="multipart/form-data">
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="gambar">Gambar</label>
						<div class="col">
							<input type="file"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['gambar']) ? 'is-invalid' : '' ?>"
								   id="gambar" name="gambar"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['gambar'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="judul">Judul</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['judul']) ? 'is-invalid' : '' ?>"
								   id="judul" name="judul"
								   placeholder="Masukkan judul"
								   value="<?= $this->session->flashdata('old_tambah_berita')['judul'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['judul'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="row">
						<label class="col-12 col-form-label pt-0 required" for="isi">Isi</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['isi']) ? 'is-invalid' : '' ?>"
								   id="isi" name="isi"
								   placeholder="Masukkan isi"
								   value="<?= $this->session->flashdata('old_tambah_berita')['isi'] ?? '' ?>"
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['isi'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
