<div class="modal modal-blur fade" id="edit-password-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Password</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>pengguna/post-edit-password" method="post">
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="password">Password</label>
						<div class="col">
							<input type="password"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['password']) ? 'is-invalid' : '' ?>"
								   id="password" name="password"
								   placeholder="Masukkan password"
								   value="<?= $this->session->flashdata('old_edit_password')['password'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['password'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="password_baru">Password Baru</label>
						<div class="col">
							<input type="password"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['password_baru']) ? 'is-invalid' : '' ?>"
								   id="password_baru" name="password_baru"
								   placeholder="Masukkan password baru"
								   value="<?= $this->session->flashdata('old_edit_password')['password_baru'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['password_baru'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="row">
						<label class="col-12 col-form-label pt-0 required" for="konfirmasi_password">Konfirmasi
							Password</label>
						<div class="col">
							<input type="password"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['konfirmasi_password']) ? 'is-invalid' : '' ?>"
								   id="konfirmasi_password" name="konfirmasi_password"
								   placeholder="Ketik ulang password baru"
								   value="<?= $this->session->flashdata('old_edit_password')['konfirmasi_password'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['konfirmasi_password'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
