<div class="modal modal-blur fade" id="edit-profile-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Profile</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>pengguna/post-edit-profile" method="post" enctype="multipart/form-data">
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0" for="gambar">Foto</label>
						<div class="col">
							<input type="file"
								   class="form-control <?= isset($this->session->flashdata('edit_profile_validation_errors')['gambar']) ? 'is-invalid' : '' ?>"
								   id="gambar" name="gambar"
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_profile_validation_errors')['gambar'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="row">
						<label class="col-12 col-form-label pt-0 required" for="nama_lengkap">Nama Lengkap</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('edit_profile_validation_errors')['nama_lengkap']) ? 'is-invalid' : '' ?>"
								   id="nama_lengkap" name="nama_lengkap"
								   placeholder="Masukkan nama lengkap"
								   value="<?= $this->session->flashdata('old_edit_profile')['nama_lengkap'] ?? $this->session->userdata('pengguna')['namaLengkap'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_profile_validation_errors')['nama_lengkap'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
