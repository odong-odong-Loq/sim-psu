<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		<?php if ($this->session->flashdata('message') !== null): ?>
		Swal.fire({
			title: "<?= $this->session->flashdata('message')['title'] ?>",
			text: "<?= $this->session->flashdata('message')['text'] ?>",
			icon: "<?= $this->session->flashdata('message')['icon'] ?>",
			cancelButtonText: 'Tutup',
			showCancelButton: true,
			showConfirmButton: false,
		})
		<?php endif; ?>
	});
</script>

<!-- Libs JS -->
<script src="<?= base_url() ?>public/assets/libs/jquery/jquery-3.6.0.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/jquery/jquery.validate.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/jquery/additional-methods.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/datatables/datatables.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/datatables/datatables.bootstrap5.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/datatables/responsive.bootstrap5.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/tinymce/tinymce.min.js"></script>
<script src="<?= base_url() ?>public/assets/libs/select2/js/select2.full.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Tabler Core -->
<script src="<?= base_url() ?>public/assets/libs/tabler/js/tabler.min.js?1692870487" defer></script>
<script src="<?= base_url() ?>public/assets/libs/tabler/js/demo.min.js?1692870487" defer></script>

</body>
</html>
