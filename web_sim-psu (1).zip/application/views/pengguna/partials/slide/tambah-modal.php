<div class="modal modal-blur fade" id="tambah-slide-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Tambah Slide</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>slide/post-tambah" method="post" enctype="multipart/form-data">
				<div class="modal-body">
					<div class="row">
						<label class="col-12 col-form-label pt-0 required" for="gambar">Gambar</label>
						<div class="col">
							<input type="file"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['gambar']) ? 'is-invalid' : '' ?>"
								   id="gambar" name="gambar"
								   value="<?= $this->session->flashdata('old_tambah_slide')['gambar'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['gambar'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
