<aside class="navbar navbar-vertical navbar-expand-lg">
	<div class="container-fluid">
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu"
				aria-controls="sidebar-menu" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<h1 class="navbar-brand navbar-brand-autodark">
			<a href="<?= current_url() ?>">
				<img src="<?= base_url() ?>public/assets/img/lambang.png" width="110" height="32" alt="Tabler"
					 class="navbar-brand-image">
			</a>
		</h1>
		<div class="navbar-nav flex-row d-lg-none">
			<div class="nav-item dropdown">
				<a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown"
				   aria-label="Open user menu">
					<span class="avatar avatar-sm avatar-rounded"
						  style="background-image: url(<?= base_url() ?>public/uploads/pengguna/<?= $this->session->userdata("pengguna")["foto"] ?>)"></span>
					<div class="d-none d-xl-block ps-2">
						<div><?= $this->session->userdata("pengguna")["namaLengkap"] ?></div>
						<div
							class="mt-1 small text-secondary"><?= ucfirst($this->session->userdata("pengguna")["role"]) ?></div>
					</div>
				</a>
				<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
					<a href="<?= base_url() ?>pengaturan"
					   class="dropdown-item small">Pengaturan</a>
					<a href="<?= base_url() ?>logout"
					   class="dropdown-item small">Logout</a>
				</div>
			</div>
		</div>
		<div class="collapse navbar-collapse" id="sidebar-menu">
			<ul class="navbar-nav pt-lg-3">
				<li class="nav-item <?= $activeMenu == 1 ? 'active' : '' ?>" style="font-weight: normal">
					<a class="nav-link" href="<?= base_url() ?>dashboard">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-gauge"></i>
						</span>
						<span class="nav-link-title">
							Dashboard
						</span>
					</a>
				</li>

				<li class="nav-item <?= $activeMenu == 2 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>penyerahan-aset">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-handshake"></i>
						</span>
						<span class="nav-link-title">
							Penyerahan Aset
						</span>
					</a>
				</li>

				<li class="nav-item <?= $activeMenu == 3 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>terverifikasi">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-file-circle-check" style="margin-left: 3px"></i>
						</span>
						<span class="nav-link-title">
							Terverifikasi
						</span>
					</a>
				</li>

				<li class="nav-item <?= $activeMenu == 4 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>permohonan">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-file"></i>
						</span>
						<span class="nav-link-title">
							Permohonan
						</span>
					</a>
				</li>

				<li class="nav-item <?= $activeMenu == 5 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>perumahan">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-house"></i>
						</span>
						<span class="nav-link-title">
							Perumahan
						</span>
					</a>
				</li>
				

				<li class="nav-item <?= $activeMenu == 6 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>rpp">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-house"></i>
						</span>
						<span class="nav-link-title">
						Rencana Pembangunan/ Peruntukan
						</span>
					</a>
				</li>


				<?php if ($this->session->userdata("pengguna")["role"] == "admin"): ?>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#navbar-base" data-bs-toggle="dropdown"
						   data-bs-auto-close="false" role="button" aria-expanded="false">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-database"></i>
						</span>
							<span class="nav-link-title">
							Master Data
						</span>
						</a>
						<div class="dropdown-menu <?= $activeMenu == 6 ? 'show' : '' ?>">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
									<a class="dropdown-item <?= $activeSubMenu == 1 ? 'active' : '' ?>"
									   href="<?= base_url() ?>pengguna">
										Pengguna
									</a>
									<a class="dropdown-item <?= $activeSubMenu == 2 ? 'active' : '' ?>"
									   href="<?= base_url() ?>slide">
										Slide
									</a>
									<a class="dropdown-item <?= $activeSubMenu == 3 ? 'active' : '' ?>"
									   href="<?= base_url() ?>berita">
										Berita
									</a>
								</div>
							</div>
						</div>
					</li>
				<?php endif; ?>

				<div class="hr my-1"></div>

				<li class="nav-item <?= $activeMenu == 7 ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url() ?>pengaturan">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-gear"></i>
						</span>
						<span class="nav-link-title">
							Pengaturan
						</span>
					</a>
				</li>

				<li class="nav-item">
					<a class="nav-link" href="<?= base_url() ?>logout">
						<span class="nav-link-icon text-center d-md-none d-lg-inline-block">
							<i class="fa-solid fa-right-from-bracket"></i>
						</span>
						<span class="nav-link-title">
							Logout
						</span>
					</a>
				</li>
			</ul>
		</div>
	</div>
</aside>
