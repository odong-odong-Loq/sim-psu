<div class="modal modal-blur fade" id="edit-perumahan-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Perumahan</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>perumahan/post-edit" method="post" enctype="multipart/form-data">
				<div class="modal-body">
					<input type="hidden" id="id" name="id"
						   value="<?= $this->session->flashdata('old_edit_perumahan')['id'] ?? '' ?>">

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="nama">Nama</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['nama']) ? 'is-invalid' : '' ?>"
								   id="nama" name="nama"
								   placeholder="Masukkan nama"
								   value="<?= $this->session->flashdata('old_edit_perumahan')['nama'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['nama'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="perusahaan">Perusahaan</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['perusahaan']) ? 'is-invalid' : '' ?>"
								   id="perusahaan" name="perusahaan"
								   placeholder="Masukkan perusahaan"
								   value="<?= $this->session->flashdata('old_edit_perumahan')['perusahaan'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['perusahaan'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0" for="latitude">Latitude</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['latitude']) ? 'is-invalid' : '' ?>"
								   id="latitude" name="latitude"
								   placeholder="Masukkan latitude"
								   value="<?= $this->session->flashdata('old_edit_perumahan')['latitude'] ?? '' ?>">
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['latitude'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="row">
						<label class="col-12 col-form-label pt-0" for="longitude">Longitude</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('edit_validation_errors')['longitude']) ? 'is-invalid' : '' ?>"
								   id="longitude" name="longitude"
								   placeholder="Masukkan longitude"
								   value="<?= $this->session->flashdata('old_edit_perumahan')['longitude'] ?? '' ?>">
							<div class="invalid-feedback">
								<?= $this->session->flashdata('edit_validation_errors')['longitude'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
