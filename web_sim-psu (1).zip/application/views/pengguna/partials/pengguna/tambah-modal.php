<div class="modal modal-blur fade" id="tambah-pengguna-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Tambah Pengguna</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form action="<?= base_url() ?>pengguna/post-tambah" method="post">
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="nama_lengkap">Nama Lengkap</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['nama_lengkap']) ? 'is-invalid' : '' ?>"
								   id="nama_lengkap" name="nama_lengkap"
								   placeholder="Masukkan nama lengkap"
								   value="<?= $this->session->flashdata('old_tambah_pengguna')['nama_lengkap'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['nama_lengkap'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="username">Username</label>
						<div class="col">
							<input type="text"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['username']) ? 'is-invalid' : '' ?>"
								   id="username" name="username"
								   placeholder="Masukkan username"
								   value="<?= $this->session->flashdata('old_tambah_pengguna')['username'] ?? '' ?>"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['username'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="mb-3 row">
						<label class="col-12 col-form-label pt-0 required" for="password">Password</label>
						<div class="col">
							<input type="password"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['password']) ? 'is-invalid' : '' ?>"
								   id="password" name="password"
								   placeholder="Masukkan password"
								   value="<?= $this->session->flashdata('old_tambah_pengguna')['password'] ?? '' ?>"
								   autocomplete="off"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['password'] ?? '' ?>
							</div>
						</div>
					</div>

					<div class="row">
						<label class="col-12 col-form-label pt-0 required" for="konfirmasi_password">Konfirmasi
							Password</label>
						<div class="col">
							<input type="password"
								   class="form-control <?= isset($this->session->flashdata('tambah_validation_errors')['konfirmasi_password']) ? 'is-invalid' : '' ?>"
								   id="konfirmasi_password"
								   name="konfirmasi_password"
								   placeholder="Ketik ulang password"
								   value="<?= $this->session->flashdata('old_tambah_pengguna')['konfirmasi_password'] ?? '' ?>"
								   autocomplete="off"
								   required
							>
							<div class="invalid-feedback">
								<?= $this->session->flashdata('tambah_validation_errors')['konfirmasi_password'] ?? '' ?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="reset" class="btn me-auto" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
