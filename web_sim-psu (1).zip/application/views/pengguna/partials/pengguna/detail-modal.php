<div class="modal modal-blur fade" id="detail-pengguna-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Detail Pengguna</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-12">
						<address class="row">
							<strong class="col-sm-4">Foto</strong>
							<span class="col-sm-8">
								<img
									src="<?= base_url() ?>public/uploads/pengguna/<?= $this->session->flashdata('old_detail_pengguna')['foto'] ?? '' ?>"
									alt="John Doe" style="max-width: 128px;min-height: 128px">
                            </span>
						</address>
					</div>

					<div class="col-12">
						<address class="row">
							<strong class="col-sm-4">Nama Lengkap</strong>
							<span class="col-sm-8">
								<?= $this->session->flashdata('old_detail_pengguna')['nama_lengkap'] ?? '' ?>
							</span>
						</address>
					</div>

					<div class="col-12">
						<address class="row">
							<strong class="col-sm-4">Username</strong>
							<span class="col-sm-8">
								<?= $this->session->flashdata('old_detail_pengguna')['username'] ?? '' ?>
							</span>
						</address>
					</div>

					<div class="col-12">
						<address class="row mb-0">
							<strong class="col-sm-4">Role</strong>
							<span class="col-sm-8">
								<?= $this->session->flashdata('old_detail_pengguna')['role'] ?? '' ?>
							</span>
						</address>
					</div>

				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn ms-auto" data-bs-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>
