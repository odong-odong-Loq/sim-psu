<div class="modal modal-blur fade" id="detail-permohonan-modal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Detail Pemohon</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				 

				<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">
					Data Pemohon
				</div>
				<div class="row">
					<div class="col-12 col-sm-6">
						<address class="row">
							<strong class="col-12">Nama Lengkap</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['NamaPemohon'] ?? '' ?>
							</span>
						</address>

						

						<address class="row">
							<strong class="col-12">Koordinat</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['KoordinatY'] ." - ". $this->session->flashdata('rpp')['KoordinatX'] ?? '' ?>
							</span>
							 
						</address>
					</div>

					<div class="col-12 col-sm-6">
					<address class="row">
							<strong class="col-12">Alamat</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['Lokasi'] ?? '' ?>
							</span>
						</address>

						 
					</div>
				</div>

				<div class="hr-text hr-text-left text-black mb-3" style="font-size: 14px">
					Data Lainnya
				</div>
				<div class="row">
					<div class="col-12 col-sm-6">
						
						<address class="row">
							<strong class="col-12">NIB</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['nib'] ?? '' ?>
							</span>
						</address>

						

						<address class="row">
							<strong class="col-12">Kawasan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['kawasan'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Nomor Surat Tugas</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['NomorSuratTugas'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Tanggal Surat Tugas</strong>
							<span class="col-12">
								<?= tgl_indo($this->session->flashdata('rpp')['TanggalSuratTugas']) ?? '' ?>
							</span>
						</address>
						<address class="row">
							<strong class="col-12">Keterangan</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['ket'] ?? '' ?> 
							</span>
						</address>
											
					</div>

					<div class="col-12 col-sm-6">
					<address class="row">
							<strong class="col-12">Luas Area</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['luas'] ?? '' ?> m<sup>2</sup>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Rencana Pembangunan / Peruntukan </strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['rpp'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Nomor SKRK</strong>
							<span class="col-12">
								<?= $this->session->flashdata('rpp')['NomorSKRK'] ?? '' ?>
							</span>
						</address>

						<address class="row">
							<strong class="col-12">Tanggal SKRK</strong>
							<span class="col-12">
								<?= tgl_indo($this->session->flashdata('rpp')['TanggalSKRK']) ?? '' ?> 
							</span>
						</address>

							
						 
					</div>
				</div>


				 
				 
			</div>
			<div class="modal-footer">
				<button type="button" class="btn ms-auto" data-bs-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>
