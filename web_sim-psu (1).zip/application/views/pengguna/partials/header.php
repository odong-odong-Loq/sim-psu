<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
	<meta http-equiv="X-UA-Compatible" content="ie=edge"/>
	<title><?= $title ?></title>

	<!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180"
		  href="<?= base_url() ?>public/assets/favicon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32"
		  href="<?= base_url() ?>public/assets/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16"
		  href="<?= base_url() ?>public/assets/favicon/favicon-16x16.png">
	<link rel="manifest" href="<?= base_url() ?>public/assets/img/favicon/site.webmanifest">

	<!-- CSS files -->
	<link href="<?= base_url() ?>public/assets/libs/tabler/css/tabler.min.css?1692870487" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/tabler/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/tabler/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/tabler/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/tabler/css/demo.min.css?1692870487" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/datatables/datatables.min.css" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/datatables/datatables.bootstrap5.min.css" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/datatables/responsive.bootstrap5.min.css" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/fontawesome-free-6.4.2-web/css/all.min.css" rel="stylesheet"/>
	<link href="<?= base_url() ?>public/assets/libs/select2/css/select2.min.css" rel="stylesheet"/>
	<link rel="stylesheet"
		  href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css"/>
	<link href="<?= base_url() ?>public/assets/css/style.css" rel="stylesheet">
	<style>
		@import url('https://rsms.me/inter/inter.css');

		:root {
			--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
		}

		body {
			font-feature-settings: "cv03", "cv04", "cv11";
		}

		.fa-regular,
		.fa-solid {
			font-size: 18px;
		}

		.btn-sm > .fa-regular,
		.btn-sm > .fa-solid {
			font-size: 15px;
		}

		.nav-item {
			color: rgba(24, 36, 51, 0.7);
		}

		.nav-item.active,
		.dropdown-item.active {
			color: rgb(3, 15, 107) !important;
			background-color: rgba(3, 15, 107, 0.1) !important;
		}

		.nav-item.active:after {
			border-left-width: 0 !important;
		}

		.nav-link, .nav-link-icon, .dropdown-item {
			color: inherit;
		}

		.btn-group-sm > .btn, .btn-sm {
			padding: 0.5rem 0.5rem;
			font-size: .875rem;
			line-height: 1.5;
			border-radius: 0.2rem;
		}

		.swal2-popup {
			font-size: .875rem !important;
		}

	</style>
</head>
<body>
<script src="<?= base_url() ?>public/assets/libs/tabler/js/demo-theme.min.js?1692870487"></script>
<div class="page">
