<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Data Berita</h3>
							<div class="card-actions">
								<a href="#" class="btn btn-icon btn-sm btn-primary" data-bs-toggle="modal"
								   data-bs-target="#tambah-berita-modal">
									<i class="fa-solid fa-plus"></i>
									<span class="ms-1 d-none d-sm-block">Tambah Berita</span>
								</a>
							</div>
						</div>
						<div class="card-body">
							<table class="table table-vcenter table-striped" id="tabel-berita">
								<thead>
								<tr>
									<th width="1%" class="text-center bg-primary text-light">No</th>
									<th class="bg-primary text-light">Gambar</th>
									<th class="bg-primary text-light">Judul</th>
									<th class="bg-primary text-light">Tanggal Dibuat</th>
									<th width="5%" class="text-center bg-primary text-light">Aksi</th>
								</tr>
								</thead>
								<tbody class="table-tbody">
								<?php foreach ($berita as $index => $data): ?>
									<tr>
										<td class="text-center px-0"><?= $index + 1 ?></td>
										<td>
											<span class="avatar avatar-2xl"
												  style="background-image: url(<?= base_url() ?>public/uploads/berita/<?= $data->gambar ?>)"></span>
										</td>
										<td>
											<?= $data->judul ?>
										</td>
										<td>
											<?= $data->tanggalDibuat ?>
										</td>
										<td class="text-center">
											<div class="d-inline-block">
												<div class="btn-list flex-nowrap">
													<a href="<?= base_url() ?>baca/<?= $data->slug ?>"
													   target="_blank"
													   class="btn btn-icon btn-sm btn-info">
														<i class="fa-solid fa-eye"></i>
														<span class="ms-1 d-none d-sm-block">Lihat</span>
													</a>
													<a href="<?= base_url() ?>berita/edit?id=<?= $data->id ?>"
													   class="btn btn-icon btn-sm btn-success">
														<i class="fa-solid fa-pen-to-square"></i>
														<span class="ms-1 d-none d-sm-block">Edit</span>
													</a>
													<a href="#" class="btn btn-icon btn-sm btn-danger"
													   data-bs-toggle="modal"
													   data-bs-target="#hapus-berita-modal"
													   data-value="<?= $data->id ?>"
													   onclick="hapusBeritaHandler(this)">
														<i class="fa-solid fa-trash"></i>
														<span class="ms-1 d-none d-sm-block">Hapus</span>
													</a>
												</div>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/berita/tambah-modal") ?>
<?php $this->load->view("pengguna/partials/berita/edit-modal") ?>
<?php $this->load->view("pengguna/partials/berita/hapus-modal") ?>

<script>
	function hapusBeritaHandler(el) {
		$('#hapus-berita-modal :input[name="id"]').val($(el).data('value'));
	}

	document.addEventListener("DOMContentLoaded", function (event) {
		$('#tabel-berita').DataTable({
			"paging": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			language: {
				"paginate": {
					"previous": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-left</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg></span>',
					"next": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-right</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg></span>',
				},
			},
		});

		$("#tabel-berita_wrapper").children(".row")[0].classList.add("mb-3");
		$("#tabel-berita_wrapper").children(".row")[2].classList.add("mb-3");
		$("#tabel_berita_length").addClass("mt-2");
		$("#tabel-berita_info").addClass("mt-2");
		$("#tabel-berita_paginate").addClass("mt-2");
		$("#tabel-berita_filter").addClass("mt-2 mt-sm-0");

		let options = {
			selector: '#isi',
			height: 250,
			menubar: false,
			statusbar: false,
			plugins: [
				'advlist autolink lists link image charmap print preview anchor',
				'searchreplace visualblocks code fullscreen',
				'insertdatetime media table paste code help wordcount'
			],
			toolbar: 'undo redo | formatselect | ' +
				'bold italic backcolor | alignleft aligncenter ' +
				'alignright alignjustify | bullist numlist outdent indent | ' +
				'removeformat',
			content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; font-size: 14px; -webkit-font-smoothing: antialiased; }'
		}
		tinyMCE.init(options);

		<?php if ($this->session->flashdata('show_tambah_berita_modal') !== null): ?>
		$('#tambah-berita-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_edit_berita_modal') !== null): ?>
		$('#edit-berita-modal').modal('show')
		<?php endif; ?>
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
