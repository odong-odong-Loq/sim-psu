<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Profile</h3>
							<div class="card-actions">
								<a href="#" class="btn btn-icon btn-sm btn-success" data-bs-toggle="modal"
								   data-bs-target="#edit-profile-modal">
									<i class="fa-solid fa-pen-to-square"></i>
									<span class="ms-1 d-none d-sm-block">Edit Profile</span>
								</a>
							</div>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-12">
									<address class="row">
										<strong class="col-sm-2">Foto</strong>
										<span class="col-sm-10">
											<img
												src="<?= base_url() ?>public/uploads/pengguna/<?= $this->session->userdata('pengguna')['foto'] ?? '' ?>"
												alt="John Doe" style="max-width: 128px;min-height: 128px">
										</span>
									</address>
								</div>

								<div class="col-12">
									<address class="row">
										<strong class="col-sm-2">Nama Lengkap</strong>
										<span class="col-sm-10">
											<?= $this->session->userdata('pengguna')['namaLengkap'] ?? '' ?>
										</span>
									</address>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Password</h3>
							<div class="card-actions">
								<a href="#" class="btn btn-icon btn-sm btn-success" data-bs-toggle="modal"
								   data-bs-target="#edit-password-modal">
									<i class="fa-solid fa-pen-to-square"></i>
									<span class="ms-1 d-none d-sm-block">Edit Password</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/pengaturan/edit-profile-modal") ?>
<?php $this->load->view("pengguna/partials/pengaturan/edit-password-modal") ?>

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		<?php if ($this->session->flashdata('show_edit_profile_modal') !== null): ?>
		$('#edit-profile-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_edit_password_modal') !== null): ?>
		$('#edit-password-modal').modal('show')
		<?php endif; ?>
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
