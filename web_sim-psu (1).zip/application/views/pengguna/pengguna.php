<?php $this->load->view("pengguna/partials/header") ?>
<?php $this->load->view("pengguna/partials/sidebar") ?>
<?php $this->load->view("pengguna/partials/navbar") ?>

<div class="page-wrapper">
	<?php $this->load->view("pengguna/partials/page-header") ?>

	<div class="page-body">
		<div class="container-xl">
			<div class="row row-deck row-cards">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Data Pengguna</h3>
							<div class="card-actions">
								<a href="#" class="btn btn-icon btn-sm btn-primary" data-bs-toggle="modal"
								   data-bs-target="#tambah-pengguna-modal">
									<i class="fa-solid fa-plus"></i>
									<span class="ms-1 d-none d-sm-block">Tambah Pengguna</span>
								</a>
							</div>
						</div>
						<div class="card-body">
							<table class="table table-vcenter table-striped" id="tabel-pengguna">
								<thead>
								<tr>
									<th width="1%" class="text-center bg-primary text-light">No</th>
									<th class="bg-primary text-light">Nama Lengkap</th>
									<th class="bg-primary text-light">Username</th>
									<th class="bg-primary text-light">Role</th>
									<th width="5%" class="text-center bg-primary text-light">Aksi</th>
								</tr>
								</thead>
								<tbody class="table-tbody">
								<?php foreach ($pengguna as $index => $data): ?>
									<tr>
										<td class="text-center px-0"><?= $index + 1 ?></td>
										<td><?= $data->namaLengkap ?></td>
										<td><?= $data->username ?></td>
										<td><?= $data->role ?></td>
										<td class="text-center">
											<div class="d-inline-block">
												<div class="btn-list flex-nowrap">
													<a href="<?= base_url() ?>pengguna/detail?id=<?= $data->id ?>"
													   class="btn btn-icon btn-sm btn-info">
														<i class="fa-solid fa-circle-info"></i>
														<span class="ms-1 d-none d-sm-block">Detail</span>
													</a>
													<a href="<?= base_url() ?>pengguna/edit?id=<?= $data->id ?>"
													   class="btn btn-icon btn-sm btn-success">
														<i class="fa-solid fa-pen-to-square"></i>
														<span class="ms-1 d-none d-sm-block">Edit</span>
													</a>
													<a href="#" class="btn btn-icon btn-sm btn-danger"
													   data-bs-toggle="modal"
													   data-bs-target="#hapus-pengguna-modal"
													   data-value="<?= $data->id ?>"
													   onclick="hapusPenggunaHandler(this)">
														<i class="fa-solid fa-trash"></i>
														<span class="ms-1 d-none d-sm-block">Hapus</span>
													</a>
												</div>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $this->load->view("pengguna/partials/footer") ?>
</div>

<?php $this->load->view("pengguna/partials/pengguna/tambah-modal") ?>
<?php $this->load->view("pengguna/partials/pengguna/edit-modal") ?>
<?php $this->load->view("pengguna/partials/pengguna/hapus-modal") ?>
<?php $this->load->view("pengguna/partials/pengguna/detail-modal") ?>

<script>
	function hapusPenggunaHandler(el) {
		$('#hapus-pengguna-modal :input[name="id"]').val($(el).data('value'));
	}

	document.addEventListener("DOMContentLoaded", function (event) {
		$('#tabel-pengguna').DataTable({
			"paging": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			language: {
				"paginate": {
					"previous": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-left</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg></span>',
					"next": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-right</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg></span>',
				},
			},
		});

		$("#tabel-pengguna_wrapper").children(".row")[0].classList.add("mb-3");
		$("#tabel-pengguna_wrapper").children(".row")[2].classList.add("mb-3");
		$("#tabel_pengguna_length").addClass("mt-2");
		$("#tabel-pengguna_info").addClass("mt-2");
		$("#tabel-pengguna_paginate").addClass("mt-2");
		$("#tabel-pengguna_filter").addClass("mt-2 mt-sm-0");

		<?php if ($this->session->flashdata('show_tambah_pengguna_modal') !== null): ?>
		$('#tambah-pengguna-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_edit_pengguna_modal') !== null): ?>
		$('#edit-pengguna-modal').modal('show')
		<?php endif; ?>

		<?php if ($this->session->flashdata('show_detail_pengguna_modal') !== null): ?>
		$('#detail-pengguna-modal').modal('show')
		<?php endif; ?>
	});
</script>

<?php $this->load->view("pengguna/partials/close-tag") ?>
