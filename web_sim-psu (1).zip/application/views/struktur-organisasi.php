<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<h3>
			<strong>STRUKTUR ORGANISASI</strong>
		</h3>
		<hr>
		<div class="row">
			<div
				class="col-10 col-sm-8 col-md-12 mx-auto d-flex overflow-hidden p-0 appear-animation animated fadeInUpShorter appear-animation-visible"
				data-appear-animation="fadeInUpShorter" data-appear-animation-duration="700ms"
				style="animation-duration: 700ms; animation-delay: 100ms;">
				<img src="<?php echo base_url(); ?>public/assets/STRUKTURORGANISASIDPUTR.jpg" width="100%"
					 height="100%">
			</div>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
