<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<h3>
			<strong>TUJUAN DAN SASARAN JANGKA MENENGAH DPUTR KOTA SUKABUMI</strong>
		</h3>
		<hr>
		<div class="row">
			<h4><strong>Tujuan</strong></h4><br>
		</div>
		<div class="row">
			<p>Tujuan yang hendak dicapai oleh Dinas antara lain:</p>
			<ol>
				<li>Meningkatkan organisasi yang efisien, tata laksana yang efektif, dan terpadu dengan mengembangkan
					sumber daya manusia yang profesional.
				</li>
				<li>Mengendalikan tata ruang kota untuk mewujudkan kota yang nyaman dan berkelanjutan.</li>
				<li>Meningkatkan tata kelola proses penyelenggaraan jasa konstruksi yang profesional di Daerah;.</li>
				<li>Meningkatkan kemantapan infrastruktur jalan kota.</li>
				<li>Meningkatkan pemeliharaan infrastruktur sumber daya air dari hulu hingga hilir.</li>
				<li>Meningkatkan kualitas dan kuantitas prasarana, sarana dan utilitas umum permukiman.</li>
				<li>Memfasilitasi hunian layak huni bagi masyarakat berpenghasilan rendah.</li>
			</ol>
		</div>
		<br>
		<hr>
		<div class="row">
			<h4><strong>Sasaran Jangka Menengah</strong></h4><br>
		</div>
		<div class="row">
			<p>Sasaran yang hendak dicapai dirinci menjadi sasaran-sasaran jangka menengah Dinas antara lain:</p>
			<ol>
				<li>Terwujudnya Pengembangan sumber daya manusia yang profesional.</li>
				<li>Terwujudnya kota yang teratur sesuai penataan ruang.</li>
				<li>Terwujudnya pelaku sektor jasa konstruksi yang tumbuh dan berkembang.</li>
				<li>Terwujudnya Kondisi Jalan yang Mantap.</li>
				<li>Terwujudnya Jaringan Drainase Jalan dalam Kondisi Baik.</li>
				<li>Terwujudnya Jalan Trotoar yang Ramah Pejalan Kaki dan Berkebutuhan Khusus;</li>
				<li>Terwujudnya kondisi infrastruktur sumber daya air dari hulu hingga hilir yang baik.</li>
				<li>Terwujudnya kota tanpa permukiman kumuh.</li>
				<li>Terwujudnya sarana dan prasarana utilitas umum yang memadai.</li>
				<li>Terfasilitasinya hunian layak huni bagi masyarakat berpenghasilan rendah.</li>
			</ol>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
