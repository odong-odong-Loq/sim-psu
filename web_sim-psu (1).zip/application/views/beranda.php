<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<div class="slider-container slider-container-full-height rev_slider_wrapper">
	<div id="revolutionSlider" class="slider rev_slider" data-version="5.4.7" data-plugin-revolution-slider
		 data-plugin-options="{'delay': 9000,'disableProgressBar': 'on', 'responsiveLevels': [4096,1200,992,576], 'navigation' : {'arrows': { 'enable': true, 'hide_under': 767, 'style': 'slider-arrows-style-1' }}}}">
		<ul>
			<?php foreach ($slide as $data): ?>
				<li class="slide-overlay slide-overlay-primary slide-overlay-level-1" data-transition="fade">
					<img src="<?= base_url() ?>public/uploads/slide/<?= $data->gambar ?>"
						 data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"
						 class="rev-slidebg">
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>

<section class="section section-height-2 bg-light-5 pb-5">
	<div class="container-fluid">
		<div class="row">
			<div
				class="col-10 col-sm-8 col-md-12 mx-auto d-flex overflow-hidden p-0 appear-animation animated fadeInUpShorter appear-animation-visible"
				data-appear-animation="fadeInUpShorter" data-appear-animation-duration="700ms"
				style="animation-duration: 700ms; animation-delay: 100ms;">
				<div
					class="owl-carousel carousel-center-active-items carousel-center-active-items-style-3 owl-theme owl-loaded owl-drag owl-carousel-init"
					data-plugin-carousel=""
					data-plugin-options="{'autoplay': false, 'dots': false, 'nav': true, 'loop': false, 'margin': 30, 'responsive': { '0': {'items': 1}, '576': {'items': 1}, '768': {'items': 3}, '992': {'items': 3}, '1200': {'items': 5}}}">
					<div class="owl-stage-outer">
						<div class="owl-stage"
							 style="transform: translate3d(-3576px, 0px, 0px); transition: all 0.25s ease 0s; width: 6796px;">
							<?php foreach ($berita as $data): ?>
								<div class="owl-item" style="max-width: 327.65px; margin-right: 30px;">
									<div class="appear-animation animated" data-appear-animation="fadeInLeftShorter"
										 data-appear-animation-delay="400">
										<article class="card rounded border-0 p-0">

											<a href="<?= base_url() ?>baca/<?= $data->slug ?>"><img
													src="<?= base_url() ?>public/uploads/berita/<?= $data->gambar ?>"
													class="card-img-top hover-effect-2" alt=""
													style="height: 200px;object-fit: cover;"></a>

											<div class="card-body">
												<h3 class="font-weight-bold text-4 mb-1"><a
														href="<?= base_url() ?>baca/<?= $data->slug ?>"
														class="link-color-dark"><?= $data->judul ?></a></h3>
												<span class="text-color-dark mb-3"><i
														class="far fa-clock text-color-primary"> </i> <?= $data->tanggalDibuat ?></span>
											</div>
										</article>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
