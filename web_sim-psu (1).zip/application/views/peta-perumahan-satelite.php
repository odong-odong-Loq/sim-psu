<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh" style="color:#030F6B">
	<div class="container">
		<h3>
			<strong>PETA SATELIT</strong>
		</h3>
		<hr>
		<div id="map" class="height-100vh"></div>
	</div>
</section>
<!-- content end -->

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		var map = L.map('map').setView([-6.91806, 106.92667], 10);

		L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
			subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
		}).addTo(map);

		<?php foreach ($perumahan as $data): ?>
		<?php if ($data->latitude != null && $data->longitude != null): ?>
			L.marker([<?= $data->latitude ?>, <?= $data->longitude ?>]).addTo(map).bindPopup(' <?= "<table><tr><td>Perumahan</td><td>".$data->nama."</td></tr><tr><td>Nama Pemohon</td><td>".$data->nama_pemohon."</td></tr><tr><td>Perusahaan</td><td>".$data->perusahaan."</td> </tr><tr><td>Alamat Pemohon</td><td>".$data->alamat_pemohon."</td> </tr> <tr><td>Tipe Perumahan</td><td>".$data->tipe_perumahan."</td></tr><tr><td>Lokasi Perumahan</td><td>".$data->alamat_perumahan."</td> </tr><tr><td>Luas Lahan Kav</td><td>".number_format($data->luas_kav,2)." m<sup>2</sup></td></tr><tr><td>Luas Kav Efektif</td><td>". number_format($data->luas_efektif,2)." m<sup>2</sup></td> </tr><tr><td>Luas Fasum/Fasos</td><td>". number_format($data->luas_fasum,2)." m<sup>2</sup></td> </tr><tr><td>Luas Lahan TPU</td><td>".number_format($data->luas_tpu,2)." m<sup>2</sup></td> </tr><tr><td>Jumlah Unit</td><td>".$data->jumlah_unit."</td> </tr><tr><td>Luas RTH</td><td>". number_format($data->luasRTH,2)." m<sup>2</sup></td> </tr><tr><td></td><td></td> </tr><tr><td>Nomor SK Pengesahan</td><td>".$data->nomor_surat_pengesahan."</td> </tr><tr><td>Tanggal Penerbitan</td><td>".$data->tanggal_terbit."</td> </tr><tr><td>Keterangan</td><td>".$data->keterangan."</td> </tr><tr><td>PSU</td><td>".$data->penyerahan ."</td> </tr></table>"?>');
		<?php endif; ?>
		<?php endforeach; ?>
	});
</script>

<?php $this->load->view("partials/footer") ?>
