<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section
	class="page-header parallax section section-background section-height-3 overlay overlay-color-primary overlay-show overlay-op-5 mt-2 mb-2"
	data-plugin-image-background="" data-plugin-options="{'imageUrl': https://pu.go.id/ }"
	style="background-image: url(https://pu.go.id/); background-size: cover; background-position: center center; background-repeat: no-repeat;">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-8 text-left">
				<span class="tob-sub-title text-color-light d-block">BERITA</span>
				<h1 class="font-weight-bold text-color-light"><?= $berita->judul ?></h1>
			</div>
		</div>
	</div>
</section>

<section class="section section-height-3">
	<div class="container">
		<div class="row">
			<!-- main content -->
			<div class="col-md-7 col-lg-7 order-1 mb-5 mb-md-0">
				<article class="blog-post mb-4">
					<h1 class="font-weight-bold text-color-primary mb-3 mt-3"><?= $berita->judul ?></h1>
					<div class="d-flex mb-3">
						<span class="post-date text-color-primary pr-3"><?= $berita->tanggalDibuat ?></span>
					</div>
					<header class="blog-post-header mb-3 lightbox"
							data-plugin-options="{'delegate': 'a', 'type': 'image', 'gallery': {'enabled': true}}">
						<a class="lightbox" href="<?= base_url() ?>public/uploads/berita/<?= $berita->gambar ?>">
                            <span class="image-frame image-frame-style-1 image-frame-effect-1">
                                <span class="image-frame-wrapper">

                                    <img src="<?= base_url() ?>public/uploads/berita/<?= $berita->gambar ?>"
										 class="lazyOwl img-fluid" alt="PUPR" title="">

                                    <span class="image-frame-inner-border"></span>
                                    <span class="image-frame-action">
                                        <span class="image-frame-action-icon"><i
												class="lnr lnr-magnifier text-color-light"></i></span>
                                    </span>
                                    <span class="thumb-info-title">
                                        <span class="thumb-info-caption-text">

                                        </span>
                                    </span>
                                </span>
                            </span>
						</a>
					</header>
					<p class="mb-4"></p>
					<?= $berita->isi ?>
					<hr class="tall">
				</article>
			</div>
		</div>
	</div>
</section>

<section class="section section-height-2 bg-light-5 pb-5">
	<div class="container-fluid">
		<div class="row">
			<div
				class="col-10 col-sm-8 col-md-12 mx-auto d-flex overflow-hidden p-0 appear-animation animated fadeInUpShorter appear-animation-visible"
				data-appear-animation="fadeInUpShorter" data-appear-animation-duration="700ms"
				style="animation-duration: 700ms; animation-delay: 100ms;">
				<div
					class="owl-carousel carousel-center-active-items carousel-center-active-items-style-3 owl-theme owl-loaded owl-drag owl-carousel-init"
					data-plugin-carousel=""
					data-plugin-options="{'autoplay': false, 'dots': false, 'nav': true, 'loop': false, 'margin': 30, 'responsive': { '0': {'items': 1}, '576': {'items': 1}, '768': {'items': 3}, '992': {'items': 3}, '1200': {'items': 5}}}">
					<div class="owl-stage-outer">
						<div class="owl-stage"
							 style="transform: translate3d(-3576px, 0px, 0px); transition: all 0.25s ease 0s; width: 6796px;">

							<?php foreach ($beritaLainnya as $data) : ?>
								<?php if ($data->id != $berita->id): ?>
									<div class="owl-item" style="width: 327.65px; margin-right: 30px;">
										<div class="appear-animation animated" data-appear-animation="fadeInLeftShorter"
											 data-appear-animation-delay="400">
											<article class="card rounded border-0 p-0">
												<a href="<?= base_url() ?>baca/<?= $data->slug ?>"><img
														src="<?= base_url() ?>public/uploads/berita/<?= $data->gambar ?>"
														class="card-img-top hover-effect-2" alt=""
														style="height: 200px;object-fit: cover;"></a>

												<div class="card-body">
													<h3 class="font-weight-bold text-4 mb-1"><a
															href="<?= base_url() ?>baca/<?= $data->slug ?>"
															class="link-color-dark"><?= $data->judul ?></a></h3>
													<span class="text-color-dark mb-3"><i
															class="far fa-clock text-color-primary"> </i> <?= $data->tanggalDibuat ?></span>
												</div>
											</article>
										</div>
									</div>
								<?php endif; ?>
							<?php endforeach; ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
