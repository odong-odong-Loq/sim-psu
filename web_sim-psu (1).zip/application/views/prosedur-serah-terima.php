<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<h3>
			<strong>TAHAPAN SERAH TERIMA PRASARANA, SARANA, DAN UTILITAS UMUM</strong>
		</h3>
		<hr>
		<div class="row">
			<ol>
				<li>Rapat Persiapan (Rapat Pendahuluan)</li>
				<li>Verifikasi Dokumen (Pengajuan)</li>
				<li>Verifikasi Lapangan (Dilakukan Tim Verifikasi)</li>
				<li>Rapat Evaluasi Hasil Verifikasi Lapangan (Dilakukan Tim Verifikasi)</li>
				<li>Penandatanganan Berita Acara Serah Terima (Apabila Sudah Layak Diserah Terimakan)</li>
			</ol>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
