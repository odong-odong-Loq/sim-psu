<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh" style="color:#030F6B">
	<div class="container">
		<h3>
			<strong>Peta Rencana Pembangunan / Peruntukan</strong>
		</h3>
		<hr>
		<div id="map" class="height-100vh"></div>
	</div>
</section>
<!-- content end -->

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		var map = L.map('map').setView([-6.91806, 106.92667], 10);

		L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
			subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
		}).addTo(map);

		<?php foreach ($perumahan as $data): ?>
		<?php if ($data->KoordinatY != null && $data->KoordinatX != null): ?>
			L.marker([<?= $data->KoordinatY ?>, <?= $data->KoordinatX ?>]).addTo(map).bindPopup('<?php echo  "<table> <tr><td>Nama Pemohon</td> <td> - </td> </tr> <tr><td>Lokasi</td> <td>".$data->Lokasi."</td> </tr><tr><td>Luas Area</td> <td>".number_format($data->luas,2)." m<sup>2</sup></td></tr> <tr><td>Keterangan</td> <td>". $data->ket." </td></tr></table>";?>');
		<?php endif; ?>
		<?php endforeach; ?>
	});
</script>

<?php $this->load->view("partials/footer") ?>
