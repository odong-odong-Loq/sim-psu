<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<div class="card card-md mx-auto" style="flex-basis: 500px; max-width: 500px;">
			<form action="<?= base_url() ?>post/login" method="post" autocomplete="off">
				<div class="card-body">
					<div class="card-title text-center mb-4 mt-2 fs-1 fw-bold">
						<h1 class="font-weight-semibold" style="font-size: 28px;color:#030F6B">LOGIN SIM PSU</h1>
						<h4 style="font-size: 16px">Silahkan Masuk</h4>
					</div>

					<?php if ($this->session->flashdata('error') != null): ?>
						<div class="mb-3">
							<div class="alert alert-danger" role="alert">
								<?= $this->session->flashdata('error') ?>
							</div
						</div>
					<?php endif; ?>

					<div class="mb-3">
						<input type="text"
							   class="form-control <?= isset($this->session->flashdata('validation_errors')['username']) ? 'is-invalid' : '' ?>"
							   id="username" name="username"
							   placeholder="Masukkan username"
							   value="<?= $this->session->flashdata('old')['username'] ?? '' ?>"
							   required
						>
						<div class="invalid-feedback">
							<?= $this->session->flashdata('validation_errors')['username'] ?? '' ?>
						</div>
					</div>

					<div class="mb-3">
						<input type="password"
							   class="form-control <?= isset($this->session->flashdata('validation_errors')['password']) ? 'is-invalid' : '' ?>"
							   id="password" name="password"
							   placeholder="Masukkan password"
							   value="<?= $this->session->flashdata('old')['password'] ?? '' ?>"
							   required
						>
						<div class="invalid-feedback">
							<?= $this->session->flashdata('validation_errors')['password'] ?? '' ?>
						</div>
					</div>

					<div class="form-footer">
						<button type="submit" class="btn btn-lg btn-primary btn-block border-radius-0">Masuk</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
