<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh" style="color:#030F6B">
	<div class="container">
		<h3>
			<strong>INFOGRAFIS</strong>
		</h3>
		<hr>
		<div class="row">
			<div class="col-12 col-lg-6">
				<div class="card mt-2">
					<div class="card-header bg-white fw-bold">Tipe Perumahan</div>
					<div class="card-body">
						<div id="chart-tipe-perumahan"></div>
					</div>
				</div>
			</div>

			<div class="col-12 col-lg-6">
				<div class="card mt-2">
					<div class="card-header bg-white fw-bold">Perumahan Per Kecamatan</div>
					<div class="card-body">
						<div id="chart-kecamatan-perumahan"></div>
					</div>
				</div>
			</div>

			<div class="col-12">
				<div class="card mt-2">
					<div class="card-header bg-white fw-bold">Permohonan dan Statusnya</div>
					<div class="card-body">
						<div id="chart-status-permohonan"></div>
					</div>
				</div>
			</div>

			<div class="col-12">
				<div class="card mt-2">
					<div class="card-header bg-white fw-bold">Permohonan Per Tahun</div>
					<div class="card-body">
						<div id="chart-permohonan-per-tahun"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- content end -->

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		let options = {
			chart: {
				type: 'pie',
				height: 300
			},
			dataLabels: {
				formatter(val, opts) {
					const name = opts.w.globals.labels[opts.seriesIndex]
					const series = opts.w.globals.series[opts.seriesIndex]
					return [series + " (" + val.toFixed(1) + '%)']
				}
			},
			series: <?= json_encode(array_values($jumlahTipePerumahan)) ?>,
			labels: <?= json_encode(array_keys($jumlahTipePerumahan)) ?>,
		}

		let chartTipePerumahan = new ApexCharts(document.querySelector("#chart-tipe-perumahan"), options);
		chartTipePerumahan.render();

		options = {
			chart: {
				type: 'pie',
				height: 300
			},
			dataLabels: {
				formatter(val, opts) {
					const name = opts.w.globals.labels[opts.seriesIndex]
					const series = opts.w.globals.series[opts.seriesIndex]
					return [series + " (" + val.toFixed(1) + '%)']
				}
			},
			series: <?= json_encode(array_values($jumlahKecamatanPerumahan)) ?>,
			labels: <?= json_encode(array_keys($jumlahKecamatanPerumahan)) ?>,
		}

		chartTipePerumahan = new ApexCharts(document.querySelector("#chart-kecamatan-perumahan"), options);
		chartTipePerumahan.render();

		options = {
			chart: {
				type: 'pie',
				height: 300
			},
			dataLabels: {
				formatter(val, opts) {
					const name = opts.w.globals.labels[opts.seriesIndex]
					const series = opts.w.globals.series[opts.seriesIndex]
					return [series + " (" + val.toFixed(1) + '%)']
				}
			},
			series: <?= json_encode(array_values($jumlahPermohonanPerStatus)) ?>,
			labels: <?= json_encode(array_keys($jumlahPermohonanPerStatus)) ?>,
		}

		chartTipePerumahan = new ApexCharts(document.querySelector("#chart-status-permohonan"), options);
		chartTipePerumahan.render();

		options = {
			chart: {
				type: 'bar',
				height: 300
			},
			series: [{
				name: "Jumlah",
				data: [
					<?php foreach ($permohonanPerTahun as $key => $value): ?>
					{
						x: "<?= $key ?>",
						y: <?= $value ?>
					},
					<?php endforeach; ?>
				]
			}]
		}

		let chartPermohonanPerumahan = new ApexCharts(document.querySelector("#chart-permohonan-per-tahun"), options);
		chartPermohonanPerumahan.render();
	});
</script>

<?php $this->load->view("partials/footer") ?>
