<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
	<meta http-equiv="X-UA-Compatible" content="ie=edge"/>
	<title><?= $title ?></title>

	<!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180"
		  href="<?= base_url() ?>public/assets/favicon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32"
		  href="<?= base_url() ?>public/assets/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16"
		  href="<?= base_url() ?>public/assets/favicon/favicon-16x16.png">
	<link rel="manifest" href="<?= base_url() ?>public/assets/img/favicon/site.webmanifest">

	<!-- Web Fonts  -->
	<link
		href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500,600,700,900%7COpen+Sans:300,400,600,700,800"
		rel="stylesheet" type="text/css">

	<!-- Vendor CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/animate.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/linear-icons.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/owl.theme.default.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/magnific-popup.min.css">
	<link href="<?= base_url() ?>public/assets/libs/datatables/datatables.min.css" rel="stylesheet"/>
	<link rel="stylesheet" type="text/css"
		  href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
	<link rel="stylesheet" type="text/css"
		  href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.bootstrap5.min.css">
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
		  integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
		  crossorigin=""/>

	<!-- Theme CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/theme.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/theme-elements.css">

	<!-- Current Page CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/settings.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/layers.css">
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/navigation.css">

	<!-- Skin CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/default.css">

	<!-- Theme Custom CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/custom.css">

	<!-- Head Libs -->
	<script src="<?= base_url() ?>public/assets/js/modernizr.min.js"></script>
	<script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
			integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
			crossorigin=""></script>
	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios@1.1.2/dist/axios.min.js"></script>

	<style>
		.scroll {
			/*width: 300px;*/
			/*background: orange;*/
			padding: 10px;
			overflow: scroll;
			height: 400px;
			/*script tambahan khusus untuk IE */
			scrollbar-face-color: #CE7E00;
			scrollbar-shadow-color: #FFFFFF;
			scrollbar-highlight-color: #6F4709;
			scrollbar-3dlight-color: #1111;
			scrollbar-darkshadow-color: #6F4709;
			scrollbar-track-color: #FFE8C1;
			scrollbar-arrow-color: #6F4709;
		}

		body .overlay-color-primary:not(.no-skin):before {
			background-color: #030F6B !important;
		}

		.form-control {
			border-color: #dee2e6;
		}
	</style>

	<link rel="stylesheet" href="<?= base_url() ?>public/assets/css/style.css">
</head>
<body>

<div role="main" class="main">
