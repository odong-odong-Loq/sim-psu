<footer id="footer" class="footer-hover-links-light mt-0">
	<div class="footer-copyright">
		<div class="container">
			<div class="text-center">
				<img class="light" width="300"
					 src="<?= base_url() ?>public/assets/img/lambang1.png">
			</div>
			<p class="text-md-center pb-0 mb-0 text-color-primary" style="font-size: 1em !important;color: yellow;">
				Hak Cipta ©2022 Dinas Pekerjaan Umum dan Tata Ruang Kota Sukabumi. All Rights Reserved
			</p>
		</div>
	</div>
</footer>
<!--    footer section end   -->

<!-- preloader section start -->
<div class="loader-container">
            <span class="loader">
                <span class="loader-inner"></span>
            </span>
</div>

<script type="text/javascript">
	$(document).ready(function () {
		var get_dark = getCookie('dark');
		console.log(get_dark);
		if (get_dark == 'on') {
			document.body.classList.toggle("dark");
			$("#switch").prop('checked', true);
		} else {
			$("#switch").prop('checked', false);
		}

		function getCookie(cname) {
			var name = cname + "=";
			var decodedCookie = decodeURIComponent(document.cookie);
			var ca = decodedCookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}

		function setCookie(cname, cvalue) {
			var d = new Date();
			d.setTime(d.getTime() + (1 * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toUTCString();
			document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
		}
	})
</script>

<!--Start of subscribe functionality-->
<script>
	$(document).ready(function () {
		$("#subscribeForm, #footerSubscribeForm").on('submit', function (e) {
			e.preventDefault();
			let formId = $(this).attr('id');
			let fd = new FormData(document.getElementById(formId));
			let $this = $(this);
			$.ajax({
				url: $(this).attr('action'),
				type: $(this).attr('method'),
				data: fd,
				contentType: false,
				processData: false,
				success: function (data) {
					if ((data.errors)) {
						$this.find(".err-email").html(data.errors.email[0]);
					} else {
						toastr["success"]("You are subscribed successfully!");
						$this.trigger('reset');
						$this.find(".err-email").html('');
					}
				}
			});
		});
	});
</script>
<script>
	window.onload = function () {
		jam();
	}

	function jam() {
		var e = document.getElementById('jam'),
			d = new Date(),
			h, m, s;
		h = d.getHours();
		m = set(d.getMinutes());
		s = set(d.getSeconds());
		e.innerHTML = h + ':' + m + ':' + s;
		setTimeout('jam()', 1000);
	}

	function set(e) {
		e = e < 10 ? '0' + e : e;
		return e;
	}
</script>

</body>
</html>
