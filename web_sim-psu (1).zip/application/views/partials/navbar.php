<header id="header" class="header-effect-shrink"
		data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 120}"
		style='margin-bottom:-30px'>
	<div class="header-body">
		<style>
			#header .header-container:after {
				border-bottom: 0px
			}
		</style>
		<div class="header-top" style="background-color: #030F6B">
			<div class="header-top-container container" style='margin-top:-15px; margin-bottom:-15px;'>
				<div class="header-row">
					<div class="header-column justify-content-start">
						<span class="d-none text-color-light d-sm-flex align-items-center">
							<?= date('d M Y') ?>&nbsp; | 
							&nbsp;<span id="jam"></span>-WIB &nbsp &nbsp SIM-PSU : Sistem Informasi Manajemen Prasarana, Sarana dan Utilitas</span>
					</div>
					<div class="header-column justify-content-end" style='margin-top:-15px; margin-bottom:-15px;'>
						<ul class="nav">
							<li class="nav-item">
								<div class="toggle-dark-mode" data-toggle="tooltip" data-placement="bottom"
									 title="dark mode/light mode" data-original-title="dark mode/light mode">
									<input id="switch" type="checkbox">
									<label for="switch">button</label>
									<script>
										const btn = document.querySelector(".toggle-dark-mode input");
										const currentTheme = localStorage.getItem("theme");
										if (currentTheme == "dark") {
											document.body.classList.add("dark");
										}
										btn.addEventListener("click", function () {
											document.body.classList.toggle("dark");
											let theme = "light";
											if (document.body.classList.contains("dark")) {
												theme = "dark";
											}
											localStorage.setItem("theme", theme);
										});
									</script>
								</div>
							</li>
						</ul>
						<ul class="nav">
							<li class="nav-item">
								<a href="#" class="nav-link dropdown-menu-toggle py-2 text-color-light"
								   id="dropdownLanguage" data-toggle="dropdown" aria-haspopup="true"
								   aria-expanded="true">Indonesia <i class="fas fa-angle-down fa-sm"></i></a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownLanguage">
									<li>
										<a href="#" class="no-skin"><img
												src="<?= base_url() ?>public/assets/front/blank.gif"
												class="flag flag-id"/>Indonesia</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="header-container container" style='margin-top:-15px; margin-bottom:-15px'>
			<div class="header-row">
				<div class="header-column justify-content-start">
					<div class="header-logo">
						<a href="<?= base_url() ?>">
							<img class="light" width="230" height="40"
								 src="<?= base_url() ?>public/assets/img/logodputr.png">
							<img class="dark" width="230" height="40"
								 src="<?= base_url() ?>public/assets/img/logodputr1.png">
						</a>
					</div>
				</div>
				<div class="header-column justify-content-end">
					<div class="header-nav header-nav-light-dropdown">
						<div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 ">
							<nav class="collapse">
								<ul class="nav flex-column flex-lg-row" id="mainNav">

									<li>
										<a class="dropdown-item"
										   href="<?= base_url() ?>beranda">Beranda</a>
									</li>

									<li class="dropdown">
										<a class="dropdown-item dropdown-toggle" href="#">
											Profil
											<i class="menu-arrow"></i>
										</a>
										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item" href="<?= base_url() ?>visi-misi">
													Visi dan Misi
												</a>
											</li>
											<li>
												<a class="dropdown-item" href="<?= base_url() ?>tujuan-sasaran">
													Tujuan dan Sasaran
												</a>
											</li>
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>struktur-organisasi">
													Struktur Organisasi
												</a>
											</li>
										</ul>
									</li>

									<li class="dropdown">
										<a class="dropdown-item" href="#">Regulasi<i class="menu-arrow"></i></a>

										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>peraturan">
													Peraturan
												</a>
											</li>
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>prosedur-serah-terima">
													Prosedur Serah Terima
												</a>
											</li>
										</ul>
									</li>

									<li class="dropdown">
										<a class="dropdown-item dropdown-toggle" href="#">Data<i class="menu-arrow"></i></a>
										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>data-permohonan">
													Data Permohonan
												</a>
											</li>

											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>data-perumahan">
													Data Perumahan
												</a>
											</li>
										</ul>
									</li>

									<li class="dropdown">
										<a class="dropdown-item" href="#">Peta Perumahan<i class="menu-arrow"></i></a>

										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>peta-perumahan-roadmap">Peta Jalan</a>
											</li>
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>peta-perumahan-satelite">Peta Satelit</a>
											</li> 
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>peta-RPP">Rencana Pembangunan/ Peruntukan</a>
											</li>

										</ul>
									</li>

									<li>
										<a class="dropdown-item" href="<?= base_url() ?>infografis">Infografis</a>
									</li>

									<li class="dropdown">
										<a class="dropdown-item" href="#">Aset<i class="menu-arrow"></i></a>

										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>tahap-verifikasi">Tahap
													Verifikasi</a>
											</li>
											<li>
												<a class="dropdown-item"
												   href="<?= base_url() ?>aset-psu">Aset PSU</a>
											</li>
										</ul>
									</li>

									<li>
										<a class="dropdown-item" href="<?= base_url() ?>login">Login</a>
									</li>
								</ul>
							</nav>
						</div>
						<button class="header-btn-collapse-nav ml-3" data-toggle="collapse"
								data-target=".header-nav-main nav">
                                <span class="hamburguer">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </span>
							<span class="close">
                                    <span></span>
                                    <span></span>
                                </span>
						</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Vendor -->
		<script src="<?= base_url() ?>public/assets/js/jquery.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.appear.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.easing.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery-cookie.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/bootstrap.bundle.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/common.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.validation.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.easy-pie-chart.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.gmap.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.lazyload.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.isotope.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/owl.carousel.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/jquery.magnific-popup.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/vide.min.js"></script>
		<script src="<?= base_url() ?>public/assets/js/vivus.min.js"></script>
		<!-- Theme Base, Components and Settings -->
		<script src="<?= base_url() ?>public/assets/js/theme.js"></script>
		<!-- Current Page Vendor and Views -->
		<script src="<?= base_url() ?>public/assets/js/jquery.themepunch.tools.min.js"></script>
		<script
			src="<?= base_url() ?>public/assets/js/jquery.themepunch.revolution.min.js"></script>
		<!-- Theme Custom -->
		<script src="<?= base_url() ?>public/assets/js/custom.js"></script>
		<!-- Theme Initialization Files -->
		<script src="<?= base_url() ?>public/assets/js/theme.init.js"></script>
		<!-- Examples -->
		<script src="<?= base_url() ?>public/assets/js/examples.portfolio.js"></script>

		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.bootstrap5.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
		<script type="text/javascript" language="javascript"
				src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.colVis.min.js"></script>
	</div>
</header>
