<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh" style="color:#030F6B">
	<div class="container">
		<h3>
			<strong>TAHAP VERIFIKASI</strong>
		</h3>
		<hr>
		<form action="<?= base_url() ?>tahap-verifikasi" method="get" class="form-inline">
			<label class="form-check-label mr-1 mb-2 mr-sm-2">
				Filter Tahun:
			</label>
			<select class="custom-select mb-2 mr-sm-2" name="tahun">
				<?php foreach ($tahunData as $tahun): ?>
					<option
						value="<?= $tahun ?>" <?= $selectedTahun == $tahun ? "selected" : "" ?>><?= $tahun ?>
					</option>
				<?php endforeach; ?>
			</select>

			<button type="submit" class="btn btn-primary mb-2">Filter</button>
		</form>
		<table id="tabel-permohonan" class="table table-striped" style="width:100%">
			<thead>
			<tr>
				<th width="1%" class="text-center bg-primary text-light">No</th>
				<th class="bg-primary text-light">Pemohon</th>
				<th class="bg-primary text-light">Perumahan</th>
				<th class="bg-primary text-light">Perusahaan</th>
				<th class="bg-primary text-light">Alamat Pemohon</th>
			</tr>
			</thead>
			<tbody>
			<?php foreach ($permohonan as $index => $data): ?>
				<tr>
					<td class="text-center px-0"><?= $index + 1 ?></td>
					<td><?= $data->namaPemohon ?></td>
					<td><?= $data->perumahan->nama ?></td>
					<td><?= $data->perumahan->perusahaan ?></td>
					<td><?= $data->alamatPemohon ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</section>
<!-- content end -->

<script>
	document.addEventListener("DOMContentLoaded", function (event) {
		$('#tabel-permohonan').DataTable({
			"paging": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"language": {
				"paginate": {
					"previous": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-left</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg></span>',
					"next": '<span><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chevron-right" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/chevron-right</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg></span>',
				},
			},
			"dom": 'Bfrtip',
			"buttons": ['copy', 'excel', {
				"extend": 'pdf',
				"orientation": 'landscape',
			}, 'colvis']
		});
	});
</script>

<?php $this->load->view("partials/footer") ?>
