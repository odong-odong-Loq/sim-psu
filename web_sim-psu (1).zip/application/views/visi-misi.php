<?php $this->load->view("partials/header") ?>
<?php $this->load->view("partials/navbar") ?>

<!-- content start -->
<section class="section px-3 min-height-100vh">
	<div class="container">
		<h3>
			<strong>VISI DAN MISI WALIKOTA SUKABUMI</strong>
		</h3>
		<hr>
		<div class="row">
			<h4><strong> VISI </strong></h4>
			<p style="margin-left: 40px;"> Terwujudnya kota Sukabumi yang religius, nyaman, dan
				sejahtera. </p>
		</div>
		<div class="row">
			<h4><strong>MISI</strong></h4><br>
			<ol style="margin-left: 40px;">
				<li>Mewujudkan masyarakat yang berakhlakulkarimah, sehat, cerdas, kreatif,dan berbudaya serta memiliki
					kesetiakawanan sosial.
				</li>
				<li>Mewujudkan tata ruang dan infrastruktur yang berkualitas dan berwawasan lingkungan.</li>
				<li>Mewujudkan ekonomi daerah yang maju bertumpu pada sektor perdagangan,ekonomi kreatif, dan pariwisata
					melalui prinsip kemitraan dengan dunia usaha, dunia pendidikan dan daerah sekitar.
				</li>
				<li>Mewujudkan tata kelola pemerintahan yang baik (good governance) dan inovatif.</li>
			</ol>

		</div>
		<br>
		<hr>
		<div class="row">
			<p><strong> Visi Pembangunan Kota Sukabumi Tahun 2005-2025 Yang Termuat Dalam RPJPD
					Kota Sukabumi Tahun 2005-2025 Yaitu :</strong> <br></p>
			<p style="margin-left:40px;">Terwujudnya kota Sukabumi sebagai pusat pelayanan berkualitas di
				bidang pendidikan, kesehatan dan perdagangan di Jawa Barat berdasarkan iman dan takwa. </p>
		</div>
		<div class="row">
			<h4><strong>Misi</strong></h4><br>
			<ol style="margin-left: 40px;">
				<li>Mewujudkan sumber daya manusia yang beriman, bertaqwa dan berbudaya.</li>
				<li>Mewujudkan Pelayanan pendidikan yang berkualitas.</li>
				<li>Mewujudkan pelayanan kesehatan yang berkualitas.</li>
				<li>Mewujudkan pengembangan perdagangan dan sektor lapangan usaha lainya yang berdaya saing tinggi.</li>
				<li>Mewujudkan tata kelola pemerintahan yang baik dengan aparatur pemerintahan daerah yang profesional
					dan amanah.
				</li>
				<li>Mewujudkan kota sukabumi yang aman dan indah.</li>
			</ol>
		</div>
		<br>
		<hr>
		<div class="row">
			<h4><strong>Visi Pemerintahan Kota Sukabumi</strong></h4>
		</div>
		<br>
		<div class="row"><p style="margin-left: 40px;">Dengan Iman Dan Taqwa Mewujudkan Pemerintahan
				Rahmatan Lil Alamin (Perda Kota Sukabumi No.5 Tahun 2013) </p>
		</div>
	</div>
</section>
<!-- content end -->

<?php $this->load->view("partials/footer") ?>
