<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SlideController extends CI_Controller
{
	private $slideModel;

	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
		$this->load->model("SlideModel");

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata('error', 'Silahkan login terlebih dahulu.');
			redirect("login");
		}

		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$this->slideModel = new SlideModel();
	}

	public function slide()
	{
		$this->load->view("pengguna/slide", [
			"title" => "Slide | SIM PSU Kota Sukabumi",
			"pageTitle" => "Slide",
			"activeMenu" => 6,
			"activeSubMenu" => 2,
			"slide" => $this->slideModel->all()
		]);
	}

	public function postTambah()
	{
		// validasi request
		if (empty($_FILES['gambar']['name'])) {
			$this->form_validation->set_rules("gambar", "Gambar", "required");
			$this->form_validation->set_message("required", "%s wajib diisi.");
			if ($this->form_validation->run() == FALSE) {
				$this->session->set_flashdata("tambah_validation_errors", $this->form_validation->error_array());
				$this->session->set_flashdata("show_tambah_slide_modal", true);
				redirect("slide");
			}
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/slide/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('gambar')) {
			$this->session->set_flashdata("tambah_validation_errors", ["gambar" => $this->upload->display_errors()]);
			$this->session->set_flashdata("show_tambah_slide_modal", true);
			redirect("slide");
		} else {
			$uploadedGambar = $this->upload->data();

			// simpan slide
			$slide = new Slide();
			$slide->gambar = $uploadedGambar["file_name"];
			$this->slideModel->save($slide);
		}

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Slide berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("slide");
	}

	public function postHapus()
	{
		$id = $this->input->post("id");

		// cek slide
		$slide = $this->slideModel->find($id);
		if ($slide == null) {
			redirect("slide");
		}

		// hapus gambar
		$path = FCPATH . '/public/uploads/slide/';
		if (file_exists($path . $slide->gambar)) {
			unlink($path . $slide->gambar);
		}

		// hapus slide
		$this->slideModel->delete($slide->id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Slide berhasil dihapus.",
			"icon" => "success"
		]);

		redirect("slide");
	}

	public function edit()
	{
		$id = $this->input->get("id");

		$slide = $this->slideModel->find($id);
		$this->session->set_flashdata("old_edit_slide", [
			"id" => $slide->id,
		]);
		$this->session->set_flashdata("show_edit_slide_modal", true);

		redirect("slide");
	}

	public function postEdit()
	{
		$id = $this->input->post("id");

		// cek slide
		$slide = $this->slideModel->find($id);
		if ($slide == null) {
			redirect("slide");
		}

		// validasi request
		if (empty($_FILES['gambar']['name'])) {
			$this->form_validation->set_rules("gambar", "Gambar", "required");
			$this->form_validation->set_message("required", "%s wajib diisi.");
			if ($this->form_validation->run() == FALSE) {
				$this->session->set_flashdata("edit_validation_errors", $this->form_validation->error_array());
				$this->session->set_flashdata("show_edit_slide_modal", true);
				redirect("slide");
			}
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/slide/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('gambar')) {
			$this->session->set_flashdata("edit_validation_errors", ["gambar" => $this->upload->display_errors()]);
			$this->session->set_flashdata("show_edit_slide_modal", true);
			redirect("slide");
		} else {
			$uploadedGambar = $this->upload->data();

			// hapus gambar lama
			$path = FCPATH . '/public/uploads/slide/';
			if (file_exists($path . $slide->gambar)) {
				unlink($path . $slide->gambar);
			}

			// update slide
			$slide->gambar = $uploadedGambar["file_name"];
			$this->slideModel->update($slide);
		}

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Slide berhasil diubah.",
			"icon" => "success"
		]);

		redirect("slide");
	}
}
