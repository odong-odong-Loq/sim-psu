<?php
defined("BASEPATH") or exit("No direct script access allowed");

require_once __DIR__ . "/../data/TambahPenggunaRequest.php";
require_once __DIR__ . "/../data/EditPenggunaRequest.php";
require_once __DIR__ . "/../data/EditProfileRequest.php";
require_once __DIR__ . "/../data/EditPasswordRequest.php";
require_once __DIR__ . "/../data/Pengguna.php";

class PenggunaController extends CI_Controller
{
	private $penggunaModel;

	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
		$this->load->model("PenggunaModel");

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata("error", "Silahkan login terlebih dahulu.");
			redirect("login");
		}

		$this->penggunaModel = new PenggunaModel();
	}

	public function pengguna()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$this->load->view("pengguna/pengguna", [
			"title" => "Pengguna | SIM PSU Kota Sukabumi",
			"pageTitle" => "Pengguna",
			"activeMenu" => 6,
			"activeSubMenu" => 1,
			"pengguna" => $this->penggunaModel->all()
		]);
	}

	public function pengaturan()
	{
		$this->load->view("pengguna/pengaturan", [
			"title" => "Pengaturan | SIM PSU Kota Sukabumi",
			"pageTitle" => "Pengaturan",
			"activeMenu" => 7,
			"activeSubMenu" => null
		]);
	}

	public function postTambah()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$request = new TambahPenggunaRequest();
		$request->namaLengkap = $this->input->post("nama_lengkap");
		$request->username = $this->input->post("username");
		$request->password = $this->input->post("password");

		// validasi request
		$this->form_validation->set_rules("nama_lengkap", "Nama lengkap", "required");
		$this->form_validation->set_rules("username", "Username", "required|is_unique[pengguna.username]");
		$this->form_validation->set_rules("password", "Password", "required");
		$this->form_validation->set_rules("konfirmasi_password", "Konfirmasi password", "required|matches[password]");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		$this->form_validation->set_message("matches", "%s tidak sama.");
		$this->form_validation->set_message("is_unique", "%s sudah digunakan.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_tambah_pengguna", $this->input->post());
			$this->session->set_flashdata("tambah_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_tambah_pengguna_modal", true);
			redirect("pengguna");
		}

		// simpan pengguna
		$pengguna = new Pengguna();
		$pengguna->namaLengkap = $request->namaLengkap;
		$pengguna->username = $request->username;
		$pengguna->password = md5($request->password);
		$this->penggunaModel->save($pengguna);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Pengguna berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("pengguna");
	}

	public function postHapus()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") redirect("dashboard");

		$id = $this->input->post("id");

		// cek pengguna
		$pengguna = $this->penggunaModel->find($id);
		if ($pengguna == null) {
			redirect("pengguna");
		}

		// hapus gambar lama
		if ($pengguna->foto != "default.png") {
			$path = FCPATH . '/public/uploads/pengguna/';
			if (file_exists($path . $pengguna->foto)) {
				unlink($path . $pengguna->foto);
			}
		}

		// hapus pengguna
		$this->penggunaModel->delete($id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Pengguna berhasil dihapus.",
			"icon" => "success"
		]);

		redirect("pengguna");
	}

	public function edit()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$id = $this->input->get("id");

		$pengguna = $this->penggunaModel->find($id);
		$this->session->set_flashdata("old_edit_pengguna", [
			"id" => $pengguna->id,
			"nama_lengkap" => $pengguna->namaLengkap,
			"username" => $pengguna->username
		]);
		$this->session->set_flashdata("show_edit_pengguna_modal", true);

		redirect("pengguna");
	}

	public function postEdit()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$request = new EditPenggunaRequest();
		$request->id = $this->input->post("id");
		$request->namaLengkap = $this->input->post("nama_lengkap");
		$request->username = $this->input->post("username");
		$request->password = $this->input->post("password");

		// cek pengguna
		$pengguna = $this->penggunaModel->find($request->id);
		if ($pengguna == null) {
			redirect("pengguna");
		}

		// validasi request
		$this->form_validation->set_rules("nama_lengkap", "Nama lengkap", "required");
		$this->form_validation->set_rules("username", "Username", "required");

		// cek username
		$existedPengguna = $this->penggunaModel->findByUsername($request->username);
		if (($existedPengguna != null) && ($existedPengguna->id != $request->id)) {
			$this->form_validation->set_rules("username", "Username", "required|is_unique[pengguna.username]");
		}

		// cek jika password di reset
		if ($request->password != "") {
			$this->form_validation->set_rules("password", "Password", "required");
			$this->form_validation->set_rules("konfirmasi_password", "Konfirmasi password", "required|matches[password]");
			$pengguna->password = md5($request->password);
		}

		$this->form_validation->set_message("required", "%s wajib diisi.");
		$this->form_validation->set_message("matches", "%s tidak sama.");
		$this->form_validation->set_message("is_unique", "%s sudah digunakan.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_edit_pengguna", $this->input->post());
			$this->session->set_flashdata("edit_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_edit_pengguna_modal", true);
			redirect("pengguna");
		}

		// update pengguna
		$pengguna->id = $request->id;
		$pengguna->namaLengkap = $request->namaLengkap;
		$pengguna->username = $request->username;
		$this->penggunaModel->update($pengguna);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Pengguna berhasil diubah.",
			"icon" => "success"
		]);

		redirect("pengguna");
	}

	public function detail()
	{
		if ($this->session->userdata("pengguna")["role"] != "admin") redirect("dashboard");

		$id = $this->input->get("id");

		$pengguna = $this->penggunaModel->find($id);
		$this->session->set_flashdata("old_detail_pengguna", [
			"id" => $pengguna->id,
			"nama_lengkap" => $pengguna->namaLengkap,
			"foto" => $pengguna->foto,
			"username" => $pengguna->username,
			"role" => $pengguna->role,
		]);
		$this->session->set_flashdata("show_detail_pengguna_modal", true);

		redirect("pengguna");
	}

	public function postEditProfile()
	{
		$request = new EditProfileRequest();
		$request->id = $this->session->userdata("pengguna")["id"];
		$request->namaLengkap = $this->input->post("nama_lengkap");

		// cek pengguna
		$pengguna = $this->penggunaModel->find($request->id);
		if ($pengguna == null) {
			redirect("pengaturan");
		}

		// validasi request
		$this->form_validation->set_rules("nama_lengkap", "Nama lengkap", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_edit_profile", $this->input->post());
			$this->session->set_flashdata("edit_profile_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_edit_profile_modal", true);
			redirect("pengaturan");
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/pengguna/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;

		$this->load->library('upload', $config);

		if (!empty($_FILES['gambar']['name'])) {
			if (!$this->upload->do_upload('gambar')) {
				$this->session->set_flashdata("edit_profile_validation_errors", ["gambar" => $this->upload->display_errors()]);
				$this->session->set_flashdata("show_edit_profile_modal", true);
				redirect("pengaturan");
			} else {
				$uploadedGambar = $this->upload->data();

				// hapus foto lama
				if ($pengguna->foto != "default.png") {
					$path = FCPATH . '/public/uploads/pengguna/';
					if (file_exists($path . $pengguna->foto)) {
						unlink($path . $pengguna->foto);
					}
				}

				$pengguna->foto = $uploadedGambar["file_name"];
			}
		}

		// update pengguna
		$pengguna->id = $request->id;
		$pengguna->namaLengkap = $request->namaLengkap;
		$this->penggunaModel->update($pengguna);

		// buat session
		$this->session->set_userdata([
			"pengguna" => (array)$pengguna,
		]);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Profile berhasil diubah.",
			"icon" => "success"
		]);

		redirect("pengaturan");
	}

	public function postEditPassword()
	{
		$request = new EditPasswordRequest();
		$request->id = $this->session->userdata("pengguna")["id"];
		$request->password = $this->input->post("password");
		$request->passwordBaru = $this->input->post("password_baru");

		// cek pengguna
		$pengguna = $this->penggunaModel->find($request->id);
		if ($pengguna == null) {
			redirect("pengaturan");
		}

		// validasi request
		$this->form_validation->set_rules("password", "Password", "required");
		$this->form_validation->set_rules("password_baru", "Password baru", "required");
		$this->form_validation->set_rules("konfirmasi_password", "Konfirmasi password", "required|matches[password_baru]");

		$this->form_validation->set_message("required", "%s wajib diisi.");
		$this->form_validation->set_message("matches", "%s tidak sama.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_edit_password", $this->input->post());
			$this->session->set_flashdata("edit_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_edit_password_modal", true);
			redirect("pengaturan");
		}

		// cek password
		if ($pengguna->password != md5($request->password)) {
			$this->session->set_flashdata("old_edit_password", $this->input->post());
			$this->session->set_flashdata("edit_validation_errors", ["password" => "Password salah."]);
			$this->session->set_flashdata("show_edit_password_modal", true);
			redirect("pengaturan");
		}

		// update pengguna
		$pengguna->id = $request->id;
		$pengguna->password = md5($request->passwordBaru);
		$this->penggunaModel->update($pengguna);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Password berhasil diubah.",
			"icon" => "success"
		]);

		redirect("pengaturan");
	}
}
