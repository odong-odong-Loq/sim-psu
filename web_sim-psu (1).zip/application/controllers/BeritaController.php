<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once __DIR__ . "/../data/TambahBeritaRequest.php";
require_once __DIR__ . "/../data/EditBeritaRequest.php";
require_once __DIR__ . "/../data/Berita.php";

class BeritaController extends CI_Controller
{
	private $beritaModel;

	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
		$this->load->model("BeritaModel");

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata('error', 'Silahkan login terlebih dahulu.');
			redirect("login");
		}

		if ($this->session->userdata("pengguna")["role"] != "admin") {
			redirect("dashboard");
		}

		$this->beritaModel = new BeritaModel();
	}

	public function berita()
	{
		$this->load->view("pengguna/berita", [
			"title" => "Berita | SIM PSU Kota Sukabumi",
			"pageTitle" => "Berita",
			"activeMenu" => 6,
			"activeSubMenu" => 3,
			"berita" => $this->beritaModel->all()
		]);
	}

	public function postTambah()
	{
		$request = new TambahBeritaRequest();
		$request->judul = $this->input->post("judul");
		$request->isi = $this->input->post("isi");

		// validasi request
		$this->form_validation->set_rules("judul", "Judul", "required|is_unique[berita.judul]");
		$this->form_validation->set_rules("isi", "Isi", "required");
		if (empty($_FILES['gambar']['name'])) $this->form_validation->set_rules("gambar", "Gambar", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		$this->form_validation->set_message("is_unique", "%s sudah digunakan.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_tambah_berita", $this->input->post());
			$this->session->set_flashdata("tambah_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_tambah_berita_modal", true);
			redirect("berita");
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/berita/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('gambar')) {
			$this->session->set_flashdata("tambah_validation_errors", ["gambar" => $this->upload->display_errors()]);
			$this->session->set_flashdata("show_tambah_berita_modal", true);
			redirect("berita");
		} else {
			$uploadedGambar = $this->upload->data();

			// simpan berita
			$berita = new Berita();
			$berita->gambar = $uploadedGambar["file_name"];
			$berita->judul = $request->judul;
			$berita->slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request->judul)));
			$berita->isi = $request->isi;
			$berita->tanggalDibuat = date('Y-m-d H:i:s');
			$berita->idPengguna = $this->session->userdata("pengguna")["id"];
			$this->beritaModel->save($berita);
		}

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Berita berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("berita");
	}

	public function postHapus()
	{
		$id = $this->input->post("id");

		// cek berita
		$berita = $this->beritaModel->find($id);
		if ($berita == null) {
			redirect("berita");
		}

		// hapus gambar
		$path = FCPATH . '/public/uploads/berita/';
		if (file_exists($path . $berita->gambar)) {
			unlink($path . $berita->gambar);
		}

		// hapus berita
		$this->beritaModel->delete($berita->id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Berita berhasil dihapus.",
			"icon" => "success"
		]);

		redirect("berita");
	}

	public function edit()
	{
		$id = $this->input->get("id");

		$berita = $this->beritaModel->find($id);
		$this->session->set_flashdata("old_edit_berita", (array)$berita);
		$this->session->set_flashdata("show_edit_berita_modal", true);

		redirect("berita");
	}

	public function postEdit()
	{
		$request = new EditBeritaRequest();
		$request->id = $this->input->post("id");
		$request->judul = $this->input->post("judul");
		$request->isi = $this->input->post("isi");

		// cek berita
		$berita = $this->beritaModel->find($request->id);
		if ($berita == null) {
			redirect("berita");
		}

		// validasi request
		$this->form_validation->set_rules("judul", "Judul", "required");
		$this->form_validation->set_rules("isi", "Isi", "required");

		// cek judul
		$existedBerita = $this->beritaModel->findByJudul($request->judul);
		if (($existedBerita != null) && ($existedBerita->id != $request->id)) {
			$this->form_validation->set_rules("judul", "Judul", "required|is_unique[berita.judul]");
		}

		$this->form_validation->set_message("required", "%s wajib diisi.");
		$this->form_validation->set_message("is_unique", "%s sudah digunakan.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_edit_berita", $this->input->post());
			$this->session->set_flashdata("edit_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_edit_berita_modal", true);
			redirect("berita");
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/berita/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;

		$this->load->library('upload', $config);

		if (!empty($_FILES['gambar']['name'])) {
			if (!$this->upload->do_upload('gambar')) {
				$this->session->set_flashdata("edit_validation_errors", ["gambar" => $this->upload->display_errors()]);
				$this->session->set_flashdata("show_edit_berita_modal", true);
				redirect("berita");
			} else {
				$uploadedGambar = $this->upload->data();

				// hapus gambar lama
				$path = FCPATH . '/public/uploads/berita/';
				if (file_exists($path . $berita->gambar)) {
					unlink($path . $berita->gambar);
				}

				$berita->gambar = $uploadedGambar["file_name"];
			}
		}

		// update berita
		$berita->judul = $request->judul;
		$berita->slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request->judul)));
		$berita->isi = $request->isi;
		$berita->tanggalDibuat = date('Y-m-d H:i:s');
		$berita->idPengguna = $this->session->userdata("pengguna")["id"];
		$this->beritaModel->update($berita);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Berita berhasil diubah.",
			"icon" => "success"
		]);

		redirect("berita");
	}
}
