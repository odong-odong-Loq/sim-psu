<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once __DIR__ . "/../data/AuthLoginRequest.php";

class AuthController extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
	}

	public function login()
	{
		if ($this->session->userdata("is_logged_in")) {
			redirect("dashboard");
		}

		$this->load->view("login", [
			"title" => "Login | SIM PSU Kota Sukabumi"
		]);
	}

	public function postLogin()
	{
		$this->load->model("PenggunaModel");

		$penggunaModel = new PenggunaModel();

		$request = new AuthLoginRequest();
		$request->username = $this->input->post("username");
		$request->password = $this->input->post("password");
		

		// validasi request
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_message('required', '%s wajib diisi.');
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('old', $this->input->post());
			$this->session->set_flashdata('validation_errors', $this->form_validation->error_array());
			 
			 redirect("login");
		}

		// validasi pengguna
		$pengguna = $penggunaModel->findByUsername($request->username, $request->password);
		 
		 
		if ($pengguna == null) {
			$this->session->set_flashdata('old', $this->input->post());
			$this->session->set_flashdata('login_error', 'Username atau Password salah.');
			redirect("login");
		}else {
				 
				// buat session
				$this->session->set_userdata([
					"is_logged_in" => true,
					"pengguna" => (array)$pengguna,
				]);

				redirect("dashboard");
			}  
 
		
	}

	public function logout()
	{
		$this->session->sess_destroy();

		redirect("login");
	}
}
