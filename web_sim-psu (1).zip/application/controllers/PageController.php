<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PageController extends CI_Controller
{
	public function beranda()
	{
		$this->load->model("SlideModel");
		$this->load->model("BeritaModel");

		$slideModel = new SlideModel();
		$beritaModel = new BeritaModel();

		$this->load->view("beranda", [
			"title" => "Beranda | SIM PSU Kota Sukabumi",
			"slide" => $slideModel->all(),
			"berita" => $beritaModel->all()
		]);
	}

	public function visiMisi()
	{
		$this->load->view("visi-misi", [
			"title" => "Visi - Misi | SIM PSU Kota Sukabumi"
		]);
	}

	public function tujuanSasaran()
	{
		$this->load->view("tujuan-sasaran", [
			"title" => "Tujuan - Sasaran DPUTR | SIM PSU Kota Sukabumi"
		]);
	}

	public function strukturOrganisasi()
	{
		$this->load->view("struktur-organisasi", [
			"title" => "Struktur Organisasi | SIM PSU Kota Sukabumi"
		]);
	}

	public function peraturan()
	{
		$this->load->view("peraturan", [
			"title" => "Peraturan | SIM PSU Kota Sukabumi"
		]);
	}

	public function prosedurSerahTerima()
	{
		$this->load->view("prosedur-serah-terima", [
			"title" => "Prosedur Serah Terima | SIM PSU Kota Sukabumi"
		]);
	}

	public function petaPerumahanRoadmap()
	{
		$this->load->model("PerumahanModel");

		$perumahanModel = new PerumahanModel();

		$this->load->view("peta-perumahan-roadmap", [
			"title" => "Peta Perumahan Berbasis Roadmap | SIM PSU Kota Sukabumi",
			"perumahan" => $perumahanModel->all()
		]);
	}

	public function petaPerumahanSatelite()
	{
		$this->load->model("PerumahanModel");

		$perumahanModel = new PerumahanModel();

		$this->load->view("peta-perumahan-satelite", [
			"title" => "Peta Perumahan Berbasis Satelite | SIM PSU Kota Sukabumi",
			"perumahan" => $perumahanModel->all()
		]);
	}

	public function petaRPP()
	{
		$this->load->model("RPPModel");

		$RPPModel = new RPPModel();


		$this->load->view("peta-RPP", [
			"title" => "Peta Rencana Pembangunan / Peruntukan | SIM PSU Kota Sukabumi",
			"perumahan" => $RPPModel->all()
		]);
	}


	public function infografis()
	{
		$this->load->model("PermohonanModel");

		$permohonanModel = new PermohonanModel();
		$permohonan = $permohonanModel->all();

		// tipe perumahan
		$tipePerumahan = [];
		foreach ($permohonan as $data) {
			$tipePerumahan[] = $data->tipePerumahan;
		}
		$tipePerumahan = array_unique($tipePerumahan, SORT_STRING);

		$jumlahTipePerumahan = [];
		foreach ($tipePerumahan as $data) {
			$jumlahTipePerumahan[$data] = 0;
		}

		foreach ($permohonan as $data) {
			if (isset($jumlahTipePerumahan[$data->tipePerumahan])) {
				$jumlahTipePerumahan[$data->tipePerumahan] += 1;
			}
		}

		// perumahan per kecamatan
		$kecamatanPerumahan = [];
		foreach ($permohonan as $data) {
			$kecamatanPerumahan[] = $data->kecamatanPerumahan;
		}
		$kecamatanPerumahan = array_unique($kecamatanPerumahan, SORT_STRING);

		$jumlahKecamatanPerumahan = [];
		foreach ($kecamatanPerumahan as $data) {
			$jumlahKecamatanPerumahan[$data] = 0;
		}

		foreach ($permohonan as $data) {
			if (isset($jumlahKecamatanPerumahan[$data->kecamatanPerumahan])) {
				$jumlahKecamatanPerumahan[$data->kecamatanPerumahan] += 1;
			}
		}

		// permohonan per status
		$jumlahPermohonanPerStatus = [
			"PSU Telah Diserahkan" => 0,
			"Tahap Verifikasi" => 0,
			"Belum Diverifikasi" => 0
		];
		foreach ($permohonan as $data) {
			if ($data->statusPenyerahan == 1) {
				$jumlahPermohonanPerStatus["PSU Telah Diserahkan"] += 1;
			}

			if ($data->statusBerkasPermohonan == 1 &&
				$data->statusBerkasPrasarana == 1 &&
				$data->statusBerkasSarana == 1 &&
				$data->statusBerkasBeritaAcara == 1 &&
				$data->statusBerkasLainnya == 1 &&
				$data->statusPenyerahan == 0) {
				$jumlahPermohonanPerStatus["Tahap Verifikasi"] += 1;
			} else {
				$jumlahPermohonanPerStatus["Belum Diverifikasi"] += 1;
			}
		}

		// permohonan per tahun
		$permohonanPerTahun = [];
		foreach ($permohonan as $data) {
			$permohonanPerTahun[date("Y", strtotime($data->tanggalTerbit))] = 0;
		}
		ksort($permohonanPerTahun);

		foreach ($permohonan as $data) {
			if (isset($permohonanPerTahun[date("Y", strtotime($data->tanggalTerbit))])) {
				$permohonanPerTahun[date("Y", strtotime($data->tanggalTerbit))] += 1;
			}
		}

		$this->load->view("infografis", [
			"title" => "Infografis | SIM PSU Kota Sukabumi",
			"jumlahTipePerumahan" => $jumlahTipePerumahan,
			"jumlahKecamatanPerumahan" => $jumlahKecamatanPerumahan,
			"jumlahPermohonanPerStatus" => $jumlahPermohonanPerStatus,
			"permohonanPerTahun" => $permohonanPerTahun,
		]);
	}

	public function tahapVerifikasi()
	{
		$this->load->model("PermohonanModel");

		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonanModel = new PermohonanModel();
		$permohonan = $permohonanModel->sudahTerverifikasi();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("tahap-verifikasi", [
			"title" => "Permohonan Dalam Tahap Verifikasi | SIM PSU Kota Sukabumi",
			"permohonan" => $permohonanModel->sudahTerverifikasi([
				[
					"column" => "YEAR(tanggal_terbit)",
					"value" => $tahun
				]
			]),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}

	public function asetPSU()
	{
		$this->load->model("PermohonanModel");

		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonanModel = new PermohonanModel();
		$permohonan = $permohonanModel->sudahPenyerahan();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("aset-psu", [
			"title" => "Aset PSU | SIM PSU Kota Sukabumi",
			"permohonan" => $permohonanModel->sudahPenyerahan([
				[
					"column" => "YEAR(tanggal_terbit)",
					"value" => $tahun
				]
			]),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}

	public function dashboard()
	{
		$this->load->library("session");
		$this->load->model("PermohonanModel");

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata('error', 'Silahkan login terlebih dahulu.');
			redirect("login");
		}

		$permohonanModel = new PermohonanModel();

		$this->load->view("pengguna/dashboard", [
			"title" => "Dashboard | SIM PSU Kota Sukabumi",
			"pageTitle" => "Dashboard",
			"activeMenu" => 1,
			"activeSubMenu" => null,
			"jumlahPermohonan" => count($permohonanModel->belumTerverifikasi()),
			"jumlahPermohonanTerverifikasi" => count($permohonanModel->sudahTerverifikasi()),
			"jumlahPenyerahanAset" => count($permohonanModel->sudahPenyerahan()),
		]);
	}

	public function baca($slug)
	{
		$this->load->model("BeritaModel");

		$beritaModel = new BeritaModel();
		$berita = $beritaModel->findBySlug($slug);

		if ($berita == null) {
			show_404();
		}

		$this->load->view("baca", [
			"title" => "$berita->judul | SIM PSU Kota Sukabumi",
			"berita" => $berita,
			"beritaLainnya" => $beritaModel->all(),
		]);
	}

	public function dataPermohonan()
	{
		$this->load->model("PermohonanModel");

		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonanModel = new PermohonanModel();
		$permohonan = $permohonanModel->all();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("data-permohonan", [
			"title" => "Data Permohonan | SIM PSU Kota Sukabumi",
			"permohonan" => $permohonanModel->filterByTahunTanggalTerbit($tahun),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}

	public function dataPerumahan()
	{
		$this->load->model("PermohonanModel");

		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonanModel = new PermohonanModel();
		$permohonan = $permohonanModel->all();
		$tahunData = [];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("data-perumahan", [
			"title" => "Data Perumahan | SIM PSU Kota Sukabumi",
			"permohonan" => $permohonanModel->filterByTahunTanggalTerbit($tahun),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}
}
