<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once __DIR__ . "/../data/TambahPerumahanRequest.php";
require_once __DIR__ . "/../data/EditPerumahanRequest.php";
require_once __DIR__ . "/../data/Perumahan.php";

class PerumahanController extends CI_Controller
{
	private $perumahanModel;

	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
		$this->load->model("PerumahanModel");

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata('error', 'Silahkan login terlebih dahulu.');
			redirect("login");
		}

		$this->perumahanModel = new PerumahanModel();
	}

	public function perumahan()
	{
		$this->load->view("pengguna/perumahan", [
			"title" => "Perumahan | SIM PSU Kota Sukabumi",
			"pageTitle" => "Perumahan",
			"activeMenu" => 5,
			"activeSubMenu" => null,
			"perumahan" => $this->perumahanModel->all()
		]);
	}

	public function postTambah()
	{
		$request = new TambahPerumahanRequest();
		$request->nama = $this->input->post("nama");
		$request->perusahaan = $this->input->post("perusahaan");
		$request->latitude = $this->input->post("latitude");
		$request->longitude = $this->input->post("longitude");

		// validasi request
		$this->form_validation->set_rules("nama", "Nama", "required");
		$this->form_validation->set_rules("perusahaan", "Perusahaan", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_tambah_perumahan", $this->input->post());
			$this->session->set_flashdata("tambah_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_tambah_perumahan_modal", true);
			redirect("perumahan");
		}

		// simpan perumahan
		$perumahan = new Perumahan();
		$perumahan->nama = $request->nama;
		$perumahan->perusahaan = $request->perusahaan;
		$perumahan->latitude = $request->latitude;
		$perumahan->longitude = $request->longitude;
		$this->perumahanModel->save($perumahan);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Perumahan berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("perumahan");
	}

	public function postHapus()
	{
		$id = $this->input->post("id");

		// hapus perumahan
		$this->perumahanModel->delete($id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Perumahan berhasil dihapus.",
			"icon" => "success"
		]);

		redirect("perumahan");
	}

	public function edit()
	{
		$id = $this->input->get("id");

		$perumahan = $this->perumahanModel->find($id);
		$this->session->set_flashdata("old_edit_perumahan", (array)$perumahan);
		$this->session->set_flashdata("show_edit_perumahan_modal", true);

		redirect("perumahan");
	}

	public function postEdit()
	{
		$request = new EditPerumahanRequest();
		$request->id = $this->input->post("id");
		$request->nama = $this->input->post("nama");
		$request->perusahaan = $this->input->post("perusahaan");
		$request->longitude = $this->input->post("longitude");
		$request->latitude = $this->input->post("latitude");

		// cek perumahan
		$perumahan = $this->perumahanModel->find($request->id);
		if ($perumahan == null) {
			redirect("perumahan");
		}

		// validasi request
		$this->form_validation->set_rules("nama", "Nama", "required");
		$this->form_validation->set_rules("perusahaan", "Perusahaan", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_edit_perumahan", $this->input->post());
			$this->session->set_flashdata("edit_validation_errors", $this->form_validation->error_array());
			$this->session->set_flashdata("show_edit_perumahan_modal", true);
			redirect("perumahan");
		}

		// update perumahan
		$perumahan->id = $request->id;
		$perumahan->nama = $request->nama;
		$perumahan->perusahaan = $request->perusahaan;
		$perumahan->latitude = $request->latitude;
		$perumahan->longitude = $request->longitude;
		$this->perumahanModel->update($perumahan);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Perumahan berhasil diubah.",
			"icon" => "success"
		]);

		redirect("perumahan");
	}
}
