<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once __DIR__ . "/../data/TambahPermohonanRequest.php";
require_once __DIR__ . "/../data/EditPermohonanRequest.php";
require_once __DIR__ . "/../data/Permohonan.php";
require_once __DIR__ . "/../data/RPP.php";

class RPPController  extends CI_Controller
{
	private $permohonanModel;
	private $perumahanModel;

	public function __construct()
	{
		parent::__construct();
		$this->load->library(["session", "form_validation"]);
		$this->load->model(["RPPModel"]);

		if (!$this->session->userdata("is_logged_in")) {
			$this->session->set_flashdata('error', 'Silahkan login terlebih dahulu.');
			redirect("login");
		}

		$this->RPPModel = new RPPModel();
		 
	}

	public function penyerahanAset()
	{
		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonan = $this->permohonanModel->sudahPenyerahan();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("pengguna/penyerahan-aset", [
			"title" => "Penyerahan Aset | SIM PSU Kota Sukabumi",
			"pageTitle" => "Penyerahan Aset",
			"activeMenu" => 2,
			"activeSubMenu" => null,
			"permohonan" => $this->permohonanModel->sudahPenyerahan([
				[
					"column" => "YEAR(tanggal_terbit)",
					"value" => $tahun
				]
			]),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}

	public function terverifikasi()
	{
		$tahun = $_GET['tahun'] ?? date("Y");
		$permohonan = $this->permohonanModel->sudahTerverifikasi();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->tanggalTerbit));
		}
		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("pengguna/terverifikasi", [
			"title" => "Terverifikasi | SIM PSU Kota Sukabumi",
			"pageTitle" => "Terverifikasi",
			"activeMenu" => 3,
			"activeSubMenu" => null,
			"permohonan" => $this->permohonanModel->sudahTerverifikasi([
				[
					"column" => "YEAR(tanggal_terbit)",
					"value" => $tahun
				]
			]),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData
		]);
	}

	public function rpp()
	{
		$tahun = $_GET['tahun'] ?? date("Y"); 
	 

		$permohonan = $this->RPPModel->all();
		$tahunData = [date("Y")];
		foreach ($permohonan as $data) {
			$tahunData[] = date("Y", strtotime($data->TanggalDisposisi));
		}

		rsort($tahunData);
		$tahunData = array_unique($tahunData, SORT_STRING);

		$this->load->view("pengguna/rpp", [
			"title" => "Rencana Pembangunan / Peruntukan | SIM PSU Kota Sukabumi",
			"pageTitle" => "Rencana Pembangunan / Peruntukan",
			"activeMenu" => 6,
			"activeSubMenu" => null,
			"permohonan" => $this->RPPModel->all([
				[
					"column" => "YEAR(TanggalSuratPermohonan)",
					"value" => $tahun
				]
			]),
			"selectedTahun" => $tahun,
			"tahunData" => $tahunData]);
	}

	public function tambah()
	{
		$this->load->view("pengguna/tambah-permohonan", [
			"title" => "Permohonan | SIM PSU Kota Sukabumi",
			"pageTitle" => "Permohonan",
			"activeMenu" => 4,
			"activeSubMenu" => null,
			"perumahan" => $this->perumahanModel->all()
		]);
	}

	public function postTambah()
	{
		$request = new TambahPermohonanRequest();
		$request->nomorSuratPengesahan = $this->input->post("nomor_surat_pengesahan");
		$request->tanggalTerbit = $this->input->post("tanggal_terbit");
		$request->keterangan = $this->input->post("keterangan");
		$request->namaPemohon = $this->input->post("nama_pemohon");
		$request->alamatPemohon = $this->input->post("alamat_pemohon");
		$request->kecamatanPemohon = $this->input->post("kecamatan_pemohon");
		$request->kelurahanPemohon = $this->input->post("kelurahan_pemohon");
		$request->kotaPemohon = $this->input->post("kota_pemohon");
		$request->idPerumahan = $this->input->post("id_perumahan");
		$request->tipePerumahan = $this->input->post("tipe_perumahan");
		$request->alamatPerumahan = $this->input->post("alamat_perumahan");
		$request->kecamatanPerumahan = $this->input->post("kecamatan_perumahan");
		$request->kelurahanPerumahan = $this->input->post("kelurahan_perumahan");
		$request->kotaPerumahan = $this->input->post("kota_perumahan");
		$request->jumlahUnit = $this->input->post("jumlah_unit");
		$request->luasKav = $this->input->post("luas_kav");
		$request->luasEfektif = $this->input->post("luas_efektif");
		$request->luasFasum = $this->input->post("luas_fasum");
		$request->luasTpu = $this->input->post("luas_tpu");
		$request->luasRTH = $this->input->post("luasRTH");

		// validasi request
		$this->form_validation->set_rules("nomor_surat_pengesahan", "Nomor surat pengesahan", "required");
		$this->form_validation->set_rules("tanggal_terbit", "Tanggal terbit", "required");
		$this->form_validation->set_rules("keterangan", "Keterangan", "required");
		$this->form_validation->set_rules("nama_pemohon", "Nama lengkap", "required");
		$this->form_validation->set_rules("alamat_pemohon", "Alamat", "required");
		$this->form_validation->set_rules("kecamatan_pemohon", "Kecamatan", "required");
		$this->form_validation->set_rules("kelurahan_pemohon", "Kelurahan", "required");
		$this->form_validation->set_rules("kota_pemohon", "Kota", "required");
		$this->form_validation->set_rules("id_perumahan", "Perumahan", "required");
		$this->form_validation->set_rules("tipe_perumahan", "Tipe", "required");
		$this->form_validation->set_rules("alamat_perumahan", "Alamat", "required");
		$this->form_validation->set_rules("kecamatan_perumahan", "Kecamatan", "required");
		$this->form_validation->set_rules("kelurahan_perumahan", "Kelurahan", "required");
		$this->form_validation->set_rules("kota_perumahan", "Kota", "required");
		$this->form_validation->set_rules("jumlah_unit", "Jumlah unit", "required");
		$this->form_validation->set_rules("luas_kav", "Luas kav", "required");
		$this->form_validation->set_rules("luas_efektif", "Luas efektif", "required");
		$this->form_validation->set_rules("luas_fasum", "Luas fasum", "required");
		$this->form_validation->set_rules("luas_tpu", "Luas tpu", "required");
		$this->form_validation->set_rules("luasRTH", "Luas tpu", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
			$this->session->set_flashdata("validation_errors", $this->form_validation->error_array());
			redirect("permohonan/tambah");
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/permohonan/';
		$config['allowed_types'] = 'doc|docx|pdf';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;
		$config['max_size'] = 5000;

		$this->load->library('upload', $config);

		// cek jika berkas permohonan diupload
		if (!empty($_FILES['berkas_permohonan']['name'])) {
			if (!$this->upload->do_upload('berkas_permohonan')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_permohonan" => $this->upload->display_errors()]);
				redirect("permohonan/tambah");
			} else {
				$uploadedBerkas = $this->upload->data();
				$request->berkasPermohonan = $uploadedBerkas["file_name"];
				$request->statusBerkasPermohonan = $this->input->post("status_berkas_permohonan") ?? 0;
			}
		}

		// cek jika berkas prasarana diupload
		if (!empty($_FILES['berkas_prasarana']['name'])) {
			if (!$this->upload->do_upload('berkas_prasarana')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_prasarana" => $this->upload->display_errors()]);
				redirect("permohonan/tambah");
			} else {
				$uploadedBerkas = $this->upload->data();
				$request->berkasPrasarana = $uploadedBerkas["file_name"];
				$request->statusBerkasPrasarana = $this->input->post("status_berkas_prasarana") ?? 0;
			}
		}

		// cek jika berkas sarana diupload
		if (!empty($_FILES['berkas_sarana']['name'])) {
			if (!$this->upload->do_upload('berkas_sarana')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_sarana" => $this->upload->display_errors()]);
				redirect("permohonan/tambah");
			} else {
				$uploadedBerkas = $this->upload->data();
				$request->berkasSarana = $uploadedBerkas["file_name"];
				$request->statusBerkasSarana = $this->input->post("status_berkas_sarana") ?? 0;
			}
		}

		// cek jika berkas berita acara diupload
		if (!empty($_FILES['berkas_berita_acara']['name'])) {
			if (!$this->upload->do_upload('berkas_berita_acara')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_berita_acara" => $this->upload->display_errors()]);
				redirect("permohonan/tambah");
			} else {
				$uploadedBerkas = $this->upload->data();
				$request->berkasBeritaAcara = $uploadedBerkas["file_name"];
				$request->statusBerkasBeritaAcara = $this->input->post("status_berkas_berita_acara") ?? 0;
			}
		}

		// cek jika berkas lainnya diupload
		if (!empty($_FILES['berkas_lainnya']['name'])) {
			if (!$this->upload->do_upload('berkas_lainnya')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_lainnya" => $this->upload->display_errors()]);
				redirect("permohonan/tambah");
			} else {
				$uploadedBerkas = $this->upload->data();
				$request->berkasLainnya = $uploadedBerkas["file_name"];
				$request->statusBerkasLainnya = $this->input->post("status_berkas_lainnya") ?? 0;
			}
		}

		// simpan permohonan
		$this->permohonanModel->save($request);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Permohonan berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("permohonan/tambah");
	}

	public function postHapus()
	{
		$id = $this->input->post("id");

		// cek permohonan
		$permohonan = $this->permohonanModel->find($id);
		if ($permohonan == null) {
			redirect("permohonan");
		}

		// hapus berkas lama
		$path = FCPATH . '/public/uploads/permohonan/';
		if (file_exists($path . $permohonan->berkasPermohonan)) {
			unlink($path . $permohonan->berkasPermohonan);
		}
		if (file_exists($path . $permohonan->berkasPrasarana)) {
			unlink($path . $permohonan->berkasPrasarana);
		}
		if (file_exists($path . $permohonan->berkasSarana)) {
			unlink($path . $permohonan->berkasSarana);
		}
		if (file_exists($path . $permohonan->berkasBeritaAcara)) {
			unlink($path . $permohonan->berkasBeritaAcara);
		}
		if (file_exists($path . $permohonan->statusBerkasLainnya)) {
			unlink($path . $permohonan->statusBerkasLainnya);
		}

		// hapus permohonan
		$this->permohonanModel->delete($id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Permohonan berhasil dihapus.",
			"icon" => "success"
		]);

		redirect("permohonan");
	}

	public function edit()
	{
		$id = $this->input->get("id");

		$this->load->view("pengguna/edit-permohonan", [
			"title" => "Permohonan | SIM PSU Kota Sukabumi",
			"pageTitle" => "Permohonan",
			"activeMenu" => 4,
			"activeSubMenu" => null,
			"permohonan" => $this->permohonanModel->find($id),
			"perumahan" => $this->perumahanModel->all()
		]);
	}

	public function postEdit()
	{
		$request = new EditPermohonanRequest();
		$request->id = $this->input->post("id");

		// cek permohonan
		$permohonan = $this->permohonanModel->find($request->id);
		if ($permohonan == null) {
			redirect("permohonan/edit?id=" . $request->id);
		}

		$request->nomorSuratPengesahan = $this->input->post("nomor_surat_pengesahan");
		$request->tanggalTerbit = $this->input->post("tanggal_terbit");
		$request->keterangan = $this->input->post("keterangan");
		$request->namaPemohon = $this->input->post("nama_pemohon");
		$request->alamatPemohon = $this->input->post("alamat_pemohon");
		$request->kecamatanPemohon = $this->input->post("kecamatan_pemohon");
		$request->kelurahanPemohon = $this->input->post("kelurahan_pemohon");
		$request->kotaPemohon = $this->input->post("kota_pemohon");
		$request->idPerumahan = $this->input->post("id_perumahan");
		$request->tipePerumahan = $this->input->post("tipe_perumahan");
		$request->alamatPerumahan = $this->input->post("alamat_perumahan");
		$request->kecamatanPerumahan = $this->input->post("kecamatan_perumahan");
		$request->kelurahanPerumahan = $this->input->post("kelurahan_perumahan");
		$request->kotaPerumahan = $this->input->post("kota_perumahan");
		$request->jumlahUnit = $this->input->post("jumlah_unit");
		$request->luasKav = $this->input->post("luas_kav");
		$request->luasEfektif = $this->input->post("luas_efektif");
		$request->luasFasum = $this->input->post("luas_fasum");
		$request->luasTpu = $this->input->post("luas_tpu");
		$request->luasRTH = $this->input->post("luasRTH");
		$request->statusBerkasPermohonan = $this->input->post("status_berkas_permohonan") ?? 0;
		$request->statusBerkasPrasarana = $this->input->post("status_berkas_prasarana") ?? 0;
		$request->statusBerkasSarana = $this->input->post("status_berkas_sarana") ?? 0;
		$request->statusBerkasBeritaAcara = $this->input->post("status_berkas_berita_acara") ?? 0;
		$request->statusBerkasLainnya = $this->input->post("status_berkas_lainnya") ?? 0;

		// validasi request
		$this->form_validation->set_rules("nomor_surat_pengesahan", "Nomor surat pengesahan", "required");
		$this->form_validation->set_rules("tanggal_terbit", "Tanggal terbit", "required");
		$this->form_validation->set_rules("keterangan", "Keterangan", "required");
		$this->form_validation->set_rules("nama_pemohon", "Nama lengkap", "required");
		$this->form_validation->set_rules("alamat_pemohon", "Alamat", "required");
		$this->form_validation->set_rules("kecamatan_pemohon", "Kecamatan", "required");
		$this->form_validation->set_rules("kelurahan_pemohon", "Kelurahan", "required");
		$this->form_validation->set_rules("kota_pemohon", "Kota", "required");
		$this->form_validation->set_rules("id_perumahan", "Perumahan", "required");
		$this->form_validation->set_rules("tipe_perumahan", "Tipe", "required");
		$this->form_validation->set_rules("alamat_perumahan", "Alamat", "required");
		$this->form_validation->set_rules("kecamatan_perumahan", "Kecamatan", "required");
		$this->form_validation->set_rules("kelurahan_perumahan", "Kelurahan", "required");
		$this->form_validation->set_rules("kota_perumahan", "Kota", "required");
		$this->form_validation->set_rules("jumlah_unit", "Jumlah unit", "required");
		$this->form_validation->set_rules("luas_kav", "Luas kav", "required");
		$this->form_validation->set_rules("luas_efektif", "Luas efektif", "required");
		$this->form_validation->set_rules("luas_fasum", "Luas fasum", "required");
		$this->form_validation->set_rules("luas_tpu", "Luas tpu", "required");
		$this->form_validation->set_rules("luasRTH", "Luas RTH", "required");
		$this->form_validation->set_message("required", "%s wajib diisi.");
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
			$this->session->set_flashdata("validation_errors", $this->form_validation->error_array());
			redirect("permohonan/edit?id=" . $request->id);
		}

		// upload config
		$fileName = uniqid();
		$config['upload_path'] = FCPATH . '/public/uploads/permohonan/';
		$config['allowed_types'] = 'doc|docx|pdf';
		$config['file_name'] = $fileName;
		$config['overwrite'] = false;
		$config['max_size'] = 5000;

		$this->load->library('upload', $config);

		// cek jika berkas permohonan diupload
		if (!empty($_FILES['berkas_permohonan']['name'])) {
			if (!$this->upload->do_upload('berkas_permohonan')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_permohonan" => $this->upload->display_errors()]);
				redirect("permohonan/edit?id=" . $request->id);
			} else {
				$uploadedBerkas = $this->upload->data();

				// hapus berkas lama
				$path = FCPATH . '/public/uploads/permohonan/';
				if (file_exists($path . $permohonan->berkasPermohonan)) {
					unlink($path . $permohonan->berkasPermohonan);
				}

				$request->berkasPermohonan = $uploadedBerkas["file_name"];
			}
		} else {
			if ($permohonan->berkasPermohonan == null) {
				$request->statusBerkasPermohonan = 0;
			}
			$request->berkasPermohonan = $permohonan->berkasPermohonan;
		}

		// cek jika berkas prasarana diupload
		if (!empty($_FILES['berkas_prasarana']['name'])) {
			if (!$this->upload->do_upload('berkas_prasarana')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_prasarana" => $this->upload->display_errors()]);
				redirect("permohonan/edit?id=" . $request->id);
			} else {
				$uploadedBerkas = $this->upload->data();

				// hapus berkas lama
				$path = FCPATH . '/public/uploads/permohonan/';
				if (file_exists($path . $permohonan->berkasPrasarana)) {
					unlink($path . $permohonan->berkasPrasarana);
				}

				$request->berkasPrasarana = $uploadedBerkas["file_name"];
			}
		} else {
			if ($permohonan->berkasPrasarana == null) {
				$request->statusBerkasPrasarana = 0;
			}
			$request->berkasPrasarana = $permohonan->berkasPrasarana;
		}

		// cek jika berkas sarana diupload
		if (!empty($_FILES['berkas_sarana']['name'])) {
			if (!$this->upload->do_upload('berkas_sarana')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_sarana" => $this->upload->display_errors()]);
				redirect("permohonan/edit?id=" . $request->id);
			} else {
				$uploadedBerkas = $this->upload->data();

				// hapus berkas lama
				$path = FCPATH . '/public/uploads/permohonan/';
				if (file_exists($path . $permohonan->berkasSarana)) {
					unlink($path . $permohonan->berkasSarana);
				}

				$request->berkasSarana = $uploadedBerkas["file_name"];
			}
		} else {
			if ($permohonan->berkasSarana == null) {
				$request->statusBerkasSarana = 0;
			}
			$request->berkasSarana = $permohonan->berkasSarana;
		}

		// cek jika berkas berita acara diupload
		if (!empty($_FILES['berkas_berita_acara']['name'])) {
			if (!$this->upload->do_upload('berkas_berita_acara')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_berita_acara" => $this->upload->display_errors()]);
				redirect("permohonan/edit?id=" . $request->id);
			} else {
				$uploadedBerkas = $this->upload->data();

				// hapus berkas lama
				$path = FCPATH . '/public/uploads/permohonan/';
				if (file_exists($path . $permohonan->berkasBeritaAcara)) {
					unlink($path . $permohonan->berkasBeritaAcara);
				}

				$request->berkasBeritaAcara = $uploadedBerkas["file_name"];
			}
		} else {
			if ($permohonan->berkasBeritaAcara == null) {
				$request->statusBerkasBeritaAcara = 0;
			}
			$request->berkasBeritaAcara = $permohonan->berkasBeritaAcara;
		}

		// cek jika berkas lainnya diupload
		if (!empty($_FILES['berkas_lainnya']['name'])) {
			if (!$this->upload->do_upload('berkas_lainnya')) {
				$this->session->set_flashdata("old_tambah_permohonan", $this->input->post());
				$this->session->set_flashdata("validation_errors", ["berkas_lainnya" => $this->upload->display_errors()]);
				redirect("permohonan/edit?id=" . $request->id);
			} else {
				$uploadedBerkas = $this->upload->data();

				// hapus berkas lama
				$path = FCPATH . '/public/uploads/permohonan/';
				if (file_exists($path . $permohonan->berkasLainnya)) {
					unlink($path . $permohonan->berkasLainnya);
				}

				$request->berkasLainnya = $uploadedBerkas["file_name"];
			}
		} else {
			if ($permohonan->berkasLainnya == null) {
				$request->statusBerkasLainnya = 0;
			}
			$request->berkasLainnya = $permohonan->berkasLainnya;
		}

		// simpan perubahan
		$this->permohonanModel->update($request);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Permohonan berhasil diubah.",
			"icon" => "success"
		]);

		redirect("permohonan/edit?id=" . $request->id);
	}

	public function postPenyerahan()
	{
		$id = $this->input->post("id");

		// cek permohonan
		$permohonan = $this->permohonanModel->find($id);
		if ($permohonan == null) {
			redirect("terverifikasi");
		}

		$this->permohonanModel->penyerahan($id);

		// buat pesan
		$this->session->set_flashdata("message", [
			"title" => "Sukses!",
			"text" => "Penyerahan aset berhasil ditambahkan.",
			"icon" => "success"
		]);

		redirect("terverifikasi");
	}

	public function detail()
	{
		$id = $this->input->get("id");

		// cek permohonan
		$permohonan = $this->RPPModel->find($id);
		if ($permohonan == null) {
			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->session->set_flashdata("rpp", json_decode(json_encode($permohonan), true));
		$this->session->set_flashdata("show_detail_permohonan_modal", true);

		redirect($_SERVER['HTTP_REFERER']);
	}
}
