<?php

require_once __DIR__ . "/../data/Berita.php";

class BeritaModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function all(): array
	{
		$this->db->order_by("id_berita", "desc");
		$rows = $this->db->get("berita")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$berita = new Berita();
			$berita->id = $row["id_berita"];
			$berita->gambar = $row["gambar"];
			$berita->judul = $row["judul"];
			$berita->slug = $row["slug"];
			$berita->isi = $row["isi"];
			$berita->tanggalDibuat = $row["tanggal_dibuat"];
			$berita->idPengguna = $row["id_pengguna"];

			$result[] = $berita;
		}

		return $result;
	}

	public function save(Berita $berita): bool
	{
		return $this->db->insert("berita", [
			"gambar" => $berita->gambar,
			"judul" => $berita->judul,
			"slug" => $berita->slug,
			"isi" => $berita->isi,
			"tanggal_dibuat" => $berita->tanggalDibuat,
			"id_pengguna" => $berita->idPengguna,
		]);
	}

	public function find($id): ?Berita
	{
		$this->db->where("id_berita", $id);
		$row = $this->db->get("berita")->row_array();

		if ($row != null) {
			$berita = new Berita();
			$berita->id = $row["id_berita"];
			$berita->gambar = $row["gambar"];
			$berita->judul = $row["judul"];
			$berita->slug = $row["slug"];
			$berita->isi = $row["isi"];
			$berita->tanggalDibuat = $row["tanggal_dibuat"];
			$berita->idPengguna = $row["id_pengguna"];

			return $berita;
		} else {
			return null;
		}
	}

	public function update(Berita $berita)
	{
		$this->db->where('id_berita', $berita->id);
		$this->db->update("berita", [
			"gambar" => $berita->gambar,
			"judul" => $berita->judul,
			"slug" => $berita->slug,
			"isi" => $berita->isi,
			"tanggal_dibuat" => $berita->tanggalDibuat,
			"id_pengguna" => $berita->idPengguna,
		]);
	}

	public function delete($id): bool
	{
		$this->db->where("id_berita", $id);
		return $this->db->delete("berita");
	}

	public function findByJudul($judul): ?Berita
	{
		$this->db->where("judul", $judul);
		$row = $this->db->get("berita")->row_array();

		if ($row != null) {
			$berita = new Berita();
			$berita->id = $row["id_berita"];
			$berita->gambar = $row["gambar"];
			$berita->judul = $row["judul"];
			$berita->slug = $row["slug"];
			$berita->isi = $row["isi"];
			$berita->tanggalDibuat = $row["tanggal_dibuat"];
			$berita->idPengguna = $row["id_pengguna"];

			return $berita;
		} else {
			return null;
		}
	}

	public function findBySlug($slug): ?Berita
	{
		$this->db->where("slug", $slug);
		$row = $this->db->get("berita")->row_array();

		if ($row != null) {
			$berita = new Berita();
			$berita->id = $row["id"];
			$berita->gambar = $row["gambar"];
			$berita->judul = $row["judul"];
			$berita->slug = $row["slug"];
			$berita->isi = $row["isi"];
			$berita->tanggalDibuat = $row["tanggal_dibuat"];
			$berita->idPengguna = $row["id_pengguna"];

			return $berita;
		} else {
			return null;
		}
	}
}
