<?php

require_once __DIR__ . "/../data/Perumahan.php";

class PerumahanModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function all(): array
	{
	//	$this->db->order_by("id_perumahan", "desc");
	//	$rows = $this->db->get("perumahan")->result_array();
		$rows = $this->db->query("select a.*, b.nama_pemohon, b.alamat_pemohon, b.tipe_perumahan,
									b.alamat_perumahan, b.luas_kav, b.luas_efektif,b.luas_fasum,
									b.luas_tpu, b.luasRTH,b.jumlah_unit, b.nomor_surat_pengesahan,
									b.tanggal_terbit, b.keterangan, if(b.status_penyerahan=0,'Belum diserahkan','Sudah diserahkan') as penyerahan
									from perumahan a 
									left join permohonan b on b.id_perumahan=a.id_perumahan
									where length(a.longitude)>5  
									")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$perumahan = new Perumahan ();
			$perumahan->id = $row["id_perumahan"];
			$perumahan->nama = $row["nama"];
			$perumahan->perusahaan = $row["perusahaan"];
			$perumahan->latitude = $row["latitude"];
			$perumahan->longitude = $row["longitude"];
			$perumahan->nama_pemohon = $row["nama_pemohon"];
			$perumahan->alamat_pemohon = $row["alamat_pemohon"];
			$perumahan->tipe_perumahan = $row["tipe_perumahan"];
			$perumahan->alamat_perumahan = $row["alamat_perumahan"];
			$perumahan->luas_kav = $row["luas_kav"];
			$perumahan->luas_efektif = $row["luas_efektif"];
			$perumahan->luas_fasum = $row["luas_fasum"]; 
			$perumahan->luas_tpu = $row["luas_tpu"];
			$perumahan->luasRTH = $row["luasRTH"];
			$perumahan->jumlah_unit = $row["jumlah_unit"];
			$perumahan->nomor_surat_pengesahan = $row["nomor_surat_pengesahan"];
			$perumahan->tanggal_terbit = $row["tanggal_terbit"];
			$perumahan->keterangan = $row["keterangan"];
			$perumahan->penyerahan = $row["penyerahan"];
			 
			

			$result[] = $perumahan;
		}

		return $result;
	}

	public function save(Perumahan $perumahan): bool
	{
		return $this->db->insert("perumahan", [
			"nama" => $perumahan->nama,
			"perusahaan" => $perumahan->perusahaan,
			"latitude" => $perumahan->latitude,
			"longitude" => $perumahan->longitude,
		]);
	}

	public function find($id): ?Perumahan
	{
		$this->db->where("id_perumahan", $id);
		$row = $this->db->get("perumahan")->row_array();

		if ($row != null) {
			$perumahan = new Perumahan();
			$perumahan->id = $row["id_perumahan"];
			$perumahan->nama = $row["nama"];
			$perumahan->perusahaan = $row["perusahaan"];
			$perumahan->latitude = $row["latitude"];
			$perumahan->longitude = $row["longitude"];

			return $perumahan;
		} else {
			return null;
		}
	}

	public function update(Perumahan $perumahan)
	{
		$this->db->where('id_perumahan', $perumahan->id);
		$this->db->update("perumahan", [
			"nama" => $perumahan->nama,
			"perusahaan" => $perumahan->perusahaan,
			"latitude" => $perumahan->latitude,
			"longitude" => $perumahan->longitude,
		]);
	}

	public function delete($id): bool
	{
		$this->db->where("id_perumahan", $id);
		return $this->db->delete("perumahan");
	}
}
