<?php

require_once __DIR__ . "/../data/Slide.php";

class SlideModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function all(): array
	{
		$this->db->order_by("id", "desc");
		$rows = $this->db->get("slide")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$slide = new Slide();
			$slide->id = $row["id"];
			$slide->gambar = $row["gambar"];

			$result[] = $slide;
		}

		return $result;
	}

	public function save(Slide $slide): bool
	{
		return $this->db->insert("slide", [
			"gambar" => $slide->gambar,
		]);
	}

	public function find($id): ?Slide
	{
		$this->db->where("id", $id);
		$row = $this->db->get("slide")->row_array();

		if ($row != null) {
			$slide = new Slide();
			$slide->id = $row["id"];
			$slide->gambar = $row["gambar"];

			return $slide;
		} else {
			return null;
		}
	}

	public function update(Slide $slide)
	{
		$this->db->where('id', $slide->id);
		$this->db->update("slide", [
			"gambar" => $slide->gambar,
		]);
	}

	public function delete($id): bool
	{
		$this->db->where("id", $id);
		return $this->db->delete("slide");
	}
}
