<?php

require_once __DIR__ . "/../data/TambahPermohonanRequest.php";
require_once __DIR__ . "/../data/EditPermohonanRequest.php";
require_once __DIR__ . "/../data/Permohonan.php";
require_once __DIR__ . "/../data/Perumahan.php";

class PermohonanModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function all(): array
	{
		
		$this->db->order_by("id_perumahan_permohonan", "desc");
		$rows = $this->db->get("permohonan")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			//$this->db->distinct('nama');
			 
			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$this->db->group_by('nama');
			$this->db->order_by("longitude", "desc");
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			$result[] = $permohonan;
		}

		return $result;
	}

	public function save(TambahPermohonanRequest $request): bool
	{
		return $this->db->insert("permohonan", [
			"nama_pemohon" => $request->namaPemohon,
			"alamat_pemohon" => $request->alamatPemohon,
			"kelurahan_pemohon" => $request->kelurahanPemohon,
			"kecamatan_pemohon" => $request->kecamatanPemohon,
			"kota_pemohon" => $request->kotaPemohon,
			"alamat_perumahan" => $request->alamatPerumahan,
			"kelurahan_perumahan" => $request->kelurahanPerumahan,
			"kecamatan_perumahan" => $request->kecamatanPerumahan,
			"kota_perumahan" => $request->kotaPerumahan,
			"tipe_perumahan" => $request->tipePerumahan,
			"luas_kav" => $request->luasKav,
			"luas_efektif" => $request->luasEfektif,
			"luas_fasum" => $request->luasFasum,
			"luas_tpu" => $request->luasTpu,
			"luasRTH" => $request->luasRTH,
			"jumlah_unit" => $request->jumlahUnit,
			"nomor_surat_pengesahan" => $request->nomorSuratPengesahan,
			"tanggal_terbit" => $request->tanggalTerbit,
			"keterangan" => $request->keterangan,
			"berkas_permohonan" => $request->berkasPermohonan,
			"status_berkas_permohonan" => $request->statusBerkasPermohonan,
			"berkas_prasarana" => $request->berkasPrasarana,
			"status_berkas_prasarana" => $request->statusBerkasPrasarana,
			"berkas_sarana" => $request->berkasSarana,
			"status_berkas_sarana" => $request->statusBerkasSarana,
			"berkas_berita_acara" => $request->berkasBeritaAcara,
			"status_berkas_berita_acara" => $request->statusBerkasBeritaAcara,
			"berkas_lainnya" => $request->berkasLainnya,
			"status_berkas_lainnya" => $request->statusBerkasLainnya,
			"status_penyerahan" => $request->statusPenyerahan,
			"id_perumahan" => $request->idPerumahan
		]);
	}

	public function find($id): ?Permohonan
	{
		$this->db->where("id_perumahan_permohonan", $id);
		$row = $this->db->get("permohonan")->row_array();
		 

		if ($row != null) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			return $permohonan;
		} else {
			return null;
		}
	}

	public function update(EditPermohonanRequest $request)
	{
		$this->db->where('id_perumahan_permohonan', $request->id);
		$this->db->update("permohonan", [
			"nama_pemohon" => $request->namaPemohon,
			"alamat_pemohon" => $request->alamatPemohon,
			"kelurahan_pemohon" => $request->kelurahanPemohon,
			"kecamatan_pemohon" => $request->kecamatanPemohon,
			"kota_pemohon" => $request->kotaPemohon,
			"alamat_perumahan" => $request->alamatPerumahan,
			"kelurahan_perumahan" => $request->kelurahanPerumahan,
			"kecamatan_perumahan" => $request->kecamatanPerumahan,
			"kota_perumahan" => $request->kotaPerumahan,
			"tipe_perumahan" => $request->tipePerumahan,
			"luas_kav" => $request->luasKav,
			"luas_efektif" => $request->luasEfektif,
			"luas_fasum" => $request->luasFasum,
			"luas_tpu" => $request->luasTpu,
			"luasRTH" => $request->luasRTH,
			"jumlah_unit" => $request->jumlahUnit,
			"nomor_surat_pengesahan" => $request->nomorSuratPengesahan,
			"tanggal_terbit" => $request->tanggalTerbit,
			"keterangan" => $request->keterangan,
			"berkas_permohonan" => $request->berkasPermohonan,
			"status_berkas_permohonan" => $request->statusBerkasPermohonan,
			"berkas_prasarana" => $request->berkasPrasarana,
			"status_berkas_prasarana" => $request->statusBerkasPrasarana,
			"berkas_sarana" => $request->berkasSarana,
			"status_berkas_sarana" => $request->statusBerkasSarana,
			"berkas_berita_acara" => $request->berkasBeritaAcara,
			"status_berkas_berita_acara" => $request->statusBerkasBeritaAcara,
			"berkas_lainnya" => $request->berkasLainnya,
			"status_berkas_lainnya" => $request->statusBerkasLainnya,
			"status_penyerahan" => $request->statusPenyerahan,
			"id_perumahan" => $request->idPerumahan
		]);
	}

	public function delete($id): bool
	{
		$this->db->where("id_perumahan_permohonan", $id);
		return $this->db->delete("permohonan");
	}

	public function belumTerverifikasi($filters = []): array
	{
		foreach ($filters as $filter) {
			$this->db->where($filter['column'], $filter['value']);
		}

		$this->db->group_start();
		$this->db->or_where('status_berkas_permohonan', 0);
		$this->db->or_where('status_berkas_prasarana', 0);
		$this->db->or_where('status_berkas_sarana', 0);
		$this->db->or_where('status_berkas_berita_acara', 0);
		$this->db->or_where('status_berkas_lainnya', 0);
		$this->db->group_end();
		$this->db->order_by("id_perumahan", "desc");
		$rows = $this->db->get("permohonan")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			$result[] = $permohonan;
		}

		return $result;
	}

	public function sudahTerverifikasi($filters = []): array
	{
		foreach ($filters as $filter) {
			$this->db->where($filter['column'], $filter['value']);
		}

		$this->db->where('status_berkas_permohonan', 1);
		$this->db->where('status_berkas_prasarana', 1);
		$this->db->where('status_berkas_sarana', 1);
		$this->db->where('status_berkas_berita_acara', 1);
		$this->db->where('status_berkas_lainnya', 1);
		$this->db->where('status_penyerahan', 0);
		$this->db->order_by("id_perumahan_permohonan", "desc");
		$rows = $this->db->get("permohonan")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			$result[] = $permohonan;
		}

		return $result;
	}

	public function sudahPenyerahan($filters = []): array
	{
		foreach ($filters as $filter) {
			$this->db->where($filter['column'], $filter['value']);
		}

		$this->db->where('status_penyerahan', 1);
		$this->db->order_by("id_perumahan_permohonan", "desc");
		$rows = $this->db->get("permohonan")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			$result[] = $permohonan;
		}

		return $result;
	}

	public function penyerahan($id)
	{
		$this->db->where('id_perumahan_permohonan', $id);
		$this->db->update("permohonan", [
			"status_penyerahan" => 1
		]);
	}

	public function filterByTahunTanggalTerbit($tahun): array
	{
		$this->db->where('YEAR(tanggal_terbit)', $tahun);
		$this->db->order_by("id_perumahan_permohonan", "desc");
		$rows = $this->db->get("permohonan")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$permohonan = new Permohonan();
			$permohonan->id = $row["id_perumahan_permohonan"];
			$permohonan->namaPemohon = $row["nama_pemohon"];
			$permohonan->alamatPemohon = $row["alamat_pemohon"];
			$permohonan->kelurahanPemohon = $row["kelurahan_pemohon"];
			$permohonan->kecamatanPemohon = $row["kecamatan_pemohon"];
			$permohonan->kotaPemohon = $row["kota_pemohon"];
			$permohonan->alamatPerumahan = $row["alamat_perumahan"];
			$permohonan->kelurahanPerumahan = $row["kelurahan_perumahan"];
			$permohonan->kecamatanPerumahan = $row["kecamatan_perumahan"];
			$permohonan->kotaPerumahan = $row["kota_perumahan"];
			$permohonan->tipePerumahan = $row["tipe_perumahan"];
			$permohonan->luasKav = $row["luas_kav"];
			$permohonan->luasEfektif = $row["luas_efektif"];
			$permohonan->luasFasum = $row["luas_fasum"];
			$permohonan->luasTpu = $row["luas_tpu"];
			$permohonan->luasRTH = $row["luasRTH"];
			$permohonan->jumlahUnit = $row["jumlah_unit"];
			$permohonan->nomorSuratPengesahan = $row["nomor_surat_pengesahan"];
			$permohonan->tanggalTerbit = $row["tanggal_terbit"];
			$permohonan->keterangan = $row["keterangan"];
			$permohonan->berkasPermohonan = $row["berkas_permohonan"];
			$permohonan->statusBerkasPermohonan = $row["status_berkas_permohonan"];
			$permohonan->berkasPrasarana = $row["berkas_prasarana"];
			$permohonan->statusBerkasPrasarana = $row["status_berkas_prasarana"];
			$permohonan->berkasSarana = $row["berkas_sarana"];
			$permohonan->statusBerkasSarana = $row["status_berkas_sarana"];
			$permohonan->berkasBeritaAcara = $row["berkas_berita_acara"];
			$permohonan->statusBerkasBeritaAcara = $row["status_berkas_berita_acara"];
			$permohonan->berkasLainnya = $row["berkas_lainnya"];
			$permohonan->statusBerkasLainnya = $row["status_berkas_lainnya"];
			$permohonan->statusPenyerahan = $row["status_penyerahan"];
			$permohonan->idPerumahan = $row["id_perumahan"];

			$this->db->where("id_perumahan", $permohonan->idPerumahan);
			$row = $this->db->get("perumahan")->row_array();
			if ($row != null) {
				$perumahan = new Perumahan();
				$perumahan->id = $row["id_perumahan"];
				$perumahan->nama = $row["nama"];
				$perumahan->perusahaan = $row["perusahaan"];
				$perumahan->latitude = $row["latitude"];
				$perumahan->longitude = $row["longitude"];

				$permohonan->perumahan = $perumahan;
			} else {
				$permohonan->perumahan = null;
			}

			$result[] = $permohonan;
		}

		return $result;
	}
}
