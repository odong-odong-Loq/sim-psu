<?php

require_once __DIR__ . "/../data/Pengguna.php";

class PenggunaModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function all(): array
	{
		$this->db->where("role", "petugas");
		$this->db->order_by("id", "desc");
		$rows = $this->db->get("pengguna")->result_array();

		$result = [];
		foreach ($rows as $row) {
			$pengguna = new Pengguna();
			$pengguna->id = $row["id"];
			$pengguna->namaLengkap = $row["nama_lengkap"];
			$pengguna->foto = $row["foto"];
			$pengguna->username = $row["username"];
			$pengguna->password = $row["password"];
			$pengguna->role = $row["role"];

			$result[] = $pengguna;
		}

		return $result;
	}

	public function save(Pengguna $pengguna): bool
	{
		return $this->db->insert("pengguna", [
			"nama_lengkap" => $pengguna->namaLengkap,
			"username" => $pengguna->username,
			"password" => $pengguna->password,
		]);
	}

	public function find($id): ?Pengguna
	{
		$this->db->where("id", $id);
		$row = $this->db->get("pengguna")->row_array();

		if ($row != null) {
			$pengguna = new Pengguna();
			$pengguna->id = $row["id"];
			$pengguna->namaLengkap = $row["nama_lengkap"];
			$pengguna->foto = $row["foto"];
			$pengguna->username = $row["username"];
			$pengguna->password = $row["password"];
			$pengguna->role = $row["role"];

			return $pengguna;
		} else {
			return null;
		}
	}

	public function update(Pengguna $pengguna)
	{
		$this->db->where('id', $pengguna->id);
		$this->db->update("pengguna", [
			"nama_lengkap" => $pengguna->namaLengkap,
			"foto" => $pengguna->foto,
			"username" => $pengguna->username,
			"password" => $pengguna->password,
		]);
	}

	public function delete($id): bool
	{
		$this->db->where("	id", $id);
		return $this->db->delete("	pengguna");
	}

	public function findByUsername($username, $pass): ?Pengguna
	{
		
		// if(password_verify($request->password, $pengguna->password))
		$this->db->where("nama_pengguna", $username);  
	// 	$row = $this->db->get("pengguna")->row_array();

		$row = $this->db->get_where('pengguna', array('nama_pengguna' => $username))->row_array();
	
		if ($row && password_verify($pass, $row->kata_kunci)) {
 			$pengguna = new Pengguna();
			$pengguna->id = $row["id"];
			$pengguna->namaLengkap = $row["nama_lengkap"];
			$pengguna->foto = $row["foto"];
			$pengguna->username = $row["nama_pengguna"];
			$pengguna->password = $row["kata_kunci"];
			$pengguna->role = $row["role"]; 
			return $pengguna;
		} else {
			return null;
		}
	}
}
