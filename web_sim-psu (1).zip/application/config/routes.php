<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'PageController/beranda';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// PageController
$route['beranda'] = 'PageController/beranda';
$route['visi-misi'] = 'PageController/visiMisi';
$route['tujuan-sasaran'] = 'PageController/tujuanSasaran';
$route['tujuan-sasaran'] = 'PageController/tujuanSasaran';
$route['struktur-organisasi'] = 'PageController/strukturOrganisasi';
$route['peraturan'] = 'PageController/peraturan';
$route['prosedur-serah-terima'] = 'PageController/prosedurSerahTerima';
$route['tahap-verifikasi'] = 'PageController/tahapVerifikasi';
$route['aset-psu'] = 'PageController/asetPsu';
$route['dashboard'] = 'PageController/dashboard';
$route['baca/(:any)'] = 'PageController/baca/$1';
$route['data-permohonan'] = 'PageController/dataPermohonan';
$route['data-perumahan'] = 'PageController/dataPerumahan';
$route['peta-perumahan-roadmap'] = 'PageController/petaPerumahanRoadmap';
$route['peta-perumahan-satelite'] = 'PageController/petaPerumahanSatelite';
$route['infografis'] = 'PageController/infografis';
$route['peta-RPP'] = 'PageController/petaRPP';

// AuthController
$route['login'] = 'AuthController/login';
$route['post/login'] = 'AuthController/postLogin';
$route['logout'] = 'AuthController/logout';

// RkkController
$route['rpp'] = 'RPPController/rpp';
$route['rpp/detail'] = 'RPPController/detail';


// PermohonanController
$route['permohonan'] = 'PermohonanController/permohonan';
$route['terverifikasi'] = 'PermohonanController/terverifikasi';
$route['penyerahan-aset'] = 'PermohonanController/penyerahanAset';
$route['permohonan/tambah'] = 'PermohonanController/tambah';
$route['permohonan/post-tambah'] = 'PermohonanController/postTambah';
$route['permohonan/post-hapus'] = 'PermohonanController/postHapus';
$route['permohonan/edit'] = 'PermohonanController/edit';
$route['permohonan/post-edit'] = 'PermohonanController/postEdit';
$route['permohonan/detail'] = 'PermohonanController/detail';
$route['permohonan/post-penyerahan'] = 'PermohonanController/postPenyerahan';

// PerumahanController
$route['perumahan'] = 'PerumahanController/perumahan';
$route['perumahan/post-tambah'] = 'PerumahanController/postTambah';
$route['perumahan/post-hapus'] = 'PerumahanController/postHapus';
$route['perumahan/edit'] = 'PerumahanController/edit';
$route['perumahan/post-edit'] = 'PerumahanController/postEdit';

// PenggunaController
$route['pengguna'] = 'PenggunaController/pengguna';
$route['pengaturan'] = 'PenggunaController/pengaturan';
$route['pengguna/post-tambah'] = 'PenggunaController/postTambah';
$route['pengguna/post-hapus'] = 'PenggunaController/postHapus';
$route['pengguna/edit'] = 'PenggunaController/edit';
$route['pengguna/post-edit'] = 'PenggunaController/postEdit';
$route['pengguna/detail'] = 'PenggunaController/detail';
$route['pengguna/post-edit-profile'] = 'PenggunaController/postEditProfile';
$route['pengguna/post-edit-password'] = 'PenggunaController/postEditPassword';

// SlideController
$route['slide'] = 'SlideController/slide';
$route['slide/post-tambah'] = 'SlideController/postTambah';
$route['slide/post-hapus'] = 'SlideController/postHapus';
$route['slide/edit'] = 'SlideController/edit';
$route['slide/post-edit'] = 'SlideController/postEdit';

// BeritaController
$route['berita'] = 'BeritaController/berita';
$route['berita/post-tambah'] = 'BeritaController/postTambah';
$route['berita/post-hapus'] = 'BeritaController/postHapus';
$route['berita/edit'] = 'BeritaController/edit';
$route['berita/post-edit'] = 'BeritaController/postEdit';
